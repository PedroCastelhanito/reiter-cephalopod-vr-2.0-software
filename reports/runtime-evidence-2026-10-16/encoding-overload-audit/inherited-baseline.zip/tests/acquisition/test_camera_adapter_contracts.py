"""Exact SDK selection, required camera features and native pixel layouts."""

from __future__ import annotations

from threading import Event
from types import SimpleNamespace

import pytest

from cephvr.acquisition.camera.basler import BaslerCameraAdapter
from cephvr.acquisition.camera.errors import CameraAdapterError
from cephvr.acquisition.camera.features import capability, read_value, write_value
from cephvr.acquisition.camera.metadata import native_metadata
from cephvr.acquisition.camera.native_formats import (
    device_pixel_format,
    native_pixel_format,
    pylon_pixel_format,
)
from cephvr.acquisition.camera.wait import PylonWaitGate


@pytest.fixture(autouse=True)
def native_control_event(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("cephvr.acquisition.camera.wait.ManualResetEvent.create", Event)


def test_adapter_construction_does_not_load_pypylon() -> None:
    adapter = BaslerCameraAdapter()
    assert adapter._pylon is None
    assert adapter._camera is None


@pytest.mark.parametrize(
    "model,interface,frequency,expected",
    [
        ("acA4112-30uc", "usb3", None, (1, 1)),
        ("a2A1920-160ucPRO", "usb3", None, (1, 1)),
        ("a2A2464-77umPRO", "usb3", None, (1, 1)),
        ("unknown", "usb3", None, (None, None)),
        ("acA4112-30uc", "gige", None, (None, None)),
        ("acA4112-30uc", "usb3", 125_000_000, (8, 1)),
        ("unknown", "gige", 125_000_000, (8, 1)),
    ],
)
def test_metadata_uses_only_documented_model_clock_fallback(
    monkeypatch, model, interface, frequency, expected
) -> None:
    from cephvr.acquisition.camera import metadata

    values = {"DeviceModelName": model, "TimestampTickFrequency": frequency}
    monkeypatch.setattr(metadata, "read_value", lambda nodes, name: values.get(name))
    monkeypatch.setattr(metadata, "get_node", lambda nodes, name: None)
    monkeypatch.setattr(
        metadata.importlib, "import_module", lambda name: SimpleNamespace()
    )
    camera = SimpleNamespace(GetNodeMap=lambda: object())
    result = native_metadata(camera, "exact-device", interface)
    clock = result.camera_clock
    assert (
        clock.tick_period_ns_numerator,
        clock.tick_period_ns_denominator,
    ) == expected
    assert result.timestamp_available is (expected[0] is not None)
    assert any(w.code == "NATIVE_TIMESTAMP_UNAVAILABLE" for w in result.warnings) is (
        expected[0] is None
    )


@pytest.mark.parametrize("failed_close", [False, True])
@pytest.mark.parametrize("timing", ["external_trigger", "free_running"])
def test_preview_reopen_retires_only_closed_device_purge_guard(
    monkeypatch: pytest.MonkeyPatch, failed_close: bool, timing: str
) -> None:
    info = SimpleNamespace(
        GetSerialNumber=lambda: "assigned", GetDeviceClass=lambda: "BaslerUsb"
    )
    cameras = []

    class Camera:
        def __init__(self):
            self.opened = False
            self.fail_close = False
            self.buffers = 0
            self.MaxNumBuffer = SimpleNamespace(
                SetValue=lambda value: setattr(self, "buffers", value),
                GetValue=lambda: self.buffers,
            )
            self.NumReadyBuffers = SimpleNamespace(GetValue=lambda: 0)

        def Open(self):
            self.opened = True

        def IsOpen(self):
            return self.opened

        def StopGrabbing(self):
            pass

        def Close(self):
            if self.fail_close:
                raise RuntimeError("native Close failed")
            self.opened = False

    def create(_device):
        camera = Camera()
        cameras.append(camera)
        return camera

    factory = SimpleNamespace(
        EnumerateDevices=lambda: [info], CreateDevice=lambda value: value
    )
    adapter = BaslerCameraAdapter()
    adapter._pylon = SimpleNamespace(
        TlFactory=SimpleNamespace(GetInstance=lambda: factory), InstantCamera=create
    )
    monkeypatch.setattr(adapter, "_set_trigger_state", lambda *_args: None)
    monkeypatch.setattr(adapter._wait_gate, "probe", lambda *_args: None)
    monkeypatch.setattr(adapter, "_stop_device_generation", lambda _camera: True)
    monkeypatch.setattr("cephvr.acquisition.camera.basler.host_time_ns", lambda: 100)
    for cycle in range(6):
        adapter.open("assigned")
        adapter.configure_capture(timing, 3)
        adapter._grabbing = True
        adapter._drain_margin_confirmed = True
        # Pending control work interrupts the observable drain; never guess zero.
        evidence = adapter.stop_capture(200, should_continue_drain=lambda: False)
        assert not evidence.accounting_complete
        assert evidence.discarded_frame_count is None
        with pytest.raises(CameraAdapterError, match="unknown SDK-buffer"):
            adapter.configure_capture(timing, 3)
        camera = cameras[-1]
        if failed_close and cycle == 0:
            camera.fail_close = True
            with pytest.raises(CameraAdapterError, match="native Close failed"):
                adapter.release_device()
            assert adapter.device_open
            assert adapter._last_purge_evidence is evidence
            with pytest.raises(CameraAdapterError, match="unknown SDK-buffer"):
                adapter.configure_capture(timing, 3)
            camera.fail_close = False
        adapter.release_device()
        assert not camera.opened and not adapter.device_open
        assert not evidence.accounting_complete
    assert len(cameras) == 6


@pytest.mark.parametrize("trigger_mode", ["On", "Off"])
def test_setting_saved_rate_preserves_external_pfs_limiter(
    monkeypatch, trigger_mode
) -> None:
    from cephvr.acquisition.camera import settings as mapping
    from cephvr.acquisition.camera.types import CameraSettings

    requested = CameraSettings(None, None, 30.0, None, None, None, None, None, None)
    writes = []
    nodes = object()
    monkeypatch.setattr(mapping, "_disable_supported_auto", lambda *args: None)
    monkeypatch.setattr(mapping, "apply_roi", lambda *args: None)
    monkeypatch.setattr(mapping, "_apply_float", lambda *args: None)
    monkeypatch.setattr(mapping, "read_settings", lambda camera: requested)
    monkeypatch.setattr(mapping, "get_node", lambda *args: object())
    values = {"TriggerMode": trigger_mode, "AcquisitionFrameRateEnable": False}
    monkeypatch.setattr(mapping, "read_value", lambda nodes, key: values.get(key))

    def write(nodes, key, value):
        writes.append((key, value))
        values[key] = value

    monkeypatch.setattr(mapping, "write_value", write)
    result = mapping.apply_settings(
        SimpleNamespace(GetNodeMap=lambda: nodes), requested, object()
    )
    assert result.actual == requested
    assert values["AcquisitionFrameRateEnable"] == (trigger_mode == "Off")
    assert writes == (
        [("AcquisitionFrameRateEnable", True)] if trigger_mode == "Off" else []
    )


def test_absent_sdk_node_is_optional_only_for_readback() -> None:
    class LogicalErrorException(Exception):
        pass

    def missing(_):
        raise LogicalErrorException("Node not existing (file 'genicam_wrap.cpp')")

    nodes = SimpleNamespace(GetNode=missing)
    assert read_value(nodes, "BslEffectiveExposureTime") is None
    with pytest.raises(CameraAdapterError, match="required mapped feature"):
        write_value(nodes, "TriggerSource", "Line4")


@pytest.mark.parametrize("external", [True, False])
def test_resolution_selects_requested_timing_before_applying_saved_rate(
    monkeypatch, external
) -> None:
    from unittest.mock import MagicMock

    from cephvr.acquisition.v1 import camera_pb2 as camera
    from cephvr.acquisition.v1 import messages_pb2 as acq
    from cephvr.acquisition.worker import camera_resolution as resolution

    adapter = MagicMock()
    expected = "external_trigger" if external else "free_running"

    def apply(settings):
        adapter.configure_capture.assert_called_once_with(expected, 1)
        return SimpleNamespace(
            applied=settings, actual=settings, effective_exposure_us=None
        )

    adapter.apply_settings.side_effect = apply
    monkeypatch.setattr(
        resolution,
        "resolved_state_to_wire",
        lambda **kwargs: camera.CameraResolvedState(),
    )
    request = acq.WorkerResolveCamera(
        configuration_revision=1,
        requested=camera.CameraDeviceConfiguration(
            device_id="CAM-1",
            frame_timing=camera.FRAME_TIMING_EXTERNAL_TRIGGER
            if external
            else camera.FRAME_TIMING_FREE_RUNNING,
        ),
    )
    resolution.resolve_camera(adapter, request)
    adapter.apply_settings.assert_called_once()


def test_other_sdk_lookup_failure_is_not_hidden() -> None:
    class LogicalErrorException(Exception):
        pass

    def invalid(_):
        raise LogicalErrorException("Device state is invalid")

    with pytest.raises(CameraAdapterError, match="Device state is invalid"):
        read_value(SimpleNamespace(GetNode=invalid), "Gain")


@pytest.mark.parametrize("has_increment", [False, True])
def test_float_capability_respects_optional_increment(
    monkeypatch, has_increment
) -> None:
    def increment():
        assert has_increment, "GetInc is invalid without a constant increment"
        return 0.1

    node = SimpleNamespace(
        GetValue=lambda: 2.0,
        GetMin=lambda: 0.0,
        GetMax=lambda: 12.0,
        HasInc=lambda: has_increment,
        GetInc=increment,
    )
    monkeypatch.setattr("cephvr.acquisition.camera.features.available", lambda _: True)
    monkeypatch.setattr("cephvr.acquisition.camera.features.readable", lambda _: True)
    monkeypatch.setattr("cephvr.acquisition.camera.features.writable", lambda _: True)
    result = capability(SimpleNamespace(GetNode=lambda _: node), "Gain", unit="dB")
    assert result.increment == (0.1 if has_increment else None)
    assert result.minimum == 0.0
    assert result.maximum == 12.0


def test_sdk_version_mismatch_is_explicit_and_does_not_import(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    adapter = BaslerCameraAdapter()
    imports: list[str] = []
    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.importlib.metadata.version",
        lambda _name: "26.4.0",
    )

    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.importlib.import_module",
        lambda name: imports.append(name),
    )
    with pytest.raises(CameraAdapterError, match="expected 26.3.1") as failure:
        adapter._sdk()
    assert failure.value.code == "SDK_UNAVAILABLE"
    assert imports == []


def test_idle_control_wait_keeps_native_deadline_wake_and_close(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[int] = []

    class NativeEvent:
        closed = False
        signaled = False

        def wait(self, timeout_ns: int) -> bool:
            calls.append(timeout_ns)
            return self.signaled

        def set(self) -> None:
            self.signaled = True

        def clear(self) -> None:
            self.signaled = False

        def close(self) -> None:
            self.closed = True

    event = NativeEvent()
    monkeypatch.setattr(
        "cephvr.acquisition.camera.wait.ManualResetEvent.create", lambda: event
    )
    gate = PylonWaitGate()
    assert not gate.wait_control(123_456)
    gate.wake()
    assert gate.wait_control(0)
    gate.clear()
    assert not gate.wait_control(789)
    with pytest.raises(ValueError, match="nonnegative"):
        gate.wait_control(-1)
    assert calls == [123_456, 0, 789]
    gate.close()
    gate.close()
    assert event.closed
    with pytest.raises(CameraAdapterError, match="unavailable"):
        gate.wait_control(0)


@pytest.mark.parametrize("control_ready", [False, True])
def test_joint_wait_retains_control_priority_and_rounding(control_ready: bool) -> None:
    gate = PylonWaitGate()
    waits: list[int] = []

    def wait(timeout: int) -> bool:
        waits.append(timeout)
        return True

    gate._waits = SimpleNamespace(WaitForAny=wait)
    if control_ready:
        gate.wake()
    assert gate.wait(1_000_001) == ("control" if control_ready else "frame")
    assert waits == [2]


def test_open_uses_exact_assigned_serial_not_enumeration_order() -> None:
    class DeviceInfo:
        def __init__(self, serial: str) -> None:
            self.serial = serial

        def GetSerialNumber(self) -> str:
            return self.serial

        def GetDeviceClass(self) -> str:
            return "BaslerUsb"

    first, assigned = DeviceInfo("other"), DeviceInfo("assigned")

    class Camera:
        opened = False

        def Open(self) -> None:
            self.opened = True

    native_camera = Camera()

    class Factory:
        def EnumerateDevices(self) -> tuple[DeviceInfo, DeviceInfo]:
            return first, assigned

        def CreateDevice(self, info: DeviceInfo) -> DeviceInfo:
            assert info is assigned
            return info

    factory = Factory()
    pylon = SimpleNamespace(
        TlFactory=SimpleNamespace(GetInstance=lambda: factory),
        InstantCamera=lambda _device: native_camera,
    )
    adapter = BaslerCameraAdapter()
    adapter._pylon = pylon

    adapter.open("assigned")

    assert native_camera.opened
    assert adapter._device_id == "assigned"
    assert adapter._interface == "usb3"


def test_trigger_timing_selects_and_verifies_exact_selector(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[tuple[str, str]] = []
    values = {"TriggerSelector": "FrameStart", "TriggerMode": "Off"}
    nodes = object()
    fake_camera = SimpleNamespace(GetNodeMap=lambda: nodes)
    adapter = BaslerCameraAdapter()
    adapter._camera = fake_camera
    adapter._device_info = object()
    adapter._opened = True
    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.get_node",
        lambda _nodes, name: object() if name in values else None,
    )
    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.set_enum",
        lambda _nodes, name, value: _set_enum(calls, values, name, value),
    )
    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.read_value",
        lambda _nodes, name: values.get(name),
    )

    assert adapter.read_frame_timing() == "free_running"
    assert calls == [("TriggerSelector", "FrameStart")]


def test_missing_trigger_mode_blocks_readiness(monkeypatch: pytest.MonkeyPatch) -> None:
    adapter = BaslerCameraAdapter()
    adapter._camera = SimpleNamespace(GetNodeMap=lambda: object())
    adapter._device_info = object()
    adapter._opened = True
    monkeypatch.setattr(
        "cephvr.acquisition.camera.basler.get_node",
        lambda _nodes, name: object() if name == "TriggerSelector" else None,
    )
    with pytest.raises(CameraAdapterError, match="TriggerMode readback is unavailable"):
        adapter.read_frame_timing()


def _set_enum(
    calls: list[tuple[str, str]], values: dict[str, str], name: str, value: str
) -> None:
    calls.append((name, value))
    values[name] = value


def test_rgb_pylon_name_and_device_symbol_resolve_same_layout() -> None:
    native = pylon_pixel_format("RGB8packed", sdk_value=17)
    device = device_pixel_format("RGB8")
    assert native == device
    assert native.sdk_name == "RGB8packed"
    assert native.sdk_value == 17


def test_native_color_result_uses_pylon_registry_not_device_symbol_registry() -> None:
    pylon = SimpleNamespace(PixelType_BGR10packed=42)
    result = native_pixel_format(pylon, 42)
    assert result == pylon_pixel_format("BGR10packed")
    assert result.sdk_name == "BGR10packed"


@pytest.mark.parametrize("already_open", [False, True])
@pytest.mark.parametrize("serial", ["CAM-1", "wrong"])
def test_connection_check_verifies_identity_and_preserves_existing_owner(
    already_open: bool,
    serial: str,
) -> None:
    from cephvr.acquisition.v1 import messages_pb2 as acq
    from cephvr.acquisition.worker.camera_configuration import WorkerCameraConfiguration

    calls: list[str] = []
    adapter = SimpleNamespace(
        device_open=already_open,
        open=lambda device: calls.append(f"open:{device}"),
        read_device_identity=lambda: SimpleNamespace(physical_id=serial),
        release_device=lambda: calls.append("close"),
    )
    owner = WorkerCameraConfiguration(adapter, SimpleNamespace(), lambda: False)
    request = acq.WorkerEditCamera(kind=acq.CAMERA_EDIT_KIND_TEST_CONNECTION)
    request.requested.device_id = "CAM-1"
    if serial == "wrong":
        with pytest.raises(RuntimeError, match="identity differs"):
            owner.edit(request, acq.WorkerOperationReport())
    else:
        owner.edit(request, acq.WorkerOperationReport())
    assert calls == ["open:CAM-1"] + ([] if already_open else ["close"])


def test_connection_check_never_reports_success_after_release_failure() -> None:
    from cephvr.acquisition.v1 import messages_pb2 as acq
    from cephvr.acquisition.worker.camera_configuration import WorkerCameraConfiguration

    def failed_close() -> None:
        raise RuntimeError("native close failed")

    owner = WorkerCameraConfiguration(
        SimpleNamespace(
            device_open=False,
            open=lambda _: None,
            read_device_identity=lambda: SimpleNamespace(physical_id="CAM-1"),
            release_device=failed_close,
        ),
        SimpleNamespace(),
        lambda: False,
    )
    request = acq.WorkerEditCamera(kind=acq.CAMERA_EDIT_KIND_TEST_CONNECTION)
    request.requested.device_id = "CAM-1"
    with pytest.raises(RuntimeError, match="native close failed"):
        owner.edit(request, acq.WorkerOperationReport())


def test_first_pfs_import_opens_assigned_camera_and_retains_sdk_readback(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from cephvr.acquisition.v1 import camera_pb2 as camera
    from cephvr.acquisition.v1 import messages_pb2 as acq
    from cephvr.acquisition.worker import camera_configuration as module

    calls = []
    adapter = SimpleNamespace(
        open=lambda serial: calls.append(("open", serial)),
        import_pfs=lambda path: calls.append(("import", path)),
    )
    resolved = camera.CameraResolvedState(configuration_revision=4)
    resolved.applied.device_id = "CAM-1"
    resolved.applied.pfs_baseline.text = "SDK snapshot"
    monkeypatch.setattr(
        module, "resolve_imported_camera", lambda adapter, requested, revision: resolved
    )
    owner = module.WorkerCameraConfiguration(adapter, SimpleNamespace(), lambda: False)
    request = acq.WorkerEditCamera(
        kind=acq.CAMERA_EDIT_KIND_IMPORT_PFS,
        path="preset.pfs",
        configuration_revision=4,
    )
    request.requested.device_id = "CAM-1"
    report = acq.WorkerOperationReport()
    owner.edit(request, report)
    assert calls == [("open", "CAM-1"), ("import", "preset.pfs")]
    assert report.resolved_camera.applied.pfs_baseline.text == "SDK snapshot"


@pytest.mark.parametrize("revision", [3, 4, 5, 6])
@pytest.mark.parametrize("changed", [False, True])
@pytest.mark.parametrize("session", [False, True])
def test_preview_adoption_requires_retained_sdk_payload_and_exact_revision(
    revision: int, changed: bool, session: bool, monkeypatch: pytest.MonkeyPatch
) -> None:
    from cephvr.acquisition.v1 import camera_pb2 as camera
    from cephvr.acquisition.v1 import messages_pb2 as acq
    from cephvr.acquisition.worker.camera_configuration import WorkerCameraConfiguration

    state = SimpleNamespace(confirmed_configuration_revision=4)
    owner = WorkerCameraConfiguration(SimpleNamespace(), state, lambda: False)
    resolved = camera.CameraResolvedState(configuration_revision=4)
    resolved.applied.device_id = "CAM-1"
    owner._retain(resolved)
    installed = []
    monkeypatch.setattr(owner, "install_owned_functions", installed.append)
    request = (
        acq.WorkerSetupSession(configuration_revision=revision)
        if session
        else acq.WorkerPreparePreview(configuration_revision=revision)
    )
    adopt = owner.require_adopted_setup if session else owner.require_adopted_preview
    request.camera.device.CopyFrom(resolved.applied)
    if changed:
        request.camera.device.device_id = "CAM-2"
    if revision not in (4, 5):
        with pytest.raises(RuntimeError, match="adopted camera revision"):
            adopt(request)
    elif changed:
        with pytest.raises(ValueError, match="retained camera result"):
            adopt(request)
    else:
        adopt(request)
        assert installed == [request.camera]
        assert state.confirmed_configuration_revision == revision
        return
    assert not installed
    assert state.confirmed_configuration_revision == 4
