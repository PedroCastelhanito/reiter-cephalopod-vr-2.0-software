"""Controller-backed device requests kept separate from GUI transport scheduling."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from decimal import Decimal, InvalidOperation
from typing import Any, cast

from cephvr.acquisition.identity import CAMERA_NAME_BY_ROLE, camera_role_name
from cephvr.acquisition.v1 import camera_pb2
from cephvr.client.session import ClientError, HeadlessClient
from cephvr.control.v1 import services_pb2 as rpc
from cephvr.control.v1 import types_pb2 as pb
from cephvr.controller.microcontroller.firmware_source import read_firmware
from cephvr.gui.action_cancellation import checkpoint
from cephvr.gui.device_requests import (
    assign_camera_role,
    import_camera_preset,
    test_camera_connections,
)
from cephvr.gui.pin_numbers import firmware_pin
from cephvr.shared.auth import Principal


async def dispatch_device_action(
    client: HeadlessClient,
    action: str,
    options: dict[str, Any],
    principal: Principal,
) -> tuple[bool, str] | None:
    """Dispatch one device request; return None when another owner handles it."""
    checkpoint(options)
    if action == "set_spikeglx_enabled":
        state = client.snapshot
        if state.configuration.revision != options["expected_revision"]:
            raise ClientError("SpikeGLX pairing configuration revision changed.")
        if state.session.phase != pb.SESSION_PHASE_CONFIGURATION:
            raise ClientError("SpikeGLX pairing can only change in Configuration.")
        proposed = pb.ExperimentConfiguration.FromString(
            state.configuration_values.current.SerializeToString()
        )
        backend = next(
            (
                item
                for item in proposed.backends
                if item.backend_name == "synchronization"
            ),
            None,
        )
        if backend is None or type(options["enabled"]) is not bool:
            raise ClientError("SpikeGLX pairing settings are unavailable.")
        backend.enabled = options["enabled"]
        if proposed != state.configuration_values.current:
            await _update_configuration(client, state, proposed, "SpikeGLX pairing")
        return True, "Pairing enabled" if backend.enabled else "Pairing disabled"
    if action == "camera":
        await _camera(client, options)
        return True, "Completed"
    if action == "test_cameras":
        return await test_camera_connections(client, options["cameras"])
    if action in {"mcu", "mcu_upload"}:
        state = client.snapshot
        image = None
        if action == "mcu_upload":
            try:
                image = await asyncio.to_thread(read_firmware, str(options["path"]))
            except (OSError, UnicodeError, ValueError) as exc:
                raise ClientError(str(exc)) from exc
        request = rpc.MicrocontrollerCommandRequest(
            command=client.operator_command(),
            expected_configuration_revision=options.get(
                "confirmed_revision", state.configuration.revision
            ),
            kind=cast(
                Any,
                rpc.MICROCONTROLLER_COMMAND_KIND_UPLOAD_FIRMWARE
                if image
                else options["kind"],
            ),
            signal=cast(Any, options.get("signal", 0)),
        )
        if image is not None:
            request.firmware_path = str(image.path)
            request.firmware_sha256 = image.digest
        outcome = await client.execute("ExecuteMicrocontrollerCommand", request)
        checkpoint(options)
        if not outcome.succeeded:
            raise ClientError(outcome.failure or "MCU operation did not succeed.")
        return True, "Completed"
    if action == "spikeglx_connection":
        result = await client.stub.CheckSpikeGLXConnection(
            rpc.SpikeGLXConnectionQuery(client_id=principal.generation),
            metadata=principal.metadata(),
            timeout=6,
        )
        if result.error:
            raise ClientError(result.error)
        return True, (
            f"{result.address}:{result.port} · {result.version} · "
            f"running={result.running} · saving={result.saving} · "
            f"run={result.run_name or 'unvalidated'} · data={result.data_directory}"
        )
    if action == "save_mcu_pins":
        state = client.snapshot
        proposed = type(state.configuration_values.current)()
        proposed.CopyFrom(state.configuration_values.current)
        acquisition = next(
            (
                item.acquisition
                for item in proposed.backends
                if item.backend_name == "acquisition"
            ),
            None,
        )
        if acquisition is None:
            raise ClientError("Acquisition settings are unavailable.")
        pulses = acquisition.pulses
        pulses.port = options["port"]
        for field, value in (
            ("trial_state_pin", options["trial_pin"]),
            ("projector_flip_pin", options["flip_pin"]),
        ):
            if value:
                setattr(pulses, field, firmware_pin(value))
            else:
                pulses.ClearField(field)
        pulses.trial_state_enabled = options["trial_enabled"]
        pulses.projector_flip_enabled = False
        for pulse, value in (
            (pulses.behavioral, options["behavioral_pin"]),
            (pulses.tracking, options["tracking_pin"]),
            (pulses.eye_tracking, options.get("eye_tracking_pin")),
        ):
            if value is None:
                continue
            if value:
                pulse.pin = firmware_pin(value)
            else:
                pulse.ClearField("pin")
        await _update_configuration(client, state, proposed, "MCU pin settings")
        return True, "Completed"
    if action == "add_mcu_output":
        state = client.snapshot
        proposed = pb.ExperimentConfiguration.FromString(
            state.configuration_values.current.SerializeToString()
        )
        backend = next(
            (item for item in proposed.backends if item.backend_name == "acquisition"),
            None,
        )
        role = str(options["role"])
        if backend is None or role not in {"behavioral", "tracking", "eye_tracking"}:
            raise ClientError("Select an assigned camera output.")
        settings = backend.acquisition
        getattr(settings.pulses, role).pin = firmware_pin(str(options["pin"]))
        await _update_configuration(client, state, proposed, "Camera output pin")
        return True, "Completed"
    if action == "assign_camera_role":
        await assign_camera_role(client, options)
        return True, "Completed"
    if action == "set_camera_enabled":
        state = client.snapshot
        proposed = type(state.configuration_values.current)()
        proposed.CopyFrom(state.configuration_values.current)
        acquisition_entry, selected, _ = _assigned_camera(
            proposed, str(options["serial"])
        )
        enabled = bool(options["enabled"])
        selected.enabled = enabled
        if enabled:
            acquisition_entry.enabled = True
        await _update_configuration(client, state, proposed, "Camera enablement")
        return True, "Completed"
    if action == "save_camera_settings":
        await _save_camera_settings(client, options)
        return True, "Completed"
    return None


async def _camera(
    client: HeadlessClient,
    options: dict[str, Any],
) -> None:
    kind = int(options["kind"])
    role = int(options["role"])
    state = client.snapshot
    device = getattr(state.acquisition_devices, camera_role_name(role))
    if (
        kind == rpc.CAMERA_COMMAND_KIND_STOP_PREVIEW
        and not device.preview_run_id
        and (device.device_open or device.cleanup_pending)
    ):
        kind = rpc.CAMERA_COMMAND_KIND_FINISH_EDITING
    request = rpc.CameraCommandRequest(
        command=client.operator_command(),
        expected_configuration_revision=state.configuration.revision,
    )
    request.camera = cast(Any, role)
    request.kind = cast(Any, kind)
    if kind == rpc.CAMERA_COMMAND_KIND_SHOW_PREVIEW and "placement" in options:
        request.preview_placement.ParseFromString(options["placement"])
    if kind in (
        rpc.CAMERA_COMMAND_KIND_STOP_PREVIEW,
        rpc.CAMERA_COMMAND_KIND_SHOW_PREVIEW,
        rpc.CAMERA_COMMAND_KIND_HIDE_PREVIEW,
    ):
        camera = getattr(state.acquisition_devices, camera_role_name(role))
        if not camera.preview_run_id:
            raise ClientError("No current preview run for this camera.")
        request.preview_run_id = camera.preview_run_id
    outcome = await client.execute("ExecuteCameraCommand", request)
    checkpoint(options)
    if not outcome.succeeded:
        raise ClientError(outcome.failure or "Camera operation did not succeed.")
    if kind == rpc.CAMERA_COMMAND_KIND_START_PREVIEW and options.get("show_preview"):
        # Completion's current view supplies the exact new run; Show never starts capture.
        current = client.snapshot
        device = getattr(current.acquisition_devices, camera_role_name(role))
        if not device.preview_running or not device.preview_run_id:
            raise ClientError(
                "Capture completed without a confirmed preview run; refresh camera status."
            )
        show = rpc.CameraCommandRequest(
            command=client.operator_command(),
            expected_configuration_revision=current.configuration.revision,
            camera=cast(Any, role),
            kind=rpc.CAMERA_COMMAND_KIND_SHOW_PREVIEW,
            preview_run_id=device.preview_run_id,
        )
        if "placement" in options:
            show.preview_placement.ParseFromString(options["placement"])
        shown = await client.execute("ExecuteCameraCommand", show)
        checkpoint(options)
        if not shown.succeeded:
            raise ClientError(
                f"Capture started; preview could not open: {shown.failure or 'unconfirmed presentation'}. "
                "Disconnect to stop capture."
            )


async def _save_camera_settings(
    client: HeadlessClient,
    options: dict[str, Any],
    *,
    accepted: Callable[[pb.Snapshot], None] | None = None,
) -> None:
    state = client.snapshot
    proposed = type(state.configuration_values.current)()
    proposed.CopyFrom(state.configuration_values.current)
    acquisition, selected, pulse = _assigned_camera(proposed, str(options["serial"]))
    if options.get("prepare_action"):
        if options.get("pin"):
            pulse.pin = firmware_pin(str(options["pin"]))
        else:
            pulse.ClearField("pin")
        if options.get("clock") == "External controller":
            if options.get("port"):
                acquisition.acquisition.pulses.port = str(options["port"])
            else:
                acquisition.acquisition.pulses.ClearField("port")
    clock = str(options["clock"])
    if clock == "External controller":
        source = str(options["source"]).strip()
        if not source:
            raise ClientError(
                "Select a PFS file with an explicit FrameStart line source."
            )
        selected.device.frame_timing = camera_pb2.FRAME_TIMING_EXTERNAL_TRIGGER
        selected.device.unaligned_free_running = False
        selected.device.settings.trigger_source = source
    elif clock == "Internal clock":
        selected.device.frame_timing = camera_pb2.FRAME_TIMING_FREE_RUNNING
        selected.device.unaligned_free_running = True
        selected.device.settings.ClearField("trigger_source")
        selected.device.settings.ClearField("trigger_activation")
    else:
        raise ClientError("Select a camera trigger source before saving.")
    preset = str(options["preset"]).strip()
    import_preset = bool(
        preset
        and (
            options.get("import_preset", False)
            or preset != selected.device.pfs_source_filename
            or not selected.device.HasField("pfs_baseline")
        )
    )
    if preset:
        if import_preset:
            selected.device.ClearField("pfs_baseline")
        selected.device.pfs_source_filename = preset
    else:
        selected.device.ClearField("pfs_source_filename")
        if options.get("prepare_action"):
            selected.device.ClearField("pfs_baseline")
    rate = str(options["rate"]).strip()
    if rate:
        try:
            frequency = Decimal(rate)
        except InvalidOperation as exc:
            raise ClientError("Camera trigger rate is not a number.") from exc
        if not frequency.is_finite() or frequency <= 0 or frequency % Decimal("0.1"):
            raise ClientError("Camera trigger rate must use a positive 0.1 Hz grid.")
        pulse.requested_frequency_hz = float(frequency)
    elif options.get("prepare_action"):
        pulse.ClearField("requested_frequency_hz")
    if proposed != state.configuration_values.current:
        await _update_configuration(client, state, proposed, "Camera settings")
    if accepted is not None:
        accepted(client.snapshot)
    checkpoint(options)
    if import_preset:
        role = next(
            role
            for role, name in CAMERA_NAME_BY_ROLE.items()
            if getattr(acquisition.acquisition, name).device.device_id
            == str(options["serial"])
        )
        try:
            await import_camera_preset(client, role, preset)
        finally:
            if accepted is not None:
                accepted(client.snapshot)


async def _update_configuration(
    client: HeadlessClient,
    state: pb.Snapshot,
    proposed: pb.ExperimentConfiguration,
    label: str,
) -> None:
    outcome = await client.execute(
        "UpdateConfiguration",
        rpc.UpdateConfigurationRequest(
            command=client.operator_command(),
            expected_revision=state.configuration.revision,
            proposed=proposed,
        ),
    )
    if not outcome.succeeded:
        raise ClientError(outcome.failure or f"{label} were rejected.")


def _assigned_camera(
    proposed: pb.ExperimentConfiguration, serial: str
) -> tuple[
    pb.BackendSettings,
    camera_pb2.CameraSessionSettings,
    camera_pb2.CameraPulseSettings,
]:
    acquisition = next(
        (item for item in proposed.backends if item.backend_name == "acquisition"),
        None,
    )
    if acquisition is None:
        raise ClientError("Acquisition settings are unavailable.")
    pairs = (
        (acquisition.acquisition.behavioral, acquisition.acquisition.pulses.behavioral),
        (acquisition.acquisition.tracking, acquisition.acquisition.pulses.tracking),
        (
            acquisition.acquisition.eye_tracking,
            acquisition.acquisition.pulses.eye_tracking,
        ),
    )
    matches = [
        (settings, pulse)
        for settings, pulse in pairs
        if settings.device.device_id == serial
    ]
    if len(matches) != 1:
        raise ClientError(
            "Camera is not uniquely assigned in controller configuration."
        )
    return acquisition, *matches[0]
