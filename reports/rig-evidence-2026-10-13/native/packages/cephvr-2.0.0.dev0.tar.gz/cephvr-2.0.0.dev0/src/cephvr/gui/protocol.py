"""Card-based local protocol configuration and canonical timeline editing."""

from decimal import Decimal, InvalidOperation
from pathlib import Path

from PyQt6.QtCore import QIODevice, QSaveFile, Qt, pyqtSignal
from PyQt6.QtGui import QResizeEvent
from PyQt6.QtWidgets import (
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from cephvr.gui.components import Card, button, combo, equal_row_height
from cephvr.gui.configuration_files import ConfigurationFiles
from cephvr.gui.layouts import column
from cephvr.gui.notices import FormNotice
from cephvr.gui.protocol_batches import grouped_program
from cephvr.gui.protocol_document import TrialDraft, blank_program
from cephvr.gui.protocol_editor import ProtocolEditor
from cephvr.gui.protocol_history import EditHistory
from cephvr.gui.protocol_snapshot import (
    capture_protocol,
    restore_protocol,
    validate_protocol,
)
from cephvr.gui.recordings import RecordingsCard
from cephvr.gui.stimulus_assets import StimulusAssetsCard
from cephvr.gui.view import DashboardView
from cephvr.visual_stimulus.config.models.program_model import parse_program_json
from cephvr.visual_stimulus.config.models.schema_common import DEFAULT_DOCUMENT_BYTES


class ProtocolPage(QWidget):
    participation_changed = pyqtSignal()

    def __init__(self, recordings: RecordingsCard, *, sample: bool = False) -> None:
        super().__init__()
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.config_scroll = QScrollArea()
        self.config_scroll.setWidgetResizable(True)
        self.config_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.config_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        content, body = column()
        content.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.config_scroll.setWidget(content)
        root.addWidget(self.config_scroll)
        top = self.top_grid = QGridLayout()
        top.setSpacing(14)
        body.addLayout(top)
        self.assets = StimulusAssetsCard()
        top.addWidget(
            self.assets,
            0,
            1,
            alignment=Qt.AlignmentFlag.AlignTop,
        )
        top.setColumnStretch(0, 3)
        top.setColumnStretch(1, 2)
        self.recordings = recordings
        self.can_edit = False
        self.session_mode = combo(("Not set", "Open-loop", "Closed-loop"))
        self.session_mode.currentTextChanged.connect(self.participation_changed.emit)
        recordings.changed.connect(self.participation_changed.emit)
        self.program_card = Card("Protocol type")
        toolbar = QHBoxLayout()
        toolbar.setSpacing(10)
        toolbar.addWidget(self.session_mode, 1)
        self.load_button = button("Load…")
        self.load_button.clicked.connect(self.choose_load)
        self.save_button = button("Save as…")
        self.save_button.clicked.connect(self.choose_save)
        equal_row_height(self.session_mode, self.load_button, self.save_button)
        toolbar.addWidget(self.load_button, alignment=Qt.AlignmentFlag.AlignBottom)
        toolbar.addWidget(self.save_button, alignment=Qt.AlignmentFlag.AlignBottom)
        self.program_card.body.addLayout(toolbar)
        self.message = FormNotice()
        self.message.hide()
        self.program_card.body.addWidget(self.message)
        top.addWidget(
            self.program_card,
            0,
            0,
            alignment=Qt.AlignmentFlag.AlignTop,
        )
        self.editor = ProtocolEditor(sample=sample)
        self._schedule_empty = False
        self.editor.changed.connect(self.mark_changed)
        self.assets.folders["root"].editor.textChanged.connect(
            self.editor.subgroup.composer.set_asset_root
        )
        self.session_mode.currentTextChanged.connect(self.update_control_mode)
        self.update_control_mode()
        body.addWidget(self.editor, 1)
        self.config_files = ConfigurationFiles(
            self,
            "Protocol",
            "protocol.json",
            capture=lambda: capture_protocol(self),
            validate=lambda value: validate_protocol(value, allow_program=True),
            apply=lambda value: restore_protocol(self, value),
            available=lambda: self.can_edit,
            load_button=self.load_button,
            save_button=self.save_button,
            connect_actions=False,
        )
        self.config_files.message.connect(self.show_file_message)
        self.config_files.loaded_document.connect(self.remember_program_import)

    def remember_program_import(self, data: object, path: str) -> None:
        if isinstance(data, dict) and data.get("format") == "cephvr-program-import":
            self.editor.drafts[self.editor.index].path = path

    def show_file_message(self, message: str) -> None:
        self.message.status(message)
        self.message.show()

    def update_control_mode(self) -> None:
        closed = self.session_mode.currentText() == "Closed-loop"
        self.editor.subgroup.composer.set_closed_loop(closed)

    def resizeEvent(self, event: QResizeEvent | None) -> None:
        super().resizeEvent(event)
        wide = self.width() >= 650
        self.top_grid.removeWidget(self.assets)
        self.top_grid.addWidget(
            self.assets,
            0 if wide else 1,
            1 if wide else 0,
            alignment=Qt.AlignmentFlag.AlignTop,
        )
        self.top_grid.setColumnStretch(1, 2 if wide else 0)

    @property
    def tracking_active(self) -> bool:
        return (
            self.session_mode.currentText() == "Closed-loop"
            or self.recordings.velocities.isChecked()
        )

    def mark_changed(self) -> None:
        self._schedule_empty = False
        self.message.clear()
        self.message.hide()

    def install_configuration(self, configuration: object) -> None:
        """Install only the session protocol fields from an authoritative config."""
        from cephvr.control.v1 import types_pb2 as control_pb

        if not isinstance(configuration, control_pb.ExperimentConfiguration):
            raise TypeError("Expected an ExperimentConfiguration")
        drafts = []
        for index, trial in enumerate(configuration.trials):
            stimulus = trial.stimulus
            try:
                program = parse_program_json(
                    stimulus.program.program_json,
                    max_bytes=DEFAULT_DOCUMENT_BYTES,
                )
            except (ValueError, UnicodeError) as error:
                raise ValueError(
                    f"Trial {index + 1} source is invalid: {error}"
                ) from error
            seed = (
                stimulus.stimulus_seed_decimal
                if stimulus.HasField("stimulus_seed_decimal")
                else ""
            )
            if seed and (
                not seed.isascii() or not seed.isdecimal() or str(int(seed)) != seed
            ):
                raise ValueError(
                    f"Trial {index + 1} seed must be a canonical nonnegative integer"
                )
            drafts.append(
                TrialDraft(
                    f"Trial {index + 1}",
                    program,
                    stimulus.program.logical_source_reference
                    if stimulus.program.HasField("logical_source_reference")
                    else "",
                    seed,
                    "",
                    stimulus.arena_boundaries.boundaries_json
                    if stimulus.HasField("arena_boundaries")
                    else "",
                )
            )
        if not drafts:
            drafts = [TrialDraft("Add a trial", grouped_program(blank_program()))]
        seen_gaps: set[int] = set()
        for gap in configuration.gaps:
            if (
                gap.after_trial_number == 0
                or gap.after_trial_number >= len(configuration.trials)
                or gap.after_trial_number in seen_gaps
                or gap.minimum_duration_ns < 0
                or gap.minimum_duration_ns > 2**63 - 1
            ):
                raise ValueError(
                    "Controller gap does not match the ordered trial schedule"
                )
            seen_gaps.add(gap.after_trial_number)
            drafts[gap.after_trial_number - 1].gap_after_seconds = str(
                Decimal(gap.minimum_duration_ns) / Decimal(1_000_000_000)
            )
        mode_text = {
            control_pb.SESSION_MODE_UNSPECIFIED: "Not set",
            control_pb.SESSION_MODE_OPEN_LOOP: "Open-loop",
            control_pb.SESSION_MODE_CLOSED_LOOP: "Closed-loop",
        }.get(configuration.mode)
        if mode_text is None:
            raise ValueError("Controller configuration has an unknown session mode")
        self.session_mode.blockSignals(True)
        self.session_mode.setCurrentText(mode_text)
        self.session_mode.blockSignals(False)
        self.update_control_mode()
        root = configuration.asset_root if configuration.HasField("asset_root") else ""
        self.assets.folders["root"].editor.setText(root)
        self._schedule_empty = not bool(configuration.trials)
        editor = self.editor
        editor.blockSignals(True)
        editor.drafts = drafts
        editor.configuration_schedule_empty = self._schedule_empty
        editor.histories = [EditHistory() for _ in drafts]
        editor.index = editor.node_index = 0
        editor.trials.blockSignals(True)
        editor.trials.clear()
        editor.trials.addItems([draft.name for draft in drafts])
        editor.trials.setCurrentRow(0)
        editor.trials.blockSignals(False)
        editor.render_selection()
        editor.blockSignals(False)

    def apply_schedule(
        self, configuration: object, *, flush_parameters: bool = True
    ) -> None:
        """Replace only mode, asset root, ordered trials and inter-trial gaps."""
        from cephvr.control.v1 import types_pb2 as control_pb

        if not isinstance(configuration, control_pb.ExperimentConfiguration):
            raise TypeError("Expected an ExperimentConfiguration")
        if flush_parameters and not self.editor.flush_parameters():
            raise ValueError(
                "Finish or correct the selected trial's parameter edit first"
            )
        if not self.editor.drafts:
            raise ValueError("Add at least one trial")
        if self._schedule_empty:
            raise ValueError("Add a managed trial before submitting the session")
        if self.session_mode.currentText() == "Not set":
            raise ValueError("Choose an open-loop or closed-loop session mode")
        configuration.mode = (
            control_pb.SESSION_MODE_CLOSED_LOOP
            if self.session_mode.currentText() == "Closed-loop"
            else control_pb.SESSION_MODE_OPEN_LOOP
        )
        root = self.assets.folders["root"].editor.text().strip()
        if root:
            configuration.asset_root = root
        else:
            configuration.ClearField("asset_root")
        del configuration.trials[:]
        del configuration.gaps[:]
        for number, draft in enumerate(self.editor.drafts, start=1):
            trial = configuration.trials.add(trial_number=number)
            trial.stimulus.program.program_json = draft.program.model_dump_json()
            if draft.path:
                trial.stimulus.program.logical_source_reference = draft.path
            seed = draft.stimulus_seed_decimal.strip()
            if seed:
                if not seed.isascii() or not seed.isdecimal() or str(int(seed)) != seed:
                    raise ValueError(
                        f"Trial {number} seed must be a canonical nonnegative integer"
                    )
                trial.stimulus.stimulus_seed_decimal = seed
            trial.stimulus.arena_boundaries.boundaries_json = (
                draft.arena_boundaries_json or '{"format_version":1,"bindings":[]}'
            )
            gap = draft.gap_after_seconds.strip()
            if gap:
                if number == len(self.editor.drafts):
                    raise ValueError("The final trial cannot have a gap after it")
                try:
                    seconds = Decimal(gap)
                except InvalidOperation as error:
                    raise ValueError(f"Trial {number} gap must be a number") from error
                nanoseconds = seconds * Decimal(1_000_000_000)
                if (
                    not seconds.is_finite()
                    or seconds < 0
                    or nanoseconds != nanoseconds.to_integral_value()
                    or nanoseconds > 2**63 - 1
                ):
                    raise ValueError(
                        f"Trial {number} gap must be nonnegative whole nanoseconds"
                    )
                configuration.gaps.add(
                    after_trial_number=number,
                    minimum_duration_ns=int(nanoseconds),
                )

    def load_program(self, path: str) -> None:
        if not self.can_edit or not path:
            return
        try:
            with Path(path).open("rb") as stream:
                data = stream.read(DEFAULT_DOCUMENT_BYTES + 1)
            program = parse_program_json(
                data.decode("utf-8"), max_bytes=DEFAULT_DOCUMENT_BYTES
            )
        except (OSError, ValueError) as error:
            self.show_error("Cannot load program", error)
            return
        self.editor.drafts[self.editor.index].path = path
        self.editor.set_program(program)
        self.message.hide()

    def show_error(self, title: str, error: Exception) -> None:
        self.message.warn(error, title)
        self.message.show()
        self.message.setToolTip(str(error))

    @property
    def load_dialog(self) -> QFileDialog | None:
        dialog = self.config_files.dialog
        return (
            dialog
            if dialog is not None
            and dialog.acceptMode() == QFileDialog.AcceptMode.AcceptOpen
            else None
        )

    @property
    def save_dialog(self) -> QFileDialog | None:
        dialog = self.config_files.dialog
        return (
            dialog
            if dialog is not None
            and dialog.acceptMode() == QFileDialog.AcceptMode.AcceptSave
            else None
        )

    def choose_load(self) -> None:
        self.config_files.choose(save=False)

    def choose_save(self) -> None:
        self.config_files.choose(save=True)

    def save_program(self, path: str) -> None:
        if not self.can_edit or not self.editor.flush_parameters():
            return
        try:
            program = parse_program_json(
                self.editor.program.model_dump_json(), max_bytes=DEFAULT_DOCUMENT_BYTES
            )
            data = program.model_dump_json(indent=2).encode("utf-8")
            if len(data) > DEFAULT_DOCUMENT_BYTES:
                raise ValueError("Formatted protocol exceeds the document byte budget")
            output = QSaveFile(path)
            if not output.open(QIODevice.OpenModeFlag.WriteOnly):
                raise OSError(output.errorString())
            if output.write(data) != len(data):
                output.cancelWriting()
                raise OSError(output.errorString())
            if not output.commit():
                raise OSError(output.errorString())
        except (OSError, ValueError) as error:
            self.show_error("Cannot save program", error)
            return
        self.editor.drafts[self.editor.index].path = path
        self.message.status("Trial saved")
        self.message.show()

    def apply_view(self, view: DashboardView) -> None:
        self.assets.apply_view(view)
        self.can_edit = view.can_edit
        self.config_files.set_enabled(self.can_edit)
        if not self.can_edit:
            self.editor.close_source_dialog()
            if self.save_dialog is not None:
                self.save_dialog.reject()
            if self.load_dialog is not None:
                self.load_dialog.reject()
        self.program_card.setEnabled(self.can_edit)
        self.editor.setEnabled(self.can_edit)
        self.editor.subgroup.setEnabled(self.can_edit)
