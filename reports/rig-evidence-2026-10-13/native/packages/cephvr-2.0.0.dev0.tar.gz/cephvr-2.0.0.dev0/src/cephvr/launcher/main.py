"""Persistent Windows application-job owner and final shutdown backstop (E08)."""

from __future__ import annotations

import argparse
import base64
import os
import queue
import secrets
import sys
import threading
import time
from contextlib import ExitStack
from pathlib import Path
from uuid import uuid4

from cephvr.control.v1 import types_pb2 as control_types
from cephvr.controller.configuration import load_controller_configuration
from cephvr.launcher.decisions import LOST_KEY, LauncherDecisions
from cephvr.launcher.gui_relaunch import (
    GuiLaunchRegistration,
    GuiRelaunchCoordinator,
    GuiRelaunchDispatcher,
    GuiRelaunchReleased,
    GuiRelaunchWork,
    reconcile_relaunch,
    request_relaunch,
)
from cephvr.launcher.notification_reader import read_notifications
from cephvr.launcher.preflight import read_backend_port, require_distinct_ports
from cephvr.launcher.replacement import (
    ReplacementDeclined,
    ReplacementEndpoint,
    acquire_application_guard,
    request_gui_relaunch,
)
from cephvr.platform.windows.bootstrap import (
    close_handle,
    create_bootstrap_pipe,
    create_control_pipe,
    write_bootstrap,
)
from cephvr.platform.windows.jobs import WindowsJobs, WindowsLaunchError
from cephvr.platform.windows.python_runtime import (
    module_arguments,
    resolve_python_executable,
)
from cephvr.shared.clock import host_time_ns
from cephvr.shared.credentials import default_runtime_root
from cephvr.shared.managed_modules import missing_roles
from cephvr.shared.recovery import ApplicationExitReceipt, RecoveryStore


def _retain_until_empty(
    native: WindowsJobs, job_name: str, deadline_ns: int, verify_timeout_ns: int
) -> None:
    """Keep the sole job handle and guard until OS membership is provably empty."""
    terminated = False
    warned = False
    while True:
        try:
            if not native.inspect_launch_job(job_name):
                return
        except WindowsLaunchError:
            pass  # Unknown membership cannot release the application guard.
        now = host_time_ns()
        if now >= deadline_ns and not terminated:
            try:
                native.terminate_job(job_name)
            except WindowsLaunchError:
                pass
            else:
                terminated = True
        if now >= deadline_ns + verify_timeout_ns and not warned:
            sys.stderr.write(
                "CephVR application job absence remains unverified; retaining guard and job handle.\n"
            )
            warned = True
        time.sleep(0.05)


def run_launcher(
    *, software_root: Path, supervisor_config: Path, interpreter: Path
) -> None:
    if sys.platform != "win32":
        raise WindowsLaunchError("CephVR managed launch requires Windows")
    missing = missing_roles()
    if missing:
        raise WindowsLaunchError(
            "required managed bootstrap modules are unavailable: " + ", ".join(missing)
        )
    interpreter = resolve_python_executable(interpreter)
    if (
        supervisor_config.resolve()
        != (software_root / "config/backends/supervisor_config.toml").resolve()
    ):
        raise ValueError("supervisor config must belong to the selected software root")
    resolved = load_controller_configuration(software_root)
    policy_root = supervisor_config.parents[2] / "contracts" / "policy"
    backend_ports = {
        role: read_backend_port(supervisor_config.parent, policy_root, role)
        for role in ("acquisition", "visual_stimulus", "tracking")
    }
    require_distinct_ports(
        (
            resolved.controller_port,
            resolved.supervisor_startup.port,
            *backend_ports.values(),
        )
    )
    startup = resolved.supervisor_startup
    backstop_ns = startup.application_backstop_ns
    port = startup.port
    supervisor_generation = str(uuid4())
    controller_generation = str(uuid4())
    supervisor_token = secrets.token_urlsafe(48)
    controller_token = secrets.token_urlsafe(48)
    native = WindowsJobs()
    with (
        acquire_application_guard(
            default_runtime_root(), endpoint_wait_ns=startup.silence_timeout_ns
        ),
        ExitStack() as resources,
    ):
        application_job = native.create_application_job()
        decisions: LauncherDecisions | None = None
        try:
            replacement = resources.enter_context(
                ReplacementEndpoint(
                    default_runtime_root(),
                    controller_generation,
                    supervisor_generation,
                    backstop_ns + startup.terminate_exit_ns,
                )
            )
            bootstrap_read, bootstrap_write = create_bootstrap_pipe()
            control_read, control_write = create_control_pipe()
            controller_control_read, controller_control_write = create_control_pipe()
            ack_read, ack_write = create_bootstrap_pipe()
            child = native.launch_suspended(
                str(interpreter),
                module_arguments(
                    "cephvr.supervisor.main",
                    [
                        "--bootstrap-handle",
                        str(bootstrap_read),
                        "--launcher-control-handle",
                        str(control_write),
                        "--launcher-controller-control-handle",
                        str(controller_control_write),
                        "--launcher-ack-handle",
                        str(ack_read),
                    ],
                ),
                [application_job],
                (bootstrap_read, control_write, controller_control_write, ack_read),
            )
            members = native.inspect_launch_job(application_job)
            if len(members) != 1 or members[0][:2] != (
                child.pid,
                child.creation_time_100ns,
            ):
                native.terminate_exact(child.pid, child.creation_time_100ns)
                raise WindowsLaunchError("supervisor not contained at creation")
            native.resume(child)
            close_handle(bootstrap_read)
            close_handle(control_write)
            close_handle(controller_control_write)
            close_handle(ack_read)
            bootstrap_descriptor = {
                "software_root": str(software_root),
                "supervisor_generation": supervisor_generation,
                "controller_generation": controller_generation,
                "supervisor_token": supervisor_token,
                "controller_token": controller_token,
                "supervisor_port": port,
                "controller_port": resolved.controller_port,
                "backend_ports": backend_ports,
                "max_message_bytes": resolved.max_message_bytes,
                "max_retained_incidents": resolved.max_retained_incidents,
                "command_retention_ns": resolved.policies.command_retention_after_finalization_ns,
                # Reuse the controller's single resolved policy instance for
                # acquisition sessionless configuration-worker startup.
                "control_policies": base64.b64encode(
                    resolved.policies.SerializeToString(deterministic=True)
                ).decode("ascii"),
                "silence_timeout_ns": startup.silence_timeout_ns,
                "heartbeat_interval_ns": startup.heartbeat_interval_ns,
                "emergency_timeout_ns": startup.emergency_timeout_ns,
                "graceful_exit_ns": startup.graceful_exit_ns,
                "terminate_exit_ns": startup.terminate_exit_ns,
                "application_backstop_ns": startup.application_backstop_ns,
                "supervisor_config": str(supervisor_config),
                "interpreter": str(interpreter),
                "supervisor_pid": child.pid,
                "supervisor_creation_time_100ns": child.creation_time_100ns,
            }
            decisions = LauncherDecisions(
                supervisor_generation=supervisor_generation,
                controller_generation=controller_generation,
                backstop_ns=backstop_ns,
                registration_window_ns=startup.silence_timeout_ns,
                launched_ns=host_time_ns(),
            )
            bootstrap_done = threading.Event()
            bootstrap_seen = False
            bootstrap_error: list[BaseException] = []
            gui_relaunch = GuiRelaunchCoordinator()

            def send_bootstrap() -> None:
                try:
                    write_bootstrap(bootstrap_write, bootstrap_descriptor)
                except BaseException as exc:
                    bootstrap_error.append(exc)
                finally:
                    bootstrap_done.set()

            threading.Thread(
                target=send_bootstrap, daemon=True, name="cephvr-bootstrap"
            ).start()
            notifications: queue.Queue[dict[str, object]] = queue.Queue(maxsize=64)
            threading.Thread(
                target=read_notifications,
                args=(control_read, notifications, "supervisor"),
                daemon=True,
            ).start()
            threading.Thread(
                target=read_notifications,
                args=(controller_control_read, notifications, "controller"),
                daemon=True,
            ).start()

            def perform_gui_relaunch(
                work: GuiRelaunchWork,
            ) -> GuiLaunchRegistration | GuiRelaunchReleased | None:
                identity = control_types.ProcessIdentity(
                    role="supervisor", generation=supervisor_generation
                )
                if work.reconcile_only:
                    return reconcile_relaunch(
                        supervisor_port=port,
                        supervisor=identity,
                        supervisor_token=supervisor_token,
                        attempt=work.attempt,
                    )
                return request_relaunch(
                    supervisor_port=port,
                    supervisor=identity,
                    supervisor_token=supervisor_token,
                    interpreter=str(interpreter),
                    attempt=work.attempt,
                )

            gui_relaunch_dispatcher = GuiRelaunchDispatcher(
                gui_relaunch, perform_gui_relaunch
            )

            while True:
                now = host_time_ns()
                for result in gui_relaunch_dispatcher.poll():
                    if (
                        result.registration is not None
                        and gui_relaunch.current == result.registration
                    ):
                        sys.stderr.write(
                            "A fresh GUI was launched in the existing application generation.\n"
                        )
                    elif result.terminal_released:
                        sys.stderr.write(
                            "The exact attempted GUI launch is confirmed released; a later explicit request may create a new attempt.\n"
                        )
                    elif result.error and (
                        gui_relaunch.attempt == result.work.attempt
                        or result.definite_failure
                    ):
                        if result.definite_failure:
                            sys.stderr.write(
                                "GUI relaunch did not reach PlanLaunch; a later explicit request may create a new attempt: "
                                f"{result.error}\n"
                            )
                        else:
                            sys.stderr.write(
                                "GUI relaunch outcome is not yet confirmed; retaining its exact identity: "
                                f"{result.error}\n"
                            )
                    elif (
                        result.registration is None
                        and gui_relaunch.attempt == result.work.attempt
                    ):
                        sys.stderr.write(
                            "GUI relaunch remains unconfirmed; a later explicit request will query the same launch identity.\n"
                        )
                if decisions.shutdown_deadline_ns is not None:
                    gui_relaunch_dispatcher.shutdown()
                if replacement.requested():
                    sys.stderr.write(
                        "Operator confirmed runtime replacement; terminating application job.\n"
                    )
                    native.terminate_job(application_job)
                    return
                relaunch_requested = replacement.gui_relaunch_requested()
                if not bootstrap_seen and bootstrap_done.is_set():
                    bootstrap_seen = True
                    decisions.bootstrap_finished(now, ok=not bootstrap_error)
                    if bootstrap_error:
                        sys.stderr.write(
                            f"CephVR launcher bootstrap write failed: {bootstrap_error[0]!r}\n"
                        )
                decisions.tick(now)
                for _ in range(64):
                    try:
                        note = notifications.get_nowait()
                    except queue.Empty:
                        break
                    kind = note.get("kind")
                    if kind == "register_controller":
                        accepted = decisions.on_register_controller(now, note)
                        if accepted is not None:
                            pid, created = accepted
                            native.retain_exact(pid, created, str(interpreter))
                            decisions.controller_acknowledged(pid, created)
                            import msvcrt

                            ack_fd = msvcrt.open_osfhandle(ack_write, os.O_WRONLY)
                            os.write(ack_fd, b"A")
                            os.close(ack_fd)
                            ack_write = 0
                    elif kind == "register_gui_launch":
                        try:
                            registered = GuiLaunchRegistration.from_notification(note)
                        except WindowsLaunchError as exc:
                            sys.stderr.write(
                                f"Ignoring invalid GUI registration: {exc}\n"
                            )
                        else:
                            if (
                                registered.supervisor_generation
                                == supervisor_generation
                            ):
                                if not gui_relaunch.registered(registered):
                                    sys.stderr.write(
                                        "Ignoring GUI registration that does not match the active or pending exact identity.\n"
                                    )
                    elif kind == "channel_lost":
                        channel = str(note.get("_channel"))
                        reason = str(note.get(LOST_KEY))
                        decisions.on_channel_lost(now, channel, reason)
                        # The controller reason also goes into the exit receipt.
                        sys.stderr.write(
                            f"CephVR launcher {channel} channel lost: {reason}\n"
                        )
                    elif kind == "shutdown":
                        decisions.on_shutdown(now, note)
                if relaunch_requested:
                    if decisions.shutdown_deadline_ns is not None:
                        sys.stderr.write(
                            "GUI relaunch ignored after application shutdown began.\n"
                        )
                    elif gui_relaunch.current is None:
                        sys.stderr.write(
                            "GUI relaunch ignored: the supervisor has not registered a GUI process yet.\n"
                        )
                    else:
                        deadline_ns = min(
                            now + 10_000_000_000,
                            decisions.shutdown_deadline_ns
                            if decisions.shutdown_deadline_ns is not None
                            else now + 10_000_000_000,
                        )
                        work = gui_relaunch_dispatcher.request(
                            deadline_ns=deadline_ns, now_ns=now
                        )
                        if work is None:
                            sys.stderr.write(
                                "GUI relaunch request is already being reconciled or unavailable.\n"
                            )
                        else:
                            pass
                if not native.process_running(child.pid, child.creation_time_100ns):
                    decisions.arm(now)
                if decisions.controller is not None and not native.process_running(
                    *decisions.controller
                ):
                    decisions.arm(now)
                if decisions.shutdown_deadline_ns is not None:
                    try:
                        shutdown_members = native.inspect_launch_job(application_job)
                    except WindowsLaunchError:
                        shutdown_members = None
                    if shutdown_members == []:
                        return
                    if now >= decisions.shutdown_deadline_ns:
                        native.terminate_job(application_job)
                        _retain_until_empty(
                            native,
                            application_job,
                            decisions.shutdown_deadline_ns,
                            startup.terminate_exit_ns,
                        )
                        return
                time.sleep(0.1)
        finally:
            _retain_until_empty(
                native,
                application_job,
                (decisions and decisions.shutdown_deadline_ns)
                or host_time_ns() + backstop_ns,
                startup.terminate_exit_ns,
            )
            try:
                # The launcher alone owns the outer Job handle. Its empty OS
                # membership is the only evidence this receipt can assert.
                RecoveryStore(default_runtime_root()).write_exit_receipt(
                    ApplicationExitReceipt(
                        controller_generation=controller_generation,
                        supervisor_generation=supervisor_generation,
                        observed_monotonic_ns=host_time_ns(),
                        all_owned_processes_absent=True,
                        controller_channel_loss=(
                            decisions.lost_channels.get("controller", "")[:256]
                            if decisions
                            else ""
                        ),
                    )
                )
            finally:
                native.close_launch_job(application_job)


def main() -> None:
    parser = argparse.ArgumentParser(description="CephVR Windows application launcher")
    parser.add_argument("--software-root", type=Path, default=Path.cwd())
    parser.add_argument("--supervisor-config", type=Path)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument(
        "--reopen-gui",
        action="store_true",
        help="open a fresh GUI in the running application generation",
    )
    args = parser.parse_args()
    if args.reopen_gui:
        if sys.platform != "win32":
            parser.error("managed GUI relaunch requires Windows")
        try:
            request_gui_relaunch(default_runtime_root())
        except WindowsLaunchError as exc:
            parser.error(str(exc))
        return
    supervisor_config = args.supervisor_config or (
        args.software_root / "config/backends/supervisor_config.toml"
    )
    try:
        run_launcher(
            software_root=args.software_root.resolve(),
            supervisor_config=supervisor_config.resolve(),
            interpreter=args.python.resolve(),
        )
    except ReplacementDeclined as exc:
        print(exc)
    except WindowsLaunchError as exc:
        parser.exit(1, f"CephVR2 could not start: {exc}\n")


if __name__ == "__main__":
    main()
