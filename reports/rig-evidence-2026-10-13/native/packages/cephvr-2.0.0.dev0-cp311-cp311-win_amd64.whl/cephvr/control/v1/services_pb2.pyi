from cephvr.control.v1 import types_pb2 as _types_pb2
from cephvr.acquisition.v1 import messages_pb2 as _messages_pb2
from cephvr.acquisition.v1 import camera_pb2 as _camera_pb2
from cephvr.acquisition.v1 import microcontroller_pb2 as _microcontroller_pb2
from cephvr.acquisition.v1 import runtime_pb2 as _runtime_pb2
from cephvr.visual_stimulus.v1 import runtime_pb2 as _runtime_pb2_1
from cephvr.visual_stimulus.v1 import messages_pb2 as _messages_pb2_1
from cephvr.tracking.v1 import methods_pb2 as _methods_pb2
from cephvr.tracking.v1 import preparation_pb2 as _preparation_pb2
from cephvr.synchronization.v1 import spikeglx_pb2 as _spikeglx_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CameraCommandKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_COMMAND_KIND_UNSPECIFIED: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_START_PREVIEW: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_STOP_PREVIEW: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_IMPORT_PFS: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_EXPORT_PFS: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_FINISH_EDITING: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_ATTACH_PREVIEW_VIEWER: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_TEST_CONNECTION: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_SHOW_PREVIEW: _ClassVar[CameraCommandKind]
    CAMERA_COMMAND_KIND_HIDE_PREVIEW: _ClassVar[CameraCommandKind]

class MicrocontrollerCommandKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MICROCONTROLLER_COMMAND_KIND_UNSPECIFIED: _ClassVar[MicrocontrollerCommandKind]
    MICROCONTROLLER_COMMAND_KIND_CONNECT: _ClassVar[MicrocontrollerCommandKind]
    MICROCONTROLLER_COMMAND_KIND_START: _ClassVar[MicrocontrollerCommandKind]
    MICROCONTROLLER_COMMAND_KIND_STATUS: _ClassVar[MicrocontrollerCommandKind]
    MICROCONTROLLER_COMMAND_KIND_STOP: _ClassVar[MicrocontrollerCommandKind]
    MICROCONTROLLER_COMMAND_KIND_UPLOAD_FIRMWARE: _ClassVar[MicrocontrollerCommandKind]

class PreviewConsumerResult(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PREVIEW_CONSUMER_RESULT_UNSPECIFIED: _ClassVar[PreviewConsumerResult]
    PREVIEW_CONSUMER_RESULT_ATTACHED: _ClassVar[PreviewConsumerResult]
    PREVIEW_CONSUMER_RESULT_RELEASED: _ClassVar[PreviewConsumerResult]
    PREVIEW_CONSUMER_RESULT_FAILED: _ClassVar[PreviewConsumerResult]

class RecoveryAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RECOVERY_ACTION_UNSPECIFIED: _ClassVar[RecoveryAction]
    RECOVERY_ACTION_RETRY_GRACEFUL_CLEANUP: _ClassVar[RecoveryAction]

class LaunchPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    LAUNCH_PHASE_UNSPECIFIED: _ClassVar[LaunchPhase]
    LAUNCH_PHASE_PLANNED: _ClassVar[LaunchPhase]
    LAUNCH_PHASE_OS_CONFIRMED: _ClassVar[LaunchPhase]
    LAUNCH_PHASE_OPERATIONAL: _ClassVar[LaunchPhase]
    LAUNCH_PHASE_CLEANUP_REQUIRED: _ClassVar[LaunchPhase]
    LAUNCH_PHASE_RELEASED: _ClassVar[LaunchPhase]

class MicrocontrollerIoKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MICROCONTROLLER_IO_KIND_UNSPECIFIED: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_CONNECT: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_CONFIGURE: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_STATUS: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_ON: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_OFF: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_RESERVE: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_CANCEL_ON: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_CANCEL_ACTIVE: _ClassVar[MicrocontrollerIoKind]
    MICROCONTROLLER_IO_KIND_CLOSE: _ClassVar[MicrocontrollerIoKind]
CAMERA_COMMAND_KIND_UNSPECIFIED: CameraCommandKind
CAMERA_COMMAND_KIND_START_PREVIEW: CameraCommandKind
CAMERA_COMMAND_KIND_STOP_PREVIEW: CameraCommandKind
CAMERA_COMMAND_KIND_IMPORT_PFS: CameraCommandKind
CAMERA_COMMAND_KIND_EXPORT_PFS: CameraCommandKind
CAMERA_COMMAND_KIND_FINISH_EDITING: CameraCommandKind
CAMERA_COMMAND_KIND_ATTACH_PREVIEW_VIEWER: CameraCommandKind
CAMERA_COMMAND_KIND_TEST_CONNECTION: CameraCommandKind
CAMERA_COMMAND_KIND_SHOW_PREVIEW: CameraCommandKind
CAMERA_COMMAND_KIND_HIDE_PREVIEW: CameraCommandKind
MICROCONTROLLER_COMMAND_KIND_UNSPECIFIED: MicrocontrollerCommandKind
MICROCONTROLLER_COMMAND_KIND_CONNECT: MicrocontrollerCommandKind
MICROCONTROLLER_COMMAND_KIND_START: MicrocontrollerCommandKind
MICROCONTROLLER_COMMAND_KIND_STATUS: MicrocontrollerCommandKind
MICROCONTROLLER_COMMAND_KIND_STOP: MicrocontrollerCommandKind
MICROCONTROLLER_COMMAND_KIND_UPLOAD_FIRMWARE: MicrocontrollerCommandKind
PREVIEW_CONSUMER_RESULT_UNSPECIFIED: PreviewConsumerResult
PREVIEW_CONSUMER_RESULT_ATTACHED: PreviewConsumerResult
PREVIEW_CONSUMER_RESULT_RELEASED: PreviewConsumerResult
PREVIEW_CONSUMER_RESULT_FAILED: PreviewConsumerResult
RECOVERY_ACTION_UNSPECIFIED: RecoveryAction
RECOVERY_ACTION_RETRY_GRACEFUL_CLEANUP: RecoveryAction
LAUNCH_PHASE_UNSPECIFIED: LaunchPhase
LAUNCH_PHASE_PLANNED: LaunchPhase
LAUNCH_PHASE_OS_CONFIRMED: LaunchPhase
LAUNCH_PHASE_OPERATIONAL: LaunchPhase
LAUNCH_PHASE_CLEANUP_REQUIRED: LaunchPhase
LAUNCH_PHASE_RELEASED: LaunchPhase
MICROCONTROLLER_IO_KIND_UNSPECIFIED: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_CONNECT: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_CONFIGURE: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_STATUS: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_ON: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_OFF: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_RESERVE: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_CANCEL_ON: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_CANCEL_ACTIVE: MicrocontrollerIoKind
MICROCONTROLLER_IO_KIND_CLOSE: MicrocontrollerIoKind

class OpenDisplayCalibrationRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "diagnostic_id", "profile_asset_reference", "arena_asset_reference", "expected_profile_sha256", "expected_arena_sha256")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    PROFILE_ASSET_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    ARENA_ASSET_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_PROFILE_SHA256_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_ARENA_SHA256_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    diagnostic_id: str
    profile_asset_reference: str
    arena_asset_reference: str
    expected_profile_sha256: str
    expected_arena_sha256: str
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., profile_asset_reference: _Optional[str] = ..., arena_asset_reference: _Optional[str] = ..., expected_profile_sha256: _Optional[str] = ..., expected_arena_sha256: _Optional[str] = ...) -> None: ...

class UpdateDisplayCalibrationRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "diagnostic_id", "adjustment_sequence", "adjustments")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    ADJUSTMENT_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ADJUSTMENTS_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    diagnostic_id: str
    adjustment_sequence: int
    adjustments: _containers.RepeatedCompositeFieldContainer[_messages_pb2_1.DisplayCalibrationAdjustment]
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., adjustment_sequence: _Optional[int] = ..., adjustments: _Optional[_Iterable[_Union[_messages_pb2_1.DisplayCalibrationAdjustment, _Mapping]]] = ...) -> None: ...

class VisualStimulusDisplayCalibrationUpdateRequest(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "configuration_revision", "diagnostic_id", "deadline_monotonic_ns", "adjustment_sequence", "adjustments")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ADJUSTMENT_SEQUENCE_FIELD_NUMBER: _ClassVar[int]
    ADJUSTMENTS_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: _types_pb2.BackendContext
    configuration_revision: int
    diagnostic_id: str
    deadline_monotonic_ns: int
    adjustment_sequence: int
    adjustments: _containers.RepeatedCompositeFieldContainer[_messages_pb2_1.DisplayCalibrationAdjustment]
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., deadline_monotonic_ns: _Optional[int] = ..., adjustment_sequence: _Optional[int] = ..., adjustments: _Optional[_Iterable[_Union[_messages_pb2_1.DisplayCalibrationAdjustment, _Mapping]]] = ...) -> None: ...

class CloseDisplayCalibrationRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "diagnostic_id")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    diagnostic_id: str
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ...) -> None: ...

class VisualStimulusDisplayCalibrationOpenRequest(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "configuration_revision", "diagnostic_id", "deadline_monotonic_ns", "profile_json", "profile_sha256", "asset_root", "arena_relative_path", "arena_size_bytes", "arena_sha256", "policies")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    PROFILE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROFILE_SHA256_FIELD_NUMBER: _ClassVar[int]
    ASSET_ROOT_FIELD_NUMBER: _ClassVar[int]
    ARENA_RELATIVE_PATH_FIELD_NUMBER: _ClassVar[int]
    ARENA_SIZE_BYTES_FIELD_NUMBER: _ClassVar[int]
    ARENA_SHA256_FIELD_NUMBER: _ClassVar[int]
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: _types_pb2.BackendContext
    configuration_revision: int
    diagnostic_id: str
    deadline_monotonic_ns: int
    profile_json: str
    profile_sha256: str
    asset_root: str
    arena_relative_path: str
    arena_size_bytes: int
    arena_sha256: str
    policies: _runtime_pb2_1.VisualStimulusFilePolicies
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., deadline_monotonic_ns: _Optional[int] = ..., profile_json: _Optional[str] = ..., profile_sha256: _Optional[str] = ..., asset_root: _Optional[str] = ..., arena_relative_path: _Optional[str] = ..., arena_size_bytes: _Optional[int] = ..., arena_sha256: _Optional[str] = ..., policies: _Optional[_Union[_runtime_pb2_1.VisualStimulusFilePolicies, _Mapping]] = ...) -> None: ...

class VisualStimulusDisplayCalibrationCloseRequest(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "configuration_revision", "diagnostic_id", "deadline_monotonic_ns")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: _types_pb2.BackendContext
    configuration_revision: int
    diagnostic_id: str
    deadline_monotonic_ns: int
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., deadline_monotonic_ns: _Optional[int] = ...) -> None: ...

class VisualStimulusDisplayInitializationRequest(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "configuration_revision", "display", "limits", "policies", "deadline_monotonic_ns", "asset_root", "pacing_refresh_hz", "pacing_output_id")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_FIELD_NUMBER: _ClassVar[int]
    LIMITS_FIELD_NUMBER: _ClassVar[int]
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ASSET_ROOT_FIELD_NUMBER: _ClassVar[int]
    PACING_REFRESH_HZ_FIELD_NUMBER: _ClassVar[int]
    PACING_OUTPUT_ID_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: _types_pb2.BackendContext
    configuration_revision: int
    display: _runtime_pb2_1.DisplayConfiguration
    limits: _runtime_pb2_1.ResourceLimits
    policies: _types_pb2.ControlPolicies
    deadline_monotonic_ns: int
    asset_root: str
    pacing_refresh_hz: float
    pacing_output_id: str
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., display: _Optional[_Union[_runtime_pb2_1.DisplayConfiguration, _Mapping]] = ..., limits: _Optional[_Union[_runtime_pb2_1.ResourceLimits, _Mapping]] = ..., policies: _Optional[_Union[_types_pb2.ControlPolicies, _Mapping]] = ..., deadline_monotonic_ns: _Optional[int] = ..., asset_root: _Optional[str] = ..., pacing_refresh_hz: _Optional[float] = ..., pacing_output_id: _Optional[str] = ...) -> None: ...

class SpikeGLXInventoryRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ...) -> None: ...

class SpikeGLXInventorySnapshot(_message.Message):
    __slots__ = ("configuration_revision", "file_sha256", "pulse_channels", "backend_enabled", "address", "command_port")
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    FILE_SHA256_FIELD_NUMBER: _ClassVar[int]
    PULSE_CHANNELS_FIELD_NUMBER: _ClassVar[int]
    BACKEND_ENABLED_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    COMMAND_PORT_FIELD_NUMBER: _ClassVar[int]
    configuration_revision: int
    file_sha256: str
    pulse_channels: _containers.RepeatedCompositeFieldContainer[_spikeglx_pb2.PulseChannel]
    backend_enabled: bool
    address: str
    command_port: int
    def __init__(self, configuration_revision: _Optional[int] = ..., file_sha256: _Optional[str] = ..., pulse_channels: _Optional[_Iterable[_Union[_spikeglx_pb2.PulseChannel, _Mapping]]] = ..., backend_enabled: _Optional[bool] = ..., address: _Optional[str] = ..., command_port: _Optional[int] = ...) -> None: ...

class SpikeGLXInventoryUpdateRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "expected_file_sha256", "pulse_channels")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_FILE_SHA256_FIELD_NUMBER: _ClassVar[int]
    PULSE_CHANNELS_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    expected_file_sha256: str
    pulse_channels: _containers.RepeatedCompositeFieldContainer[_spikeglx_pb2.PulseChannel]
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., expected_file_sha256: _Optional[str] = ..., pulse_channels: _Optional[_Iterable[_Union[_spikeglx_pb2.PulseChannel, _Mapping]]] = ...) -> None: ...

class BeginTrackingDiagnosticRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "preview_run_id", "selected_stages", "diagnostic_settings")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SELECTED_STAGES_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    preview_run_id: str
    selected_stages: _containers.RepeatedScalarFieldContainer[_types_pb2.TrackingDiagnosticStage]
    diagnostic_settings: _types_pb2.TrackingSettings
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., selected_stages: _Optional[_Iterable[_Union[_types_pb2.TrackingDiagnosticStage, str]]] = ..., diagnostic_settings: _Optional[_Union[_types_pb2.TrackingSettings, _Mapping]] = ...) -> None: ...

class CloseTrackingDiagnosticRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "diagnostic_id", "preview_run_id")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    diagnostic_id: str
    preview_run_id: str
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., preview_run_id: _Optional[str] = ...) -> None: ...

class TrackingDiagnosticQuery(_message.Message):
    __slots__ = ("client_id", "controller_generation", "configuration_revision", "diagnostic_id", "preview_run_id", "viewer")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    VIEWER_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    controller_generation: str
    configuration_revision: int
    diagnostic_id: str
    preview_run_id: str
    viewer: _types_pb2.ProcessIdentity
    def __init__(self, client_id: _Optional[str] = ..., controller_generation: _Optional[str] = ..., configuration_revision: _Optional[int] = ..., diagnostic_id: _Optional[str] = ..., preview_run_id: _Optional[str] = ..., viewer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ...) -> None: ...

class AcquisitionTrackingDiagnosticAttachmentCommand(_message.Message):
    __slots__ = ("command", "configuration_revision", "preview_run_id", "tracking_consumer")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    TRACKING_CONSUMER_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    preview_run_id: str
    tracking_consumer: _types_pb2.ProcessIdentity
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., tracking_consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ...) -> None: ...

class MicrocontrollerCommandRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "kind", "signal", "firmware_path", "firmware_sha256")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_FIELD_NUMBER: _ClassVar[int]
    FIRMWARE_PATH_FIELD_NUMBER: _ClassVar[int]
    FIRMWARE_SHA256_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    kind: MicrocontrollerCommandKind
    signal: _types_pb2.MicrocontrollerSignalKind
    firmware_path: str
    firmware_sha256: str
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., kind: _Optional[_Union[MicrocontrollerCommandKind, str]] = ..., signal: _Optional[_Union[_types_pb2.MicrocontrollerSignalKind, str]] = ..., firmware_path: _Optional[str] = ..., firmware_sha256: _Optional[str] = ...) -> None: ...

class SpikeGLXConnectionQuery(_message.Message):
    __slots__ = ("client_id",)
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    def __init__(self, client_id: _Optional[str] = ...) -> None: ...

class SpikeGLXConnectionResult(_message.Message):
    __slots__ = ("connected", "address", "port", "version", "running", "saving", "run_name", "data_directory", "error")
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    SAVING_FIELD_NUMBER: _ClassVar[int]
    RUN_NAME_FIELD_NUMBER: _ClassVar[int]
    DATA_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    connected: bool
    address: str
    port: int
    version: str
    running: bool
    saving: bool
    run_name: str
    data_directory: str
    error: str
    def __init__(self, connected: _Optional[bool] = ..., address: _Optional[str] = ..., port: _Optional[int] = ..., version: _Optional[str] = ..., running: _Optional[bool] = ..., saving: _Optional[bool] = ..., run_name: _Optional[str] = ..., data_directory: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class AcquisitionMicrocontrollerCommand(_message.Message):
    __slots__ = ("command", "configuration_revision", "kind", "signal", "requested", "settings", "firmware_path", "firmware_sha256")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    FIRMWARE_PATH_FIELD_NUMBER: _ClassVar[int]
    FIRMWARE_SHA256_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    kind: MicrocontrollerCommandKind
    signal: _types_pb2.MicrocontrollerSignalKind
    requested: _camera_pb2.CameraPulseConfiguration
    settings: _types_pb2.AcquisitionSettings
    firmware_path: str
    firmware_sha256: str
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., kind: _Optional[_Union[MicrocontrollerCommandKind, str]] = ..., signal: _Optional[_Union[_types_pb2.MicrocontrollerSignalKind, str]] = ..., requested: _Optional[_Union[_camera_pb2.CameraPulseConfiguration, _Mapping]] = ..., settings: _Optional[_Union[_types_pb2.AcquisitionSettings, _Mapping]] = ..., firmware_path: _Optional[str] = ..., firmware_sha256: _Optional[str] = ...) -> None: ...

class PreviewWindowPlacement(_message.Message):
    __slots__ = ("x", "y", "side")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    SIDE_FIELD_NUMBER: _ClassVar[int]
    x: int
    y: int
    side: int
    def __init__(self, x: _Optional[int] = ..., y: _Optional[int] = ..., side: _Optional[int] = ...) -> None: ...

class CameraCommandRequest(_message.Message):
    __slots__ = ("command", "expected_configuration_revision", "camera", "kind", "path", "preview_run_id", "preview_consumer", "preview_placement")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_CONSUMER_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_PLACEMENT_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_configuration_revision: int
    camera: _camera_pb2.CameraRole
    kind: CameraCommandKind
    path: str
    preview_run_id: str
    preview_consumer: _types_pb2.ProcessIdentity
    preview_placement: PreviewWindowPlacement
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_configuration_revision: _Optional[int] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., kind: _Optional[_Union[CameraCommandKind, str]] = ..., path: _Optional[str] = ..., preview_run_id: _Optional[str] = ..., preview_consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., preview_placement: _Optional[_Union[PreviewWindowPlacement, _Mapping]] = ...) -> None: ...

class AcquisitionCameraCommand(_message.Message):
    __slots__ = ("command", "configuration_revision", "camera", "kind", "path", "preview_run_id", "requested", "transport", "preview_consumer", "file_policies", "preview_output_bit_depth", "settings", "preview_placement")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_CONSUMER_FIELD_NUMBER: _ClassVar[int]
    FILE_POLICIES_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_OUTPUT_BIT_DEPTH_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_PLACEMENT_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    camera: _camera_pb2.CameraRole
    kind: CameraCommandKind
    path: str
    preview_run_id: str
    requested: _camera_pb2.CameraDeviceConfiguration
    transport: _camera_pb2.CameraTransportSettings
    preview_consumer: _types_pb2.ProcessIdentity
    file_policies: _runtime_pb2.AcquisitionFilePolicies
    preview_output_bit_depth: int
    settings: _types_pb2.AcquisitionSettings
    preview_placement: PreviewWindowPlacement
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., kind: _Optional[_Union[CameraCommandKind, str]] = ..., path: _Optional[str] = ..., preview_run_id: _Optional[str] = ..., requested: _Optional[_Union[_camera_pb2.CameraDeviceConfiguration, _Mapping]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ..., preview_consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., file_policies: _Optional[_Union[_runtime_pb2.AcquisitionFilePolicies, _Mapping]] = ..., preview_output_bit_depth: _Optional[int] = ..., settings: _Optional[_Union[_types_pb2.AcquisitionSettings, _Mapping]] = ..., preview_placement: _Optional[_Union[PreviewWindowPlacement, _Mapping]] = ...) -> None: ...

class CameraSettingsApplication(_message.Message):
    __slots__ = ("camera", "requested", "transport")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    camera: _camera_pb2.CameraRole
    requested: _camera_pb2.CameraDeviceConfiguration
    transport: _camera_pb2.CameraTransportSettings
    def __init__(self, camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., requested: _Optional[_Union[_camera_pb2.CameraDeviceConfiguration, _Mapping]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ...) -> None: ...

class AcquisitionCameraSettingsCommand(_message.Message):
    __slots__ = ("command", "configuration_revision", "cameras", "pulses", "file_policies", "accepted_base_revision", "accepted_base_settings")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CAMERAS_FIELD_NUMBER: _ClassVar[int]
    PULSES_FIELD_NUMBER: _ClassVar[int]
    FILE_POLICIES_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_BASE_REVISION_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_BASE_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    cameras: _containers.RepeatedCompositeFieldContainer[CameraSettingsApplication]
    pulses: PulseSettingsApplication
    file_policies: _runtime_pb2.AcquisitionFilePolicies
    accepted_base_revision: int
    accepted_base_settings: _types_pb2.AcquisitionSettings
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., cameras: _Optional[_Iterable[_Union[CameraSettingsApplication, _Mapping]]] = ..., pulses: _Optional[_Union[PulseSettingsApplication, _Mapping]] = ..., file_policies: _Optional[_Union[_runtime_pb2.AcquisitionFilePolicies, _Mapping]] = ..., accepted_base_revision: _Optional[int] = ..., accepted_base_settings: _Optional[_Union[_types_pb2.AcquisitionSettings, _Mapping]] = ...) -> None: ...

class PulseSettingsApplication(_message.Message):
    __slots__ = ("requested", "behavioral_active", "tracking_active")
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    TRACKING_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    requested: _camera_pb2.CameraPulseConfiguration
    behavioral_active: bool
    tracking_active: bool
    def __init__(self, requested: _Optional[_Union[_camera_pb2.CameraPulseConfiguration, _Mapping]] = ..., behavioral_active: _Optional[bool] = ..., tracking_active: _Optional[bool] = ...) -> None: ...

class AcquisitionPulseCommand(_message.Message):
    __slots__ = ("command", "configuration_revision", "application", "file_policies")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    APPLICATION_FIELD_NUMBER: _ClassVar[int]
    FILE_POLICIES_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    application: PulseSettingsApplication
    file_policies: _runtime_pb2.AcquisitionFilePolicies
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., application: _Optional[_Union[PulseSettingsApplication, _Mapping]] = ..., file_policies: _Optional[_Union[_runtime_pb2.AcquisitionFilePolicies, _Mapping]] = ...) -> None: ...

class PreviewAttachmentQuery(_message.Message):
    __slots__ = ("client_id", "controller_generation", "consumer", "preview_run_id")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    CONSUMER_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    controller_generation: str
    consumer: _types_pb2.ProcessIdentity
    preview_run_id: str
    def __init__(self, client_id: _Optional[str] = ..., controller_generation: _Optional[str] = ..., consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., preview_run_id: _Optional[str] = ...) -> None: ...

class PreviewAttachmentResult(_message.Message):
    __slots__ = ("available", "attachment", "failure", "release_only")
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    RELEASE_ONLY_FIELD_NUMBER: _ClassVar[int]
    available: bool
    attachment: _messages_pb2.FrameBufferAttachment
    failure: _types_pb2.Failure
    release_only: bool
    def __init__(self, available: _Optional[bool] = ..., attachment: _Optional[_Union[_messages_pb2.FrameBufferAttachment, _Mapping]] = ..., failure: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ..., release_only: _Optional[bool] = ...) -> None: ...

class PreviewAttachmentReport(_message.Message):
    __slots__ = ("source", "operation", "attachment")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    source: _types_pb2.BackendContext
    operation: _types_pb2.OperationContext
    attachment: _messages_pb2.FrameBufferAttachment
    def __init__(self, source: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., attachment: _Optional[_Union[_messages_pb2.FrameBufferAttachment, _Mapping]] = ...) -> None: ...

class PreviewConsumerReport(_message.Message):
    __slots__ = ("client_id", "controller_generation", "consumer", "preview_run_id", "allocation_id", "transfer_id", "result", "failure")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    CONSUMER_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSFER_ID_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    controller_generation: str
    consumer: _types_pb2.ProcessIdentity
    preview_run_id: str
    allocation_id: str
    transfer_id: str
    result: PreviewConsumerResult
    failure: _types_pb2.Failure
    def __init__(self, client_id: _Optional[str] = ..., controller_generation: _Optional[str] = ..., consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., preview_run_id: _Optional[str] = ..., allocation_id: _Optional[str] = ..., transfer_id: _Optional[str] = ..., result: _Optional[_Union[PreviewConsumerResult, str]] = ..., failure: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class CameraResolutionEntry(_message.Message):
    __slots__ = ("camera", "result")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    camera: _camera_pb2.CameraRole
    result: _camera_pb2.CameraResolvedState
    def __init__(self, camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., result: _Optional[_Union[_camera_pb2.CameraResolvedState, _Mapping]] = ...) -> None: ...

class AcquisitionResolutionReport(_message.Message):
    __slots__ = ("source", "work", "operation", "requested_configuration_revision", "cameras", "pulses")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CAMERAS_FIELD_NUMBER: _ClassVar[int]
    PULSES_FIELD_NUMBER: _ClassVar[int]
    source: _types_pb2.BackendContext
    work: _types_pb2.WorkContext
    operation: _types_pb2.OperationContext
    requested_configuration_revision: int
    cameras: _containers.RepeatedCompositeFieldContainer[CameraResolutionEntry]
    pulses: _microcontroller_pb2.PulseConfigurationResolution
    def __init__(self, source: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., requested_configuration_revision: _Optional[int] = ..., cameras: _Optional[_Iterable[_Union[CameraResolutionEntry, _Mapping]]] = ..., pulses: _Optional[_Union[_microcontroller_pb2.PulseConfigurationResolution, _Mapping]] = ...) -> None: ...

class AcquisitionConfigurationConfirmation(_message.Message):
    __slots__ = ("command", "resolution_operation", "requested_configuration_revision", "confirmed_configuration_revision", "confirmed", "confirmed_pulses")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_OPERATION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONFIRMED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    CONFIRMED_PULSES_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    resolution_operation: _types_pb2.OperationContext
    requested_configuration_revision: int
    confirmed_configuration_revision: int
    confirmed: _types_pb2.AcquisitionSettings
    confirmed_pulses: _microcontroller_pb2.PulseConfigurationResolution
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., resolution_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., requested_configuration_revision: _Optional[int] = ..., confirmed_configuration_revision: _Optional[int] = ..., confirmed: _Optional[_Union[_types_pb2.AcquisitionSettings, _Mapping]] = ..., confirmed_pulses: _Optional[_Union[_microcontroller_pb2.PulseConfigurationResolution, _Mapping]] = ...) -> None: ...

class AcquisitionWarningReport(_message.Message):
    __slots__ = ("source", "view")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    source: _types_pb2.BackendContext
    view: _types_pb2.AcquisitionWarningView
    def __init__(self, source: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., view: _Optional[_Union[_types_pb2.AcquisitionWarningView, _Mapping]] = ...) -> None: ...

class AcquisitionDeviceStatusReport(_message.Message):
    __slots__ = ("views", "work", "operation", "result", "exported_pfs_path", "preview_visibility")
    VIEWS_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    RESULT_FIELD_NUMBER: _ClassVar[int]
    EXPORTED_PFS_PATH_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_VISIBILITY_FIELD_NUMBER: _ClassVar[int]
    views: _types_pb2.AcquisitionDeviceViews
    work: _types_pb2.WorkContext
    operation: _types_pb2.OperationContext
    result: _types_pb2.OperationState
    exported_pfs_path: str
    preview_visibility: CameraPreviewVisibility
    def __init__(self, views: _Optional[_Union[_types_pb2.AcquisitionDeviceViews, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., result: _Optional[_Union[_types_pb2.OperationState, _Mapping]] = ..., exported_pfs_path: _Optional[str] = ..., preview_visibility: _Optional[_Union[CameraPreviewVisibility, _Mapping]] = ...) -> None: ...

class CameraPreviewVisibility(_message.Message):
    __slots__ = ("camera", "preview_run_id", "revision", "visible", "observed_monotonic_ns", "failure")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    VISIBLE_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    camera: _camera_pb2.CameraRole
    preview_run_id: str
    revision: int
    visible: bool
    observed_monotonic_ns: int
    failure: str
    def __init__(self, camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., preview_run_id: _Optional[str] = ..., revision: _Optional[int] = ..., visible: _Optional[bool] = ..., observed_monotonic_ns: _Optional[int] = ..., failure: _Optional[str] = ...) -> None: ...

class SnapshotRequest(_message.Message):
    __slots__ = ("client_id",)
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    def __init__(self, client_id: _Optional[str] = ...) -> None: ...

class WatchRequest(_message.Message):
    __slots__ = ("client_id", "watch_id")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    WATCH_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    watch_id: str
    def __init__(self, client_id: _Optional[str] = ..., watch_id: _Optional[str] = ...) -> None: ...

class OperatorCommand(_message.Message):
    __slots__ = ("operator", "controller_generation", "expected_work")
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_WORK_FIELD_NUMBER: _ClassVar[int]
    operator: _types_pb2.OperatorContext
    controller_generation: str
    expected_work: _types_pb2.WorkContext
    def __init__(self, operator: _Optional[_Union[_types_pb2.OperatorContext, _Mapping]] = ..., controller_generation: _Optional[str] = ..., expected_work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ...) -> None: ...

class ControlClaim(_message.Message):
    __slots__ = ("client_id", "command_id", "controller_generation", "session_id", "synchronized_state_revision", "watch_id")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    SYNCHRONIZED_STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    WATCH_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    command_id: str
    controller_generation: str
    session_id: str
    synchronized_state_revision: int
    watch_id: str
    def __init__(self, client_id: _Optional[str] = ..., command_id: _Optional[str] = ..., controller_generation: _Optional[str] = ..., session_id: _Optional[str] = ..., synchronized_state_revision: _Optional[int] = ..., watch_id: _Optional[str] = ...) -> None: ...

class UpdateConfigurationRequest(_message.Message):
    __slots__ = ("command", "expected_revision", "proposed")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    PROPOSED_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    expected_revision: int
    proposed: _types_pb2.ExperimentConfiguration
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., expected_revision: _Optional[int] = ..., proposed: _Optional[_Union[_types_pb2.ExperimentConfiguration, _Mapping]] = ...) -> None: ...

class PromptResponse(_message.Message):
    __slots__ = ("command", "prompt_id", "setup", "setup_operation", "choice", "expected_incident_revision")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    PROMPT_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_FIELD_NUMBER: _ClassVar[int]
    SETUP_OPERATION_FIELD_NUMBER: _ClassVar[int]
    CHOICE_FIELD_NUMBER: _ClassVar[int]
    EXPECTED_INCIDENT_REVISION_FIELD_NUMBER: _ClassVar[int]
    command: OperatorCommand
    prompt_id: str
    setup: _types_pb2.SessionContext
    setup_operation: _types_pb2.OperationContext
    choice: str
    expected_incident_revision: int
    def __init__(self, command: _Optional[_Union[OperatorCommand, _Mapping]] = ..., prompt_id: _Optional[str] = ..., setup: _Optional[_Union[_types_pb2.SessionContext, _Mapping]] = ..., setup_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., choice: _Optional[str] = ..., expected_incident_revision: _Optional[int] = ...) -> None: ...

class IncidentScopeRequest(_message.Message):
    __slots__ = ("command", "incident")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    INCIDENT_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    incident: _types_pb2.RuntimeIncident
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., incident: _Optional[_Union[_types_pb2.RuntimeIncident, _Mapping]] = ...) -> None: ...

class BackendCommand(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "work", "parent_operation")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    PARENT_OPERATION_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: _types_pb2.BackendContext
    work: _types_pb2.WorkContext
    parent_operation: _types_pb2.OperationContext
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., parent_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ...) -> None: ...

class SetupSessionRequest(_message.Message):
    __slots__ = ("command", "plan", "settings", "acquisition_policies", "visual_stimulus_policies", "tracking_policies", "feedback_attachment", "feedback_consumer")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_POLICIES_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_POLICIES_FIELD_NUMBER: _ClassVar[int]
    TRACKING_POLICIES_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_ATTACHMENT_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_CONSUMER_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    plan: _types_pb2.PreparedSession
    settings: _types_pb2.BackendSettings
    acquisition_policies: _runtime_pb2.AcquisitionFilePolicies
    visual_stimulus_policies: _runtime_pb2_1.VisualStimulusFilePolicies
    tracking_policies: _methods_pb2.TrackingFilePolicies
    feedback_attachment: _runtime_pb2_1.FeedbackAttachment
    feedback_consumer: _types_pb2.ProcessIdentity
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., plan: _Optional[_Union[_types_pb2.PreparedSession, _Mapping]] = ..., settings: _Optional[_Union[_types_pb2.BackendSettings, _Mapping]] = ..., acquisition_policies: _Optional[_Union[_runtime_pb2.AcquisitionFilePolicies, _Mapping]] = ..., visual_stimulus_policies: _Optional[_Union[_runtime_pb2_1.VisualStimulusFilePolicies, _Mapping]] = ..., tracking_policies: _Optional[_Union[_methods_pb2.TrackingFilePolicies, _Mapping]] = ..., feedback_attachment: _Optional[_Union[_runtime_pb2_1.FeedbackAttachment, _Mapping]] = ..., feedback_consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ...) -> None: ...

class PrepareTrialRequest(_message.Message):
    __slots__ = ("command", "configuration_revision", "plan", "outputs")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PLAN_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    plan: _types_pb2.TrialPlan
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputPlan]
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., plan: _Optional[_Union[_types_pb2.TrialPlan, _Mapping]] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputPlan, _Mapping]]] = ...) -> None: ...

class ScheduleTrialRequest(_message.Message):
    __slots__ = ("command", "start_monotonic_ns", "normal_end_monotonic_ns", "trial_file_prefix", "outputs")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    NORMAL_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FILE_PREFIX_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    start_monotonic_ns: int
    normal_end_monotonic_ns: int
    trial_file_prefix: str
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputPlan]
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., start_monotonic_ns: _Optional[int] = ..., normal_end_monotonic_ns: _Optional[int] = ..., trial_file_prefix: _Optional[str] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputPlan, _Mapping]]] = ...) -> None: ...

class ReleaseTrialRequest(_message.Message):
    __slots__ = ("command", "schedule_operation", "start_monotonic_ns", "normal_end_monotonic_ns")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_OPERATION_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    NORMAL_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    schedule_operation: _types_pb2.OperationContext
    start_monotonic_ns: int
    normal_end_monotonic_ns: int
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., schedule_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., start_monotonic_ns: _Optional[int] = ..., normal_end_monotonic_ns: _Optional[int] = ...) -> None: ...

class StopTrialRequest(_message.Message):
    __slots__ = ("command", "issued_monotonic_ns", "reason")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    issued_monotonic_ns: int
    reason: _types_pb2.Failure
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ..., reason: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class InterruptSessionRequest(_message.Message):
    __slots__ = ("command", "issued_monotonic_ns", "reason")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    issued_monotonic_ns: int
    reason: _types_pb2.Failure
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ..., reason: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class BackendQuery(_message.Message):
    __slots__ = ("target", "work")
    TARGET_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    target: _types_pb2.BackendContext
    work: _types_pb2.WorkContext
    def __init__(self, target: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ...) -> None: ...

class RetainedResultQuery(_message.Message):
    __slots__ = ("query", "command_id")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    query: BackendQuery
    command_id: str
    def __init__(self, query: _Optional[_Union[BackendQuery, _Mapping]] = ..., command_id: _Optional[str] = ...) -> None: ...

class RetainedResult(_message.Message):
    __slots__ = ("found", "backend", "work", "admission", "operation", "ready", "started", "stopped", "finished", "outputs", "acquisition_resolution", "acquisition_device_result", "data_preparation")
    FOUND_FIELD_NUMBER: _ClassVar[int]
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    READY_FIELD_NUMBER: _ClassVar[int]
    STARTED_FIELD_NUMBER: _ClassVar[int]
    STOPPED_FIELD_NUMBER: _ClassVar[int]
    FINISHED_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_DEVICE_RESULT_FIELD_NUMBER: _ClassVar[int]
    DATA_PREPARATION_FIELD_NUMBER: _ClassVar[int]
    found: bool
    backend: _types_pb2.BackendContext
    work: _types_pb2.WorkContext
    admission: _types_pb2.CommandAdmission
    operation: _types_pb2.OperationState
    ready: _types_pb2.ReadyReport
    started: _types_pb2.StartedReport
    stopped: _types_pb2.StoppedReport
    finished: _types_pb2.FinishedReport
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputResult]
    acquisition_resolution: AcquisitionResolutionReport
    acquisition_device_result: AcquisitionDeviceStatusReport
    data_preparation: DataPreparationReport
    def __init__(self, found: _Optional[bool] = ..., backend: _Optional[_Union[_types_pb2.BackendContext, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., admission: _Optional[_Union[_types_pb2.CommandAdmission, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationState, _Mapping]] = ..., ready: _Optional[_Union[_types_pb2.ReadyReport, _Mapping]] = ..., started: _Optional[_Union[_types_pb2.StartedReport, _Mapping]] = ..., stopped: _Optional[_Union[_types_pb2.StoppedReport, _Mapping]] = ..., finished: _Optional[_Union[_types_pb2.FinishedReport, _Mapping]] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputResult, _Mapping]]] = ..., acquisition_resolution: _Optional[_Union[AcquisitionResolutionReport, _Mapping]] = ..., acquisition_device_result: _Optional[_Union[AcquisitionDeviceStatusReport, _Mapping]] = ..., data_preparation: _Optional[_Union[DataPreparationReport, _Mapping]] = ...) -> None: ...

class RegisteredContext(_message.Message):
    __slots__ = ("controller", "supervisor", "work", "operation", "required_participants", "session_directory", "outputs", "policies", "continuation_incidents", "prepared_functions", "cleanup_resources", "cleanup_commands", "paired_spikeglx")
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_PARTICIPANTS_FIELD_NUMBER: _ClassVar[int]
    SESSION_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    CONTINUATION_INCIDENTS_FIELD_NUMBER: _ClassVar[int]
    PREPARED_FUNCTIONS_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_RESOURCES_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_COMMANDS_FIELD_NUMBER: _ClassVar[int]
    PAIRED_SPIKEGLX_FIELD_NUMBER: _ClassVar[int]
    controller: _types_pb2.ProcessIdentity
    supervisor: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    operation: _types_pb2.OperationContext
    required_participants: _containers.RepeatedCompositeFieldContainer[_types_pb2.BackendContext]
    session_directory: str
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputPlan]
    policies: _types_pb2.ControlPolicies
    continuation_incidents: _containers.RepeatedCompositeFieldContainer[_types_pb2.RuntimeIncident]
    prepared_functions: _containers.RepeatedCompositeFieldContainer[_types_pb2.PreparedFunctionScope]
    cleanup_resources: _containers.RepeatedCompositeFieldContainer[_types_pb2.ResourceObligation]
    cleanup_commands: _containers.RepeatedCompositeFieldContainer[CleanupCommandFence]
    paired_spikeglx: bool
    def __init__(self, controller: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., required_participants: _Optional[_Iterable[_Union[_types_pb2.BackendContext, _Mapping]]] = ..., session_directory: _Optional[str] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputPlan, _Mapping]]] = ..., policies: _Optional[_Union[_types_pb2.ControlPolicies, _Mapping]] = ..., continuation_incidents: _Optional[_Iterable[_Union[_types_pb2.RuntimeIncident, _Mapping]]] = ..., prepared_functions: _Optional[_Iterable[_Union[_types_pb2.PreparedFunctionScope, _Mapping]]] = ..., cleanup_resources: _Optional[_Iterable[_Union[_types_pb2.ResourceObligation, _Mapping]]] = ..., cleanup_commands: _Optional[_Iterable[_Union[CleanupCommandFence, _Mapping]]] = ..., paired_spikeglx: _Optional[bool] = ...) -> None: ...

class CleanupCommandFence(_message.Message):
    __slots__ = ("target", "work", "operation")
    TARGET_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    target: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    operation: _types_pb2.OperationContext
    def __init__(self, target: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ...) -> None: ...

class RegisterContextRequest(_message.Message):
    __slots__ = ("command_id", "context")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    context: RegisteredContext
    def __init__(self, command_id: _Optional[str] = ..., context: _Optional[_Union[RegisteredContext, _Mapping]] = ...) -> None: ...

class RegistrationReceipt(_message.Message):
    __slots__ = ("admission", "registered", "failure")
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    admission: _types_pb2.CommandAdmission
    registered: RegisteredContext
    failure: _types_pb2.Failure
    def __init__(self, admission: _Optional[_Union[_types_pb2.CommandAdmission, _Mapping]] = ..., registered: _Optional[_Union[RegisteredContext, _Mapping]] = ..., failure: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class ApplicationShutdownRequest(_message.Message):
    __slots__ = ("command_id", "controller", "supervisor", "operator", "controller_operation", "work", "issued_monotonic_ns")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_OPERATION_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    controller: _types_pb2.ProcessIdentity
    supervisor: _types_pb2.ProcessIdentity
    operator: _types_pb2.OperatorContext
    controller_operation: _types_pb2.OperationContext
    work: _types_pb2.WorkContext
    issued_monotonic_ns: int
    def __init__(self, command_id: _Optional[str] = ..., controller: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., operator: _Optional[_Union[_types_pb2.OperatorContext, _Mapping]] = ..., controller_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ...) -> None: ...

class ProcessHealthStatus(_message.Message):
    __slots__ = ("process", "process_running", "connected", "health", "last_evidence_monotonic_ns", "software_version", "capabilities", "protocol_package", "last_heartbeat", "launch_owner")
    PROCESS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_RUNNING_FIELD_NUMBER: _ClassVar[int]
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    LAST_EVIDENCE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_VERSION_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_PACKAGE_FIELD_NUMBER: _ClassVar[int]
    LAST_HEARTBEAT_FIELD_NUMBER: _ClassVar[int]
    LAUNCH_OWNER_FIELD_NUMBER: _ClassVar[int]
    process: _types_pb2.ProcessIdentity
    process_running: bool
    connected: bool
    health: str
    last_evidence_monotonic_ns: int
    software_version: str
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    protocol_package: str
    last_heartbeat: _types_pb2.HeartbeatReport
    launch_owner: _types_pb2.ProcessIdentity
    def __init__(self, process: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., process_running: _Optional[bool] = ..., connected: _Optional[bool] = ..., health: _Optional[str] = ..., last_evidence_monotonic_ns: _Optional[int] = ..., software_version: _Optional[str] = ..., capabilities: _Optional[_Iterable[str]] = ..., protocol_package: _Optional[str] = ..., last_heartbeat: _Optional[_Union[_types_pb2.HeartbeatReport, _Mapping]] = ..., launch_owner: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ...) -> None: ...

class SupervisorStatusReport(_message.Message):
    __slots__ = ("supervisor", "controller_generation", "work", "status_revision", "observed_monotonic_ns", "processes", "errors", "warnings", "recoveries", "operations")
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    STATUS_REVISION_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    PROCESSES_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    RECOVERIES_FIELD_NUMBER: _ClassVar[int]
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    supervisor: _types_pb2.ProcessIdentity
    controller_generation: str
    work: _types_pb2.WorkContext
    status_revision: int
    observed_monotonic_ns: int
    processes: _containers.RepeatedCompositeFieldContainer[ProcessHealthStatus]
    errors: _containers.RepeatedCompositeFieldContainer[_types_pb2.ErrorReport]
    warnings: _containers.RepeatedCompositeFieldContainer[_types_pb2.Warning]
    recoveries: _containers.RepeatedCompositeFieldContainer[_types_pb2.RecoveryState]
    operations: _containers.RepeatedCompositeFieldContainer[_types_pb2.OperationState]
    def __init__(self, supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., controller_generation: _Optional[str] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., status_revision: _Optional[int] = ..., observed_monotonic_ns: _Optional[int] = ..., processes: _Optional[_Iterable[_Union[ProcessHealthStatus, _Mapping]]] = ..., errors: _Optional[_Iterable[_Union[_types_pb2.ErrorReport, _Mapping]]] = ..., warnings: _Optional[_Iterable[_Union[_types_pb2.Warning, _Mapping]]] = ..., recoveries: _Optional[_Iterable[_Union[_types_pb2.RecoveryState, _Mapping]]] = ..., operations: _Optional[_Iterable[_Union[_types_pb2.OperationState, _Mapping]]] = ...) -> None: ...

class InterruptionReport(_message.Message):
    __slots__ = ("interruption_id", "supervisor", "controller_generation", "work", "issued_monotonic_ns", "reason", "triggering_error_id")
    INTERRUPTION_ID_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    TRIGGERING_ERROR_ID_FIELD_NUMBER: _ClassVar[int]
    interruption_id: str
    supervisor: _types_pb2.ProcessIdentity
    controller_generation: str
    work: _types_pb2.WorkContext
    issued_monotonic_ns: int
    reason: _types_pb2.Failure
    triggering_error_id: str
    def __init__(self, interruption_id: _Optional[str] = ..., supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., controller_generation: _Optional[str] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ..., reason: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ..., triggering_error_id: _Optional[str] = ...) -> None: ...

class RecoveryQuery(_message.Message):
    __slots__ = ("expected_supervisor", "work", "prior_controller_generation")
    EXPECTED_SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    PRIOR_CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    expected_supervisor: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    prior_controller_generation: str
    def __init__(self, expected_supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., prior_controller_generation: _Optional[str] = ...) -> None: ...

class PriorApplicationExitReceipt(_message.Message):
    __slots__ = ("controller_generation", "supervisor_generation", "observed_monotonic_ns", "all_owned_processes_absent", "format_version")
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_GENERATION_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ALL_OWNED_PROCESSES_ABSENT_FIELD_NUMBER: _ClassVar[int]
    FORMAT_VERSION_FIELD_NUMBER: _ClassVar[int]
    controller_generation: str
    supervisor_generation: str
    observed_monotonic_ns: int
    all_owned_processes_absent: bool
    format_version: int
    def __init__(self, controller_generation: _Optional[str] = ..., supervisor_generation: _Optional[str] = ..., observed_monotonic_ns: _Optional[int] = ..., all_owned_processes_absent: _Optional[bool] = ..., format_version: _Optional[int] = ...) -> None: ...

class RecoverySnapshot(_message.Message):
    __slots__ = ("supervisor", "captured_monotonic_ns", "recoveries", "participants", "operations", "errors", "warnings", "cleanup_blockers", "status_revision", "prior_application_exit")
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    CAPTURED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    RECOVERIES_FIELD_NUMBER: _ClassVar[int]
    PARTICIPANTS_FIELD_NUMBER: _ClassVar[int]
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    STATUS_REVISION_FIELD_NUMBER: _ClassVar[int]
    PRIOR_APPLICATION_EXIT_FIELD_NUMBER: _ClassVar[int]
    supervisor: _types_pb2.ProcessIdentity
    captured_monotonic_ns: int
    recoveries: _containers.RepeatedCompositeFieldContainer[_types_pb2.RecoveryState]
    participants: _containers.RepeatedCompositeFieldContainer[_types_pb2.ParticipantState]
    operations: _containers.RepeatedCompositeFieldContainer[_types_pb2.OperationState]
    errors: _containers.RepeatedCompositeFieldContainer[_types_pb2.ErrorReport]
    warnings: _containers.RepeatedCompositeFieldContainer[_types_pb2.Warning]
    cleanup_blockers: _containers.RepeatedCompositeFieldContainer[_types_pb2.CleanupBlocker]
    status_revision: int
    prior_application_exit: PriorApplicationExitReceipt
    def __init__(self, supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., captured_monotonic_ns: _Optional[int] = ..., recoveries: _Optional[_Iterable[_Union[_types_pb2.RecoveryState, _Mapping]]] = ..., participants: _Optional[_Iterable[_Union[_types_pb2.ParticipantState, _Mapping]]] = ..., operations: _Optional[_Iterable[_Union[_types_pb2.OperationState, _Mapping]]] = ..., errors: _Optional[_Iterable[_Union[_types_pb2.ErrorReport, _Mapping]]] = ..., warnings: _Optional[_Iterable[_Union[_types_pb2.Warning, _Mapping]]] = ..., cleanup_blockers: _Optional[_Iterable[_Union[_types_pb2.CleanupBlocker, _Mapping]]] = ..., status_revision: _Optional[int] = ..., prior_application_exit: _Optional[_Union[PriorApplicationExitReceipt, _Mapping]] = ...) -> None: ...

class RecoveryActionRequest(_message.Message):
    __slots__ = ("command_id", "supervisor", "target", "work", "action", "operator")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    OPERATOR_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    supervisor: _types_pb2.ProcessIdentity
    target: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    action: RecoveryAction
    operator: _types_pb2.OperatorContext
    def __init__(self, command_id: _Optional[str] = ..., supervisor: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., action: _Optional[_Union[RecoveryAction, str]] = ..., operator: _Optional[_Union[_types_pb2.OperatorContext, _Mapping]] = ...) -> None: ...

class PlanLaunchRequest(_message.Message):
    __slots__ = ("command_id", "owner", "child", "work", "parent_operation", "executable", "python_worker", "stop_method")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    CHILD_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    PARENT_OPERATION_FIELD_NUMBER: _ClassVar[int]
    EXECUTABLE_FIELD_NUMBER: _ClassVar[int]
    PYTHON_WORKER_FIELD_NUMBER: _ClassVar[int]
    STOP_METHOD_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    owner: _types_pb2.ProcessIdentity
    child: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    parent_operation: _types_pb2.OperationContext
    executable: str
    python_worker: bool
    stop_method: str
    def __init__(self, command_id: _Optional[str] = ..., owner: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., child: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., parent_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., executable: _Optional[str] = ..., python_worker: _Optional[bool] = ..., stop_method: _Optional[str] = ...) -> None: ...

class ConfirmLaunchRequest(_message.Message):
    __slots__ = ("command_id", "launch_command_id", "owner", "child", "pid", "creation_time_100ns", "endpoint", "creation_failed_without_child", "failure", "host_clock", "native_cleanup_complete", "acquisition_worker_cleanup")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    LAUNCH_COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    CHILD_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    CREATION_TIME_100NS_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    CREATION_FAILED_WITHOUT_CHILD_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    HOST_CLOCK_FIELD_NUMBER: _ClassVar[int]
    NATIVE_CLEANUP_COMPLETE_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_WORKER_CLEANUP_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    launch_command_id: str
    owner: _types_pb2.ProcessIdentity
    child: _types_pb2.ProcessIdentity
    pid: int
    creation_time_100ns: int
    endpoint: str
    creation_failed_without_child: bool
    failure: _types_pb2.Failure
    host_clock: _types_pb2.HostClockDescriptor
    native_cleanup_complete: bool
    acquisition_worker_cleanup: AcquisitionWorkerCleanupProof
    def __init__(self, command_id: _Optional[str] = ..., launch_command_id: _Optional[str] = ..., owner: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., child: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., pid: _Optional[int] = ..., creation_time_100ns: _Optional[int] = ..., endpoint: _Optional[str] = ..., creation_failed_without_child: _Optional[bool] = ..., failure: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ..., host_clock: _Optional[_Union[_types_pb2.HostClockDescriptor, _Mapping]] = ..., native_cleanup_complete: _Optional[bool] = ..., acquisition_worker_cleanup: _Optional[_Union[AcquisitionWorkerCleanupProof, _Mapping]] = ...) -> None: ...

class AcquisitionWorkerCleanupProof(_message.Message):
    __slots__ = ("operation", "cleanup")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    operation: _messages_pb2.WorkerOperationReport
    cleanup: _messages_pb2.WorkerLifecycleEvidence
    def __init__(self, operation: _Optional[_Union[_messages_pb2.WorkerOperationReport, _Mapping]] = ..., cleanup: _Optional[_Union[_messages_pb2.WorkerLifecycleEvidence, _Mapping]] = ...) -> None: ...

class LaunchQuery(_message.Message):
    __slots__ = ("requester", "launch_command_id")
    REQUESTER_FIELD_NUMBER: _ClassVar[int]
    LAUNCH_COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    requester: _types_pb2.ProcessIdentity
    launch_command_id: str
    def __init__(self, requester: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., launch_command_id: _Optional[str] = ...) -> None: ...

class LaunchState(_message.Message):
    __slots__ = ("plan", "phase", "containment_job_name", "pid", "creation_time_100ns", "endpoint", "failure", "host_clock")
    PLAN_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    CONTAINMENT_JOB_NAME_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    CREATION_TIME_100NS_FIELD_NUMBER: _ClassVar[int]
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    HOST_CLOCK_FIELD_NUMBER: _ClassVar[int]
    plan: PlanLaunchRequest
    phase: LaunchPhase
    containment_job_name: str
    pid: int
    creation_time_100ns: int
    endpoint: str
    failure: _types_pb2.Failure
    host_clock: _types_pb2.HostClockDescriptor
    def __init__(self, plan: _Optional[_Union[PlanLaunchRequest, _Mapping]] = ..., phase: _Optional[_Union[LaunchPhase, str]] = ..., containment_job_name: _Optional[str] = ..., pid: _Optional[int] = ..., creation_time_100ns: _Optional[int] = ..., endpoint: _Optional[str] = ..., failure: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ..., host_clock: _Optional[_Union[_types_pb2.HostClockDescriptor, _Mapping]] = ...) -> None: ...

class LaunchReceipt(_message.Message):
    __slots__ = ("admission", "state")
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    admission: _types_pb2.CommandAdmission
    state: LaunchState
    def __init__(self, admission: _Optional[_Union[_types_pb2.CommandAdmission, _Mapping]] = ..., state: _Optional[_Union[LaunchState, _Mapping]] = ...) -> None: ...

class DataPreparationReport(_message.Message):
    __slots__ = ("source", "configuration_revision", "report_revision", "tracking_input", "tracking")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REPORT_REVISION_FIELD_NUMBER: _ClassVar[int]
    TRACKING_INPUT_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    source: _types_pb2.ReportContext
    configuration_revision: int
    report_revision: int
    tracking_input: _messages_pb2.FrameBufferAttachment
    tracking: _preparation_pb2.TrackingPreparationState
    def __init__(self, source: _Optional[_Union[_types_pb2.ReportContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., report_revision: _Optional[int] = ..., tracking_input: _Optional[_Union[_messages_pb2.FrameBufferAttachment, _Mapping]] = ..., tracking: _Optional[_Union[_preparation_pb2.TrackingPreparationState, _Mapping]] = ...) -> None: ...

class TrackingInputConfirmation(_message.Message):
    __slots__ = ("command", "configuration_revision", "tracking_evidence", "tracking_cleanup")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    TRACKING_EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    TRACKING_CLEANUP_FIELD_NUMBER: _ClassVar[int]
    command: BackendCommand
    configuration_revision: int
    tracking_evidence: DataPreparationReport
    tracking_cleanup: _types_pb2.CleanupReport
    def __init__(self, command: _Optional[_Union[BackendCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., tracking_evidence: _Optional[_Union[DataPreparationReport, _Mapping]] = ..., tracking_cleanup: _Optional[_Union[_types_pb2.CleanupReport, _Mapping]] = ...) -> None: ...

class MicrocontrollerIoRequest(_message.Message):
    __slots__ = ("command_id", "requester", "controller_generation", "deadline_monotonic_ns", "kind", "requested", "roles", "boundary_monotonic_ns", "stop_issued_monotonic_ns", "boundary_command", "claim_id", "resolution_operation", "requested_configuration_revision")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    REQUESTER_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    ROLES_FIELD_NUMBER: _ClassVar[int]
    BOUNDARY_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    STOP_ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    BOUNDARY_COMMAND_FIELD_NUMBER: _ClassVar[int]
    CLAIM_ID_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_OPERATION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    requester: _types_pb2.ProcessIdentity
    controller_generation: str
    deadline_monotonic_ns: int
    kind: MicrocontrollerIoKind
    requested: _camera_pb2.CameraPulseConfiguration
    roles: _containers.RepeatedScalarFieldContainer[_camera_pb2.CameraRole]
    boundary_monotonic_ns: int
    stop_issued_monotonic_ns: int
    boundary_command: _microcontroller_pb2.PulseBoundaryCommand
    claim_id: str
    resolution_operation: _types_pb2.OperationContext
    requested_configuration_revision: int
    def __init__(self, command_id: _Optional[str] = ..., requester: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., controller_generation: _Optional[str] = ..., deadline_monotonic_ns: _Optional[int] = ..., kind: _Optional[_Union[MicrocontrollerIoKind, str]] = ..., requested: _Optional[_Union[_camera_pb2.CameraPulseConfiguration, _Mapping]] = ..., roles: _Optional[_Iterable[_Union[_camera_pb2.CameraRole, str]]] = ..., boundary_monotonic_ns: _Optional[int] = ..., stop_issued_monotonic_ns: _Optional[int] = ..., boundary_command: _Optional[_Union[_microcontroller_pb2.PulseBoundaryCommand, str]] = ..., claim_id: _Optional[str] = ..., resolution_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., requested_configuration_revision: _Optional[int] = ...) -> None: ...

class MicrocontrollerIoResult(_message.Message):
    __slots__ = ("command_id", "succeeded", "failure", "observation", "evidence", "cancelled")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    CANCELLED_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    succeeded: bool
    failure: str
    observation: _microcontroller_pb2.MicrocontrollerObservation
    evidence: _microcontroller_pb2.PulseCommandEvidence
    cancelled: bool
    def __init__(self, command_id: _Optional[str] = ..., succeeded: _Optional[bool] = ..., failure: _Optional[str] = ..., observation: _Optional[_Union[_microcontroller_pb2.MicrocontrollerObservation, _Mapping]] = ..., evidence: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ..., cancelled: _Optional[bool] = ...) -> None: ...
