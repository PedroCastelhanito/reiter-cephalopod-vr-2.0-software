from cephvr.acquisition.v1 import runtime_pb2 as _runtime_pb2
from cephvr.synchronization.v1 import spikeglx_pb2 as _spikeglx_pb2
from cephvr.visual_stimulus.v1 import runtime_pb2 as _runtime_pb2_1
from cephvr.visual_stimulus.v1 import plan_pb2 as _plan_pb2
from cephvr.tracking.v1 import pose_pb2 as _pose_pb2
from cephvr.tracking.v1 import methods_pb2 as _methods_pb2
from cephvr.acquisition.v1 import camera_pb2 as _camera_pb2
from cephvr.acquisition.v1 import microcontroller_pb2 as _microcontroller_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SessionPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SESSION_PHASE_UNSPECIFIED: _ClassVar[SessionPhase]
    SESSION_PHASE_CONFIGURATION: _ClassVar[SessionPhase]
    SESSION_PHASE_SETTING_UP: _ClassVar[SessionPhase]
    SESSION_PHASE_READY: _ClassVar[SessionPhase]
    SESSION_PHASE_STARTING: _ClassVar[SessionPhase]
    SESSION_PHASE_RUNNING: _ClassVar[SessionPhase]
    SESSION_PHASE_FINALIZING: _ClassVar[SessionPhase]
    SESSION_PHASE_ENDED: _ClassVar[SessionPhase]

class TrialPhase(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRIAL_PHASE_UNSPECIFIED: _ClassVar[TrialPhase]
    TRIAL_PHASE_PENDING: _ClassVar[TrialPhase]
    TRIAL_PHASE_PREPARING: _ClassVar[TrialPhase]
    TRIAL_PHASE_READY: _ClassVar[TrialPhase]
    TRIAL_PHASE_STARTING: _ClassVar[TrialPhase]
    TRIAL_PHASE_RUNNING: _ClassVar[TrialPhase]
    TRIAL_PHASE_FINALIZING: _ClassVar[TrialPhase]
    TRIAL_PHASE_ENDED: _ClassVar[TrialPhase]

class OutputClosure(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    OUTPUT_CLOSURE_UNSPECIFIED: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_NOT_STARTED: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_OPEN: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_CLOSING: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_CLOSED: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_FAILED: _ClassVar[OutputClosure]
    OUTPUT_CLOSURE_UNCONFIRMED: _ClassVar[OutputClosure]

class MetadataPersistence(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    METADATA_PERSISTENCE_UNSPECIFIED: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_NOT_REQUIRED: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_NOT_STARTED: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_PENDING: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_SYNCED: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_FAILED: _ClassVar[MetadataPersistence]
    METADATA_PERSISTENCE_UNCONFIRMED: _ClassVar[MetadataPersistence]

class CommandResult(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    COMMAND_RESULT_UNSPECIFIED: _ClassVar[CommandResult]
    COMMAND_RESULT_ACCEPTED: _ClassVar[CommandResult]
    COMMAND_RESULT_REJECTED: _ClassVar[CommandResult]

class SessionMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SESSION_MODE_UNSPECIFIED: _ClassVar[SessionMode]
    SESSION_MODE_OPEN_LOOP: _ClassVar[SessionMode]
    SESSION_MODE_CLOSED_LOOP: _ClassVar[SessionMode]

class SessionOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SESSION_OUTCOME_UNSPECIFIED: _ClassVar[SessionOutcome]
    SESSION_OUTCOME_COMPLETED: _ClassVar[SessionOutcome]
    SESSION_OUTCOME_STOPPED: _ClassVar[SessionOutcome]
    SESSION_OUTCOME_INTERRUPTED: _ClassVar[SessionOutcome]

class TrackingDiagnosticStage(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRACKING_DIAGNOSTIC_STAGE_UNSPECIFIED: _ClassVar[TrackingDiagnosticStage]
    TRACKING_DIAGNOSTIC_STAGE_POSE: _ClassVar[TrackingDiagnosticStage]
    TRACKING_DIAGNOSTIC_STAGE_SAMPLING_REGION: _ClassVar[TrackingDiagnosticStage]
    TRACKING_DIAGNOSTIC_STAGE_OPTICAL_FLOW: _ClassVar[TrackingDiagnosticStage]
    TRACKING_DIAGNOSTIC_STAGE_FLOW_QUALITY: _ClassVar[TrackingDiagnosticStage]
    TRACKING_DIAGNOSTIC_STAGE_LOCOMOTION: _ClassVar[TrackingDiagnosticStage]

class TrackingDiagnosticStageState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRACKING_DIAGNOSTIC_STAGE_STATE_UNSPECIFIED: _ClassVar[TrackingDiagnosticStageState]
    TRACKING_DIAGNOSTIC_STAGE_STATE_AVAILABLE: _ClassVar[TrackingDiagnosticStageState]
    TRACKING_DIAGNOSTIC_STAGE_STATE_RUNNING: _ClassVar[TrackingDiagnosticStageState]
    TRACKING_DIAGNOSTIC_STAGE_STATE_UNAVAILABLE: _ClassVar[TrackingDiagnosticStageState]
    TRACKING_DIAGNOSTIC_STAGE_STATE_FAILED: _ClassVar[TrackingDiagnosticStageState]

class TrialOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRIAL_OUTCOME_UNSPECIFIED: _ClassVar[TrialOutcome]
    TRIAL_OUTCOME_COMPLETED: _ClassVar[TrialOutcome]
    TRIAL_OUTCOME_INTERRUPTED: _ClassVar[TrialOutcome]

class RecoveryOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RECOVERY_OUTCOME_UNSPECIFIED: _ClassVar[RecoveryOutcome]
    RECOVERY_OUTCOME_COMPLETED: _ClassVar[RecoveryOutcome]
    RECOVERY_OUTCOME_FAILED: _ClassVar[RecoveryOutcome]

class TrackingPoseMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TRACKING_POSE_MODE_UNSPECIFIED: _ClassVar[TrackingPoseMode]
    TRACKING_POSE_MODE_MANUAL: _ClassVar[TrackingPoseMode]
    TRACKING_POSE_MODE_AUTOMATIC: _ClassVar[TrackingPoseMode]

class CameraVideoContent(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_VIDEO_CONTENT_UNSPECIFIED: _ClassVar[CameraVideoContent]
    CAMERA_VIDEO_CONTENT_UNKNOWN: _ClassVar[CameraVideoContent]
    CAMERA_VIDEO_CONTENT_NO_FRAMES: _ClassVar[CameraVideoContent]
    CAMERA_VIDEO_CONTENT_FRAMES_SUBMITTED: _ClassVar[CameraVideoContent]

class VisualStimulusReviewVideoContent(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_UNSPECIFIED: _ClassVar[VisualStimulusReviewVideoContent]
    VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_UNKNOWN: _ClassVar[VisualStimulusReviewVideoContent]
    VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_NO_FRAMES: _ClassVar[VisualStimulusReviewVideoContent]
    VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_FRAMES_SUBMITTED: _ClassVar[VisualStimulusReviewVideoContent]

class RuntimeIncidentDisposition(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    RUNTIME_INCIDENT_DISPOSITION_UNSPECIFIED: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_AWAITING_OPERATOR: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_CONTINUE_SELECTED: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_ABORT_SELECTED: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_AUTOMATIC_STOP: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_RESOLVED: _ClassVar[RuntimeIncidentDisposition]
    RUNTIME_INCIDENT_DISPOSITION_SESSION_ENDED_UNANSWERED: _ClassVar[RuntimeIncidentDisposition]

class MicrocontrollerSignalKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    MICROCONTROLLER_SIGNAL_KIND_UNSPECIFIED: _ClassVar[MicrocontrollerSignalKind]
    MICROCONTROLLER_SIGNAL_KIND_TRIAL_STATE: _ClassVar[MicrocontrollerSignalKind]
    MICROCONTROLLER_SIGNAL_KIND_PROJECTOR_FLIP: _ClassVar[MicrocontrollerSignalKind]
    MICROCONTROLLER_SIGNAL_KIND_BEHAVIORAL: _ClassVar[MicrocontrollerSignalKind]
    MICROCONTROLLER_SIGNAL_KIND_TRACKING: _ClassVar[MicrocontrollerSignalKind]
SESSION_PHASE_UNSPECIFIED: SessionPhase
SESSION_PHASE_CONFIGURATION: SessionPhase
SESSION_PHASE_SETTING_UP: SessionPhase
SESSION_PHASE_READY: SessionPhase
SESSION_PHASE_STARTING: SessionPhase
SESSION_PHASE_RUNNING: SessionPhase
SESSION_PHASE_FINALIZING: SessionPhase
SESSION_PHASE_ENDED: SessionPhase
TRIAL_PHASE_UNSPECIFIED: TrialPhase
TRIAL_PHASE_PENDING: TrialPhase
TRIAL_PHASE_PREPARING: TrialPhase
TRIAL_PHASE_READY: TrialPhase
TRIAL_PHASE_STARTING: TrialPhase
TRIAL_PHASE_RUNNING: TrialPhase
TRIAL_PHASE_FINALIZING: TrialPhase
TRIAL_PHASE_ENDED: TrialPhase
OUTPUT_CLOSURE_UNSPECIFIED: OutputClosure
OUTPUT_CLOSURE_NOT_STARTED: OutputClosure
OUTPUT_CLOSURE_OPEN: OutputClosure
OUTPUT_CLOSURE_CLOSING: OutputClosure
OUTPUT_CLOSURE_CLOSED: OutputClosure
OUTPUT_CLOSURE_FAILED: OutputClosure
OUTPUT_CLOSURE_UNCONFIRMED: OutputClosure
METADATA_PERSISTENCE_UNSPECIFIED: MetadataPersistence
METADATA_PERSISTENCE_NOT_REQUIRED: MetadataPersistence
METADATA_PERSISTENCE_NOT_STARTED: MetadataPersistence
METADATA_PERSISTENCE_PENDING: MetadataPersistence
METADATA_PERSISTENCE_SYNCED: MetadataPersistence
METADATA_PERSISTENCE_FAILED: MetadataPersistence
METADATA_PERSISTENCE_UNCONFIRMED: MetadataPersistence
COMMAND_RESULT_UNSPECIFIED: CommandResult
COMMAND_RESULT_ACCEPTED: CommandResult
COMMAND_RESULT_REJECTED: CommandResult
SESSION_MODE_UNSPECIFIED: SessionMode
SESSION_MODE_OPEN_LOOP: SessionMode
SESSION_MODE_CLOSED_LOOP: SessionMode
SESSION_OUTCOME_UNSPECIFIED: SessionOutcome
SESSION_OUTCOME_COMPLETED: SessionOutcome
SESSION_OUTCOME_STOPPED: SessionOutcome
SESSION_OUTCOME_INTERRUPTED: SessionOutcome
TRACKING_DIAGNOSTIC_STAGE_UNSPECIFIED: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_POSE: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_SAMPLING_REGION: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_OPTICAL_FLOW: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_FLOW_QUALITY: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_LOCOMOTION: TrackingDiagnosticStage
TRACKING_DIAGNOSTIC_STAGE_STATE_UNSPECIFIED: TrackingDiagnosticStageState
TRACKING_DIAGNOSTIC_STAGE_STATE_AVAILABLE: TrackingDiagnosticStageState
TRACKING_DIAGNOSTIC_STAGE_STATE_RUNNING: TrackingDiagnosticStageState
TRACKING_DIAGNOSTIC_STAGE_STATE_UNAVAILABLE: TrackingDiagnosticStageState
TRACKING_DIAGNOSTIC_STAGE_STATE_FAILED: TrackingDiagnosticStageState
TRIAL_OUTCOME_UNSPECIFIED: TrialOutcome
TRIAL_OUTCOME_COMPLETED: TrialOutcome
TRIAL_OUTCOME_INTERRUPTED: TrialOutcome
RECOVERY_OUTCOME_UNSPECIFIED: RecoveryOutcome
RECOVERY_OUTCOME_COMPLETED: RecoveryOutcome
RECOVERY_OUTCOME_FAILED: RecoveryOutcome
TRACKING_POSE_MODE_UNSPECIFIED: TrackingPoseMode
TRACKING_POSE_MODE_MANUAL: TrackingPoseMode
TRACKING_POSE_MODE_AUTOMATIC: TrackingPoseMode
CAMERA_VIDEO_CONTENT_UNSPECIFIED: CameraVideoContent
CAMERA_VIDEO_CONTENT_UNKNOWN: CameraVideoContent
CAMERA_VIDEO_CONTENT_NO_FRAMES: CameraVideoContent
CAMERA_VIDEO_CONTENT_FRAMES_SUBMITTED: CameraVideoContent
VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_UNSPECIFIED: VisualStimulusReviewVideoContent
VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_UNKNOWN: VisualStimulusReviewVideoContent
VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_NO_FRAMES: VisualStimulusReviewVideoContent
VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_FRAMES_SUBMITTED: VisualStimulusReviewVideoContent
RUNTIME_INCIDENT_DISPOSITION_UNSPECIFIED: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_AWAITING_OPERATOR: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_CONTINUE_SELECTED: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_ABORT_SELECTED: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_AUTOMATIC_STOP: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_RESOLVED: RuntimeIncidentDisposition
RUNTIME_INCIDENT_DISPOSITION_SESSION_ENDED_UNANSWERED: RuntimeIncidentDisposition
MICROCONTROLLER_SIGNAL_KIND_UNSPECIFIED: MicrocontrollerSignalKind
MICROCONTROLLER_SIGNAL_KIND_TRIAL_STATE: MicrocontrollerSignalKind
MICROCONTROLLER_SIGNAL_KIND_PROJECTOR_FLIP: MicrocontrollerSignalKind
MICROCONTROLLER_SIGNAL_KIND_BEHAVIORAL: MicrocontrollerSignalKind
MICROCONTROLLER_SIGNAL_KIND_TRACKING: MicrocontrollerSignalKind

class HostClockDescriptor(_message.Message):
    __slots__ = ("clock_id", "implementation", "monotonic", "adjustable", "resolution_s")
    CLOCK_ID_FIELD_NUMBER: _ClassVar[int]
    IMPLEMENTATION_FIELD_NUMBER: _ClassVar[int]
    MONOTONIC_FIELD_NUMBER: _ClassVar[int]
    ADJUSTABLE_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_S_FIELD_NUMBER: _ClassVar[int]
    clock_id: str
    implementation: str
    monotonic: bool
    adjustable: bool
    resolution_s: float
    def __init__(self, clock_id: _Optional[str] = ..., implementation: _Optional[str] = ..., monotonic: _Optional[bool] = ..., adjustable: _Optional[bool] = ..., resolution_s: _Optional[float] = ...) -> None: ...

class OperatorContext(_message.Message):
    __slots__ = ("client_id", "control_generation", "command_id")
    CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROL_GENERATION_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    client_id: str
    control_generation: str
    command_id: str
    def __init__(self, client_id: _Optional[str] = ..., control_generation: _Optional[str] = ..., command_id: _Optional[str] = ...) -> None: ...

class SessionContext(_message.Message):
    __slots__ = ("controller_generation", "session_id")
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    SESSION_ID_FIELD_NUMBER: _ClassVar[int]
    controller_generation: str
    session_id: str
    def __init__(self, controller_generation: _Optional[str] = ..., session_id: _Optional[str] = ...) -> None: ...

class TrialContext(_message.Message):
    __slots__ = ("session", "trial_id", "trial_number")
    SESSION_FIELD_NUMBER: _ClassVar[int]
    TRIAL_ID_FIELD_NUMBER: _ClassVar[int]
    TRIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    session: SessionContext
    trial_id: str
    trial_number: int
    def __init__(self, session: _Optional[_Union[SessionContext, _Mapping]] = ..., trial_id: _Optional[str] = ..., trial_number: _Optional[int] = ...) -> None: ...

class BackendContext(_message.Message):
    __slots__ = ("backend_name", "backend_generation")
    BACKEND_NAME_FIELD_NUMBER: _ClassVar[int]
    BACKEND_GENERATION_FIELD_NUMBER: _ClassVar[int]
    backend_name: str
    backend_generation: str
    def __init__(self, backend_name: _Optional[str] = ..., backend_generation: _Optional[str] = ...) -> None: ...

class OperationContext(_message.Message):
    __slots__ = ("command_id",)
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    def __init__(self, command_id: _Optional[str] = ...) -> None: ...

class ProcessIdentity(_message.Message):
    __slots__ = ("role", "generation")
    ROLE_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    role: str
    generation: str
    def __init__(self, role: _Optional[str] = ..., generation: _Optional[str] = ...) -> None: ...

class WorkContext(_message.Message):
    __slots__ = ("session", "trial")
    SESSION_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FIELD_NUMBER: _ClassVar[int]
    session: SessionContext
    trial: TrialContext
    def __init__(self, session: _Optional[_Union[SessionContext, _Mapping]] = ..., trial: _Optional[_Union[TrialContext, _Mapping]] = ...) -> None: ...

class Failure(_message.Message):
    __slots__ = ("code", "message")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ...) -> None: ...

class FieldIssue(_message.Message):
    __slots__ = ("component", "field_path", "failure", "file_path", "device", "trial_number", "rejected_value")
    COMPONENT_FIELD_NUMBER: _ClassVar[int]
    FIELD_PATH_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    FILE_PATH_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    TRIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    REJECTED_VALUE_FIELD_NUMBER: _ClassVar[int]
    component: str
    field_path: str
    failure: Failure
    file_path: str
    device: str
    trial_number: int
    rejected_value: str
    def __init__(self, component: _Optional[str] = ..., field_path: _Optional[str] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ..., file_path: _Optional[str] = ..., device: _Optional[str] = ..., trial_number: _Optional[int] = ..., rejected_value: _Optional[str] = ...) -> None: ...

class AcquisitionSettings(_message.Message):
    __slots__ = ("behavioral", "tracking", "pulses", "recording_options", "preview_output_bit_depth", "recording_startup_allowance_ms", "tracking_ring_frames", "recording_queue_frames", "session_preview_max_hz", "eye_tracking")
    BEHAVIORAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    PULSES_FIELD_NUMBER: _ClassVar[int]
    RECORDING_OPTIONS_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_OUTPUT_BIT_DEPTH_FIELD_NUMBER: _ClassVar[int]
    RECORDING_STARTUP_ALLOWANCE_MS_FIELD_NUMBER: _ClassVar[int]
    TRACKING_RING_FRAMES_FIELD_NUMBER: _ClassVar[int]
    RECORDING_QUEUE_FRAMES_FIELD_NUMBER: _ClassVar[int]
    SESSION_PREVIEW_MAX_HZ_FIELD_NUMBER: _ClassVar[int]
    EYE_TRACKING_FIELD_NUMBER: _ClassVar[int]
    behavioral: _camera_pb2.CameraSessionSettings
    tracking: _camera_pb2.CameraSessionSettings
    pulses: _camera_pb2.CameraPulseConfiguration
    recording_options: _runtime_pb2.AcquisitionRecordingOptions
    preview_output_bit_depth: int
    recording_startup_allowance_ms: int
    tracking_ring_frames: int
    recording_queue_frames: int
    session_preview_max_hz: float
    eye_tracking: _camera_pb2.CameraSessionSettings
    def __init__(self, behavioral: _Optional[_Union[_camera_pb2.CameraSessionSettings, _Mapping]] = ..., tracking: _Optional[_Union[_camera_pb2.CameraSessionSettings, _Mapping]] = ..., pulses: _Optional[_Union[_camera_pb2.CameraPulseConfiguration, _Mapping]] = ..., recording_options: _Optional[_Union[_runtime_pb2.AcquisitionRecordingOptions, _Mapping]] = ..., preview_output_bit_depth: _Optional[int] = ..., recording_startup_allowance_ms: _Optional[int] = ..., tracking_ring_frames: _Optional[int] = ..., recording_queue_frames: _Optional[int] = ..., session_preview_max_hz: _Optional[float] = ..., eye_tracking: _Optional[_Union[_camera_pb2.CameraSessionSettings, _Mapping]] = ...) -> None: ...

class VisualStimulusSettings(_message.Message):
    __slots__ = ("display", "save_visual_stimulus_data", "review_ffmpeg_args")
    DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SAVE_VISUAL_STIMULUS_DATA_FIELD_NUMBER: _ClassVar[int]
    REVIEW_FFMPEG_ARGS_FIELD_NUMBER: _ClassVar[int]
    display: _runtime_pb2_1.DisplayConfiguration
    save_visual_stimulus_data: bool
    review_ffmpeg_args: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, display: _Optional[_Union[_runtime_pb2_1.DisplayConfiguration, _Mapping]] = ..., save_visual_stimulus_data: _Optional[bool] = ..., review_ffmpeg_args: _Optional[_Iterable[str]] = ...) -> None: ...

class VisualStimulusDisplayView(_message.Message):
    __slots__ = ("source", "backend", "controller", "command_id", "requested_revision", "applied_revision", "outputs", "issues", "resources", "observed_monotonic_ns", "complete", "last_successful_applied_revision", "calibration")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_REVISION_FIELD_NUMBER: _ClassVar[int]
    APPLIED_REVISION_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    ISSUES_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    COMPLETE_FIELD_NUMBER: _ClassVar[int]
    LAST_SUCCESSFUL_APPLIED_REVISION_FIELD_NUMBER: _ClassVar[int]
    CALIBRATION_FIELD_NUMBER: _ClassVar[int]
    source: ProcessIdentity
    backend: BackendContext
    controller: ProcessIdentity
    command_id: str
    requested_revision: int
    applied_revision: int
    outputs: _containers.RepeatedCompositeFieldContainer[_runtime_pb2_1.OutputInitialization]
    issues: _containers.RepeatedCompositeFieldContainer[FieldIssue]
    resources: _containers.RepeatedCompositeFieldContainer[ResourceRelease]
    observed_monotonic_ns: int
    complete: bool
    last_successful_applied_revision: int
    calibration: _runtime_pb2_1.DisplayCalibrationEvidence
    def __init__(self, source: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., backend: _Optional[_Union[BackendContext, _Mapping]] = ..., controller: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., command_id: _Optional[str] = ..., requested_revision: _Optional[int] = ..., applied_revision: _Optional[int] = ..., outputs: _Optional[_Iterable[_Union[_runtime_pb2_1.OutputInitialization, _Mapping]]] = ..., issues: _Optional[_Iterable[_Union[FieldIssue, _Mapping]]] = ..., resources: _Optional[_Iterable[_Union[ResourceRelease, _Mapping]]] = ..., observed_monotonic_ns: _Optional[int] = ..., complete: _Optional[bool] = ..., last_successful_applied_revision: _Optional[int] = ..., calibration: _Optional[_Union[_runtime_pb2_1.DisplayCalibrationEvidence, _Mapping]] = ...) -> None: ...

class TrackingSettings(_message.Message):
    __slots__ = ("pipeline_id", "input_camera_role", "pose_mode", "pose_max_age_ms", "pose_history_capacity", "manual_pose", "save_tracking_data", "pose_search_region", "subject_reference", "stages", "preprocessing", "image_scale")
    PIPELINE_ID_FIELD_NUMBER: _ClassVar[int]
    INPUT_CAMERA_ROLE_FIELD_NUMBER: _ClassVar[int]
    POSE_MODE_FIELD_NUMBER: _ClassVar[int]
    POSE_MAX_AGE_MS_FIELD_NUMBER: _ClassVar[int]
    POSE_HISTORY_CAPACITY_FIELD_NUMBER: _ClassVar[int]
    MANUAL_POSE_FIELD_NUMBER: _ClassVar[int]
    SAVE_TRACKING_DATA_FIELD_NUMBER: _ClassVar[int]
    POSE_SEARCH_REGION_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    STAGES_FIELD_NUMBER: _ClassVar[int]
    PREPROCESSING_FIELD_NUMBER: _ClassVar[int]
    IMAGE_SCALE_FIELD_NUMBER: _ClassVar[int]
    pipeline_id: str
    input_camera_role: _camera_pb2.CameraRole
    pose_mode: TrackingPoseMode
    pose_max_age_ms: float
    pose_history_capacity: int
    manual_pose: _pose_pb2.ManualPoseSettings
    save_tracking_data: bool
    pose_search_region: _pose_pb2.PoseSearchRegion
    subject_reference: _pose_pb2.SubjectReferenceSettings
    stages: _containers.RepeatedCompositeFieldContainer[_methods_pb2.StageConfiguration]
    preprocessing: _pose_pb2.TrackingPreprocessingSettings
    image_scale: _pose_pb2.TrackingImageScale
    def __init__(self, pipeline_id: _Optional[str] = ..., input_camera_role: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., pose_mode: _Optional[_Union[TrackingPoseMode, str]] = ..., pose_max_age_ms: _Optional[float] = ..., pose_history_capacity: _Optional[int] = ..., manual_pose: _Optional[_Union[_pose_pb2.ManualPoseSettings, _Mapping]] = ..., save_tracking_data: _Optional[bool] = ..., pose_search_region: _Optional[_Union[_pose_pb2.PoseSearchRegion, _Mapping]] = ..., subject_reference: _Optional[_Union[_pose_pb2.SubjectReferenceSettings, _Mapping]] = ..., stages: _Optional[_Iterable[_Union[_methods_pb2.StageConfiguration, _Mapping]]] = ..., preprocessing: _Optional[_Union[_pose_pb2.TrackingPreprocessingSettings, _Mapping]] = ..., image_scale: _Optional[_Union[_pose_pb2.TrackingImageScale, _Mapping]] = ...) -> None: ...

class SynchronizationSettings(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class VisualStimulusTrialSettings(_message.Message):
    __slots__ = ("program", "stimulus_seed_decimal", "arena_boundaries")
    PROGRAM_FIELD_NUMBER: _ClassVar[int]
    STIMULUS_SEED_DECIMAL_FIELD_NUMBER: _ClassVar[int]
    ARENA_BOUNDARIES_FIELD_NUMBER: _ClassVar[int]
    program: _plan_pb2.ProgramSource
    stimulus_seed_decimal: str
    arena_boundaries: _plan_pb2.ArenaBoundaries
    def __init__(self, program: _Optional[_Union[_plan_pb2.ProgramSource, _Mapping]] = ..., stimulus_seed_decimal: _Optional[str] = ..., arena_boundaries: _Optional[_Union[_plan_pb2.ArenaBoundaries, _Mapping]] = ...) -> None: ...

class ResolvedStimulusPlan(_message.Message):
    __slots__ = ("prepared", "occurrences", "seed_decimal")
    PREPARED_FIELD_NUMBER: _ClassVar[int]
    OCCURRENCES_FIELD_NUMBER: _ClassVar[int]
    SEED_DECIMAL_FIELD_NUMBER: _ClassVar[int]
    prepared: _runtime_pb2_1.PreparedHandle
    occurrences: _containers.RepeatedCompositeFieldContainer[PlannedOccurrence]
    seed_decimal: str
    def __init__(self, prepared: _Optional[_Union[_runtime_pb2_1.PreparedHandle, _Mapping]] = ..., occurrences: _Optional[_Iterable[_Union[PlannedOccurrence, _Mapping]]] = ..., seed_decimal: _Optional[str] = ...) -> None: ...

class PlannedOccurrence(_message.Message):
    __slots__ = ("index", "epoch_id", "start_offset_ns", "duration_ns", "scene_id", "lineage")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    EPOCH_ID_FIELD_NUMBER: _ClassVar[int]
    START_OFFSET_NS_FIELD_NUMBER: _ClassVar[int]
    DURATION_NS_FIELD_NUMBER: _ClassVar[int]
    SCENE_ID_FIELD_NUMBER: _ClassVar[int]
    LINEAGE_FIELD_NUMBER: _ClassVar[int]
    index: int
    epoch_id: str
    start_offset_ns: int
    duration_ns: int
    scene_id: str
    lineage: _containers.RepeatedCompositeFieldContainer[PlannedGroupVisit]
    def __init__(self, index: _Optional[int] = ..., epoch_id: _Optional[str] = ..., start_offset_ns: _Optional[int] = ..., duration_ns: _Optional[int] = ..., scene_id: _Optional[str] = ..., lineage: _Optional[_Iterable[_Union[PlannedGroupVisit, _Mapping]]] = ...) -> None: ...

class PlannedGroupVisit(_message.Message):
    __slots__ = ("group_id", "repetition_index", "unit_id", "visit_index")
    GROUP_ID_FIELD_NUMBER: _ClassVar[int]
    REPETITION_INDEX_FIELD_NUMBER: _ClassVar[int]
    UNIT_ID_FIELD_NUMBER: _ClassVar[int]
    VISIT_INDEX_FIELD_NUMBER: _ClassVar[int]
    group_id: str
    repetition_index: int
    unit_id: str
    visit_index: int
    def __init__(self, group_id: _Optional[str] = ..., repetition_index: _Optional[int] = ..., unit_id: _Optional[str] = ..., visit_index: _Optional[int] = ...) -> None: ...

class DeviceProgressEvidence(_message.Message):
    __slots__ = ("visual_stimulus_output", "tracking_evaluation", "camera", "producer")
    VISUAL_STIMULUS_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    TRACKING_EVALUATION_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_FIELD_NUMBER: _ClassVar[int]
    visual_stimulus_output: _runtime_pb2_1.OutputActivity
    tracking_evaluation: _methods_pb2.TrackingFirstEvaluation
    camera: _camera_pb2.CameraRole
    producer: ProcessIdentity
    def __init__(self, visual_stimulus_output: _Optional[_Union[_runtime_pb2_1.OutputActivity, _Mapping]] = ..., tracking_evaluation: _Optional[_Union[_methods_pb2.TrackingFirstEvaluation, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., producer: _Optional[_Union[ProcessIdentity, _Mapping]] = ...) -> None: ...

class BackendSettings(_message.Message):
    __slots__ = ("backend_name", "enabled", "acquisition", "visual_stimulus", "tracking", "synchronization")
    BACKEND_NAME_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    SYNCHRONIZATION_FIELD_NUMBER: _ClassVar[int]
    backend_name: str
    enabled: bool
    acquisition: AcquisitionSettings
    visual_stimulus: VisualStimulusSettings
    tracking: TrackingSettings
    synchronization: SynchronizationSettings
    def __init__(self, backend_name: _Optional[str] = ..., enabled: _Optional[bool] = ..., acquisition: _Optional[_Union[AcquisitionSettings, _Mapping]] = ..., visual_stimulus: _Optional[_Union[VisualStimulusSettings, _Mapping]] = ..., tracking: _Optional[_Union[TrackingSettings, _Mapping]] = ..., synchronization: _Optional[_Union[SynchronizationSettings, _Mapping]] = ...) -> None: ...

class TrackingDiagnosticStageStatus(_message.Message):
    __slots__ = ("stage", "state", "reason")
    STAGE_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    stage: TrackingDiagnosticStage
    state: TrackingDiagnosticStageState
    reason: str
    def __init__(self, stage: _Optional[_Union[TrackingDiagnosticStage, str]] = ..., state: _Optional[_Union[TrackingDiagnosticStageState, str]] = ..., reason: _Optional[str] = ...) -> None: ...

class TrackingDiagnosticState(_message.Message):
    __slots__ = ("diagnostic_id", "configuration_revision", "preview_run_id", "acquisition_run_id", "source_camera_serial", "stages", "active", "closed", "input_frames", "evaluated_frames", "lapped_frames", "last_duration_ns", "maximum_duration_ns", "failure", "tracking_endpoint", "tracking_process")
    DIAGNOSTIC_ID_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_CAMERA_SERIAL_FIELD_NUMBER: _ClassVar[int]
    STAGES_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    CLOSED_FIELD_NUMBER: _ClassVar[int]
    INPUT_FRAMES_FIELD_NUMBER: _ClassVar[int]
    EVALUATED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    LAPPED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    LAST_DURATION_NS_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_DURATION_NS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    TRACKING_ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    TRACKING_PROCESS_FIELD_NUMBER: _ClassVar[int]
    diagnostic_id: str
    configuration_revision: int
    preview_run_id: str
    acquisition_run_id: str
    source_camera_serial: str
    stages: _containers.RepeatedCompositeFieldContainer[TrackingDiagnosticStageStatus]
    active: bool
    closed: bool
    input_frames: int
    evaluated_frames: int
    lapped_frames: int
    last_duration_ns: int
    maximum_duration_ns: int
    failure: str
    tracking_endpoint: str
    tracking_process: ProcessIdentity
    def __init__(self, diagnostic_id: _Optional[str] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., acquisition_run_id: _Optional[str] = ..., source_camera_serial: _Optional[str] = ..., stages: _Optional[_Iterable[_Union[TrackingDiagnosticStageStatus, _Mapping]]] = ..., active: _Optional[bool] = ..., closed: _Optional[bool] = ..., input_frames: _Optional[int] = ..., evaluated_frames: _Optional[int] = ..., lapped_frames: _Optional[int] = ..., last_duration_ns: _Optional[int] = ..., maximum_duration_ns: _Optional[int] = ..., failure: _Optional[str] = ..., tracking_endpoint: _Optional[str] = ..., tracking_process: _Optional[_Union[ProcessIdentity, _Mapping]] = ...) -> None: ...

class TrialDefinition(_message.Message):
    __slots__ = ("trial_number", "stimulus")
    TRIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    STIMULUS_FIELD_NUMBER: _ClassVar[int]
    trial_number: int
    stimulus: VisualStimulusTrialSettings
    def __init__(self, trial_number: _Optional[int] = ..., stimulus: _Optional[_Union[VisualStimulusTrialSettings, _Mapping]] = ...) -> None: ...

class IntertrialGap(_message.Message):
    __slots__ = ("after_trial_number", "minimum_duration_ns")
    AFTER_TRIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_DURATION_NS_FIELD_NUMBER: _ClassVar[int]
    after_trial_number: int
    minimum_duration_ns: int
    def __init__(self, after_trial_number: _Optional[int] = ..., minimum_duration_ns: _Optional[int] = ...) -> None: ...

class ExperimentConfiguration(_message.Message):
    __slots__ = ("subject", "experiment", "recording_root", "asset_root", "mode", "trials", "gaps", "backends", "subject_metadata")
    SUBJECT_FIELD_NUMBER: _ClassVar[int]
    EXPERIMENT_FIELD_NUMBER: _ClassVar[int]
    RECORDING_ROOT_FIELD_NUMBER: _ClassVar[int]
    ASSET_ROOT_FIELD_NUMBER: _ClassVar[int]
    MODE_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    GAPS_FIELD_NUMBER: _ClassVar[int]
    BACKENDS_FIELD_NUMBER: _ClassVar[int]
    SUBJECT_METADATA_FIELD_NUMBER: _ClassVar[int]
    subject: str
    experiment: str
    recording_root: str
    asset_root: str
    mode: SessionMode
    trials: _containers.RepeatedCompositeFieldContainer[TrialDefinition]
    gaps: _containers.RepeatedCompositeFieldContainer[IntertrialGap]
    backends: _containers.RepeatedCompositeFieldContainer[BackendSettings]
    subject_metadata: SubjectMetadata
    def __init__(self, subject: _Optional[str] = ..., experiment: _Optional[str] = ..., recording_root: _Optional[str] = ..., asset_root: _Optional[str] = ..., mode: _Optional[_Union[SessionMode, str]] = ..., trials: _Optional[_Iterable[_Union[TrialDefinition, _Mapping]]] = ..., gaps: _Optional[_Iterable[_Union[IntertrialGap, _Mapping]]] = ..., backends: _Optional[_Iterable[_Union[BackendSettings, _Mapping]]] = ..., subject_metadata: _Optional[_Union[SubjectMetadata, _Mapping]] = ...) -> None: ...

class SubjectMetadata(_message.Message):
    __slots__ = ("species", "sex", "age_dph", "size_mm", "condition")
    SPECIES_FIELD_NUMBER: _ClassVar[int]
    SEX_FIELD_NUMBER: _ClassVar[int]
    AGE_DPH_FIELD_NUMBER: _ClassVar[int]
    SIZE_MM_FIELD_NUMBER: _ClassVar[int]
    CONDITION_FIELD_NUMBER: _ClassVar[int]
    species: str
    sex: str
    age_dph: float
    size_mm: float
    condition: str
    def __init__(self, species: _Optional[str] = ..., sex: _Optional[str] = ..., age_dph: _Optional[float] = ..., size_mm: _Optional[float] = ..., condition: _Optional[str] = ...) -> None: ...

class WaitPolicy(_message.Message):
    __slots__ = ("initial_ns",)
    INITIAL_NS_FIELD_NUMBER: _ClassVar[int]
    initial_ns: int
    def __init__(self, initial_ns: _Optional[int] = ...) -> None: ...

class ControlPolicies(_message.Message):
    __slots__ = ("setup", "setup_cancel", "trial_ready", "trial_finished", "supervisor_registration", "start_lead_ns", "controller_release_offset_ns", "backend_release_offset_ns", "start_evidence_allowance_ns", "stop_evidence_allowance_ns", "trial_command_transport_retries", "metadata_timeout_ns", "command_retention_after_finalization_ns", "recovery_ns")
    SETUP_FIELD_NUMBER: _ClassVar[int]
    SETUP_CANCEL_FIELD_NUMBER: _ClassVar[int]
    TRIAL_READY_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FINISHED_FIELD_NUMBER: _ClassVar[int]
    SUPERVISOR_REGISTRATION_FIELD_NUMBER: _ClassVar[int]
    START_LEAD_NS_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_RELEASE_OFFSET_NS_FIELD_NUMBER: _ClassVar[int]
    BACKEND_RELEASE_OFFSET_NS_FIELD_NUMBER: _ClassVar[int]
    START_EVIDENCE_ALLOWANCE_NS_FIELD_NUMBER: _ClassVar[int]
    STOP_EVIDENCE_ALLOWANCE_NS_FIELD_NUMBER: _ClassVar[int]
    TRIAL_COMMAND_TRANSPORT_RETRIES_FIELD_NUMBER: _ClassVar[int]
    METADATA_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    COMMAND_RETENTION_AFTER_FINALIZATION_NS_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_NS_FIELD_NUMBER: _ClassVar[int]
    setup: WaitPolicy
    setup_cancel: WaitPolicy
    trial_ready: WaitPolicy
    trial_finished: WaitPolicy
    supervisor_registration: WaitPolicy
    start_lead_ns: int
    controller_release_offset_ns: int
    backend_release_offset_ns: int
    start_evidence_allowance_ns: int
    stop_evidence_allowance_ns: int
    trial_command_transport_retries: int
    metadata_timeout_ns: int
    command_retention_after_finalization_ns: int
    recovery_ns: int
    def __init__(self, setup: _Optional[_Union[WaitPolicy, _Mapping]] = ..., setup_cancel: _Optional[_Union[WaitPolicy, _Mapping]] = ..., trial_ready: _Optional[_Union[WaitPolicy, _Mapping]] = ..., trial_finished: _Optional[_Union[WaitPolicy, _Mapping]] = ..., supervisor_registration: _Optional[_Union[WaitPolicy, _Mapping]] = ..., start_lead_ns: _Optional[int] = ..., controller_release_offset_ns: _Optional[int] = ..., backend_release_offset_ns: _Optional[int] = ..., start_evidence_allowance_ns: _Optional[int] = ..., stop_evidence_allowance_ns: _Optional[int] = ..., trial_command_transport_retries: _Optional[int] = ..., metadata_timeout_ns: _Optional[int] = ..., command_retention_after_finalization_ns: _Optional[int] = ..., recovery_ns: _Optional[int] = ...) -> None: ...

class TrialPlan(_message.Message):
    __slots__ = ("context", "definition", "resolved_stimulus", "resolved_duration_ns", "continuation_incidents")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    DEFINITION_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_STIMULUS_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_DURATION_NS_FIELD_NUMBER: _ClassVar[int]
    CONTINUATION_INCIDENTS_FIELD_NUMBER: _ClassVar[int]
    context: TrialContext
    definition: TrialDefinition
    resolved_stimulus: ResolvedStimulusPlan
    resolved_duration_ns: int
    continuation_incidents: _containers.RepeatedCompositeFieldContainer[RuntimeIncident]
    def __init__(self, context: _Optional[_Union[TrialContext, _Mapping]] = ..., definition: _Optional[_Union[TrialDefinition, _Mapping]] = ..., resolved_stimulus: _Optional[_Union[ResolvedStimulusPlan, _Mapping]] = ..., resolved_duration_ns: _Optional[int] = ..., continuation_incidents: _Optional[_Iterable[_Union[RuntimeIncident, _Mapping]]] = ...) -> None: ...

class OutputPlan(_message.Message):
    __slots__ = ("backend", "output_key", "path", "trial", "output_tag", "extension")
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_KEY_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_TAG_FIELD_NUMBER: _ClassVar[int]
    EXTENSION_FIELD_NUMBER: _ClassVar[int]
    backend: BackendContext
    output_key: str
    path: str
    trial: TrialContext
    output_tag: str
    extension: str
    def __init__(self, backend: _Optional[_Union[BackendContext, _Mapping]] = ..., output_key: _Optional[str] = ..., path: _Optional[str] = ..., trial: _Optional[_Union[TrialContext, _Mapping]] = ..., output_tag: _Optional[str] = ..., extension: _Optional[str] = ...) -> None: ...

class PreparedSession(_message.Message):
    __slots__ = ("context", "configuration_revision", "configuration", "policies", "trials", "session_directory", "local_timezone", "anchor_monotonic_ns", "anchor_wall_time", "outputs", "spikeglx")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    POLICIES_FIELD_NUMBER: _ClassVar[int]
    TRIALS_FIELD_NUMBER: _ClassVar[int]
    SESSION_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    LOCAL_TIMEZONE_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_WALL_TIME_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    SPIKEGLX_FIELD_NUMBER: _ClassVar[int]
    context: SessionContext
    configuration_revision: int
    configuration: ExperimentConfiguration
    policies: ControlPolicies
    trials: _containers.RepeatedCompositeFieldContainer[TrialPlan]
    session_directory: str
    local_timezone: str
    anchor_monotonic_ns: int
    anchor_wall_time: str
    outputs: _containers.RepeatedCompositeFieldContainer[OutputPlan]
    spikeglx: _spikeglx_pb2.SpikeGLXPreparation
    def __init__(self, context: _Optional[_Union[SessionContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., configuration: _Optional[_Union[ExperimentConfiguration, _Mapping]] = ..., policies: _Optional[_Union[ControlPolicies, _Mapping]] = ..., trials: _Optional[_Iterable[_Union[TrialPlan, _Mapping]]] = ..., session_directory: _Optional[str] = ..., local_timezone: _Optional[str] = ..., anchor_monotonic_ns: _Optional[int] = ..., anchor_wall_time: _Optional[str] = ..., outputs: _Optional[_Iterable[_Union[OutputPlan, _Mapping]]] = ..., spikeglx: _Optional[_Union[_spikeglx_pb2.SpikeGLXPreparation, _Mapping]] = ...) -> None: ...

class ValidationResult(_message.Message):
    __slots__ = ("configuration_revision", "completed", "valid", "issues", "unavailable_reason", "dependencies", "component", "configuration_module_version")
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_FIELD_NUMBER: _ClassVar[int]
    VALID_FIELD_NUMBER: _ClassVar[int]
    ISSUES_FIELD_NUMBER: _ClassVar[int]
    UNAVAILABLE_REASON_FIELD_NUMBER: _ClassVar[int]
    DEPENDENCIES_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_MODULE_VERSION_FIELD_NUMBER: _ClassVar[int]
    configuration_revision: int
    completed: bool
    valid: bool
    issues: _containers.RepeatedCompositeFieldContainer[FieldIssue]
    unavailable_reason: Failure
    dependencies: _containers.RepeatedCompositeFieldContainer[DependencyRequirement]
    component: str
    configuration_module_version: str
    def __init__(self, configuration_revision: _Optional[int] = ..., completed: _Optional[bool] = ..., valid: _Optional[bool] = ..., issues: _Optional[_Iterable[_Union[FieldIssue, _Mapping]]] = ..., unavailable_reason: _Optional[_Union[Failure, _Mapping]] = ..., dependencies: _Optional[_Iterable[_Union[DependencyRequirement, _Mapping]]] = ..., component: _Optional[str] = ..., configuration_module_version: _Optional[str] = ...) -> None: ...

class DependencyRequirement(_message.Message):
    __slots__ = ("backend_name", "device", "capability", "reason")
    BACKEND_NAME_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    CAPABILITY_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    backend_name: str
    device: str
    capability: str
    reason: str
    def __init__(self, backend_name: _Optional[str] = ..., device: _Optional[str] = ..., capability: _Optional[str] = ..., reason: _Optional[str] = ...) -> None: ...

class ConfigurationState(_message.Message):
    __slots__ = ("revision", "locked", "edit_validation", "setup_issues", "outstanding_validators")
    REVISION_FIELD_NUMBER: _ClassVar[int]
    LOCKED_FIELD_NUMBER: _ClassVar[int]
    EDIT_VALIDATION_FIELD_NUMBER: _ClassVar[int]
    SETUP_ISSUES_FIELD_NUMBER: _ClassVar[int]
    OUTSTANDING_VALIDATORS_FIELD_NUMBER: _ClassVar[int]
    revision: int
    locked: bool
    edit_validation: _containers.RepeatedCompositeFieldContainer[ValidationResult]
    setup_issues: _containers.RepeatedCompositeFieldContainer[FieldIssue]
    outstanding_validators: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, revision: _Optional[int] = ..., locked: _Optional[bool] = ..., edit_validation: _Optional[_Iterable[_Union[ValidationResult, _Mapping]]] = ..., setup_issues: _Optional[_Iterable[_Union[FieldIssue, _Mapping]]] = ..., outstanding_validators: _Optional[_Iterable[str]] = ...) -> None: ...

class ConfigurationValues(_message.Message):
    __slots__ = ("current", "revision")
    CURRENT_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    current: ExperimentConfiguration
    revision: int
    def __init__(self, current: _Optional[_Union[ExperimentConfiguration, _Mapping]] = ..., revision: _Optional[int] = ...) -> None: ...

class CommandAdmission(_message.Message):
    __slots__ = ("result", "failure", "command_id")
    RESULT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    result: CommandResult
    failure: Failure
    command_id: str
    def __init__(self, result: _Optional[_Union[CommandResult, str]] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ..., command_id: _Optional[str] = ...) -> None: ...

class ReportReceipt(_message.Message):
    __slots__ = ("result", "failure")
    RESULT_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    result: CommandResult
    failure: Failure
    def __init__(self, result: _Optional[_Union[CommandResult, str]] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class ReportContext(_message.Message):
    __slots__ = ("backend", "work", "operation")
    BACKEND_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    backend: BackendContext
    work: WorkContext
    operation: OperationContext
    def __init__(self, backend: _Optional[_Union[BackendContext, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., operation: _Optional[_Union[OperationContext, _Mapping]] = ...) -> None: ...

class OutputResult(_message.Message):
    __slots__ = ("output_key", "path", "closure", "failure", "artifact_present", "camera_video_content", "visual_stimulus_review_video_content")
    OUTPUT_KEY_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    CLOSURE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    ARTIFACT_PRESENT_FIELD_NUMBER: _ClassVar[int]
    CAMERA_VIDEO_CONTENT_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_REVIEW_VIDEO_CONTENT_FIELD_NUMBER: _ClassVar[int]
    output_key: str
    path: str
    closure: OutputClosure
    failure: Failure
    artifact_present: bool
    camera_video_content: CameraVideoContent
    visual_stimulus_review_video_content: VisualStimulusReviewVideoContent
    def __init__(self, output_key: _Optional[str] = ..., path: _Optional[str] = ..., closure: _Optional[_Union[OutputClosure, str]] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ..., artifact_present: _Optional[bool] = ..., camera_video_content: _Optional[_Union[CameraVideoContent, str]] = ..., visual_stimulus_review_video_content: _Optional[_Union[VisualStimulusReviewVideoContent, str]] = ...) -> None: ...

class MetadataResult(_message.Message):
    __slots__ = ("operation", "state", "path", "failure")
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    operation: OperationContext
    state: MetadataPersistence
    path: str
    failure: Failure
    def __init__(self, operation: _Optional[_Union[OperationContext, _Mapping]] = ..., state: _Optional[_Union[MetadataPersistence, str]] = ..., path: _Optional[str] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class ReadyReport(_message.Message):
    __slots__ = ("context", "configuration_revision", "required_checks_passed", "resolved_settings", "resolved_trials", "asset_filenames", "prepared_functions", "cleanup_resources")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_CHECKS_PASSED_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_TRIALS_FIELD_NUMBER: _ClassVar[int]
    ASSET_FILENAMES_FIELD_NUMBER: _ClassVar[int]
    PREPARED_FUNCTIONS_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_RESOURCES_FIELD_NUMBER: _ClassVar[int]
    context: ReportContext
    configuration_revision: int
    required_checks_passed: bool
    resolved_settings: BackendSettings
    resolved_trials: _containers.RepeatedCompositeFieldContainer[TrialPlan]
    asset_filenames: _containers.RepeatedScalarFieldContainer[str]
    prepared_functions: _containers.RepeatedCompositeFieldContainer[PreparedFunctionScope]
    cleanup_resources: _containers.RepeatedCompositeFieldContainer[ResourceObligation]
    def __init__(self, context: _Optional[_Union[ReportContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., required_checks_passed: _Optional[bool] = ..., resolved_settings: _Optional[_Union[BackendSettings, _Mapping]] = ..., resolved_trials: _Optional[_Iterable[_Union[TrialPlan, _Mapping]]] = ..., asset_filenames: _Optional[_Iterable[str]] = ..., prepared_functions: _Optional[_Iterable[_Union[PreparedFunctionScope, _Mapping]]] = ..., cleanup_resources: _Optional[_Iterable[_Union[ResourceObligation, _Mapping]]] = ...) -> None: ...

class ResourceObligation(_message.Message):
    __slots__ = ("owner", "resource", "path")
    OWNER_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    owner: ProcessIdentity
    resource: str
    path: str
    def __init__(self, owner: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., resource: _Optional[str] = ..., path: _Optional[str] = ...) -> None: ...

class PreparedFunctionScope(_message.Message):
    __slots__ = ("resource_id", "owner", "affected_closure_resource_ids", "essential_to_stimulus_control", "feedback_hold_required_on_loss", "authorized_reporters", "bounded_uncertainty_supported", "lifecycle_sources")
    RESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    AFFECTED_CLOSURE_RESOURCE_IDS_FIELD_NUMBER: _ClassVar[int]
    ESSENTIAL_TO_STIMULUS_CONTROL_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_HOLD_REQUIRED_ON_LOSS_FIELD_NUMBER: _ClassVar[int]
    AUTHORIZED_REPORTERS_FIELD_NUMBER: _ClassVar[int]
    BOUNDED_UNCERTAINTY_SUPPORTED_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_SOURCES_FIELD_NUMBER: _ClassVar[int]
    resource_id: str
    owner: ProcessIdentity
    affected_closure_resource_ids: _containers.RepeatedScalarFieldContainer[str]
    essential_to_stimulus_control: bool
    feedback_hold_required_on_loss: bool
    authorized_reporters: _containers.RepeatedCompositeFieldContainer[ProcessIdentity]
    bounded_uncertainty_supported: bool
    lifecycle_sources: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, resource_id: _Optional[str] = ..., owner: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., affected_closure_resource_ids: _Optional[_Iterable[str]] = ..., essential_to_stimulus_control: _Optional[bool] = ..., feedback_hold_required_on_loss: _Optional[bool] = ..., authorized_reporters: _Optional[_Iterable[_Union[ProcessIdentity, _Mapping]]] = ..., bounded_uncertainty_supported: _Optional[bool] = ..., lifecycle_sources: _Optional[_Iterable[str]] = ...) -> None: ...

class ActivityEvidence(_message.Message):
    __slots__ = ("kind", "observed_monotonic_ns", "native_counter", "device_evidence")
    KIND_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    NATIVE_COUNTER_FIELD_NUMBER: _ClassVar[int]
    DEVICE_EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    kind: str
    observed_monotonic_ns: int
    native_counter: int
    device_evidence: DeviceProgressEvidence
    def __init__(self, kind: _Optional[str] = ..., observed_monotonic_ns: _Optional[int] = ..., native_counter: _Optional[int] = ..., device_evidence: _Optional[_Union[DeviceProgressEvidence, _Mapping]] = ...) -> None: ...

class StartedReport(_message.Message):
    __slots__ = ("context", "actual_start_monotonic_ns", "first_required_activity", "acquisition_pulse_on")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ACTUAL_START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    FIRST_REQUIRED_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_PULSE_ON_FIELD_NUMBER: _ClassVar[int]
    context: ReportContext
    actual_start_monotonic_ns: int
    first_required_activity: _containers.RepeatedCompositeFieldContainer[ActivityEvidence]
    acquisition_pulse_on: _microcontroller_pb2.PulseCommandEvidence
    def __init__(self, context: _Optional[_Union[ReportContext, _Mapping]] = ..., actual_start_monotonic_ns: _Optional[int] = ..., first_required_activity: _Optional[_Iterable[_Union[ActivityEvidence, _Mapping]]] = ..., acquisition_pulse_on: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ...) -> None: ...

class ProducerRecordingEnd(_message.Message):
    __slots__ = ("producer", "source_id", "end_monotonic_ns")
    PRODUCER_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    producer: ProcessIdentity
    source_id: str
    end_monotonic_ns: int
    def __init__(self, producer: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., source_id: _Optional[str] = ..., end_monotonic_ns: _Optional[int] = ...) -> None: ...

class StoppedReport(_message.Message):
    __slots__ = ("context", "actual_stop_monotonic_ns", "trial_activity_stopped", "visual_stimulus_idle", "recording_interval_sealed", "producer_ends", "acquisition_pulse_off")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    ACTUAL_STOP_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    TRIAL_ACTIVITY_STOPPED_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_IDLE_FIELD_NUMBER: _ClassVar[int]
    RECORDING_INTERVAL_SEALED_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_ENDS_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_PULSE_OFF_FIELD_NUMBER: _ClassVar[int]
    context: ReportContext
    actual_stop_monotonic_ns: int
    trial_activity_stopped: bool
    visual_stimulus_idle: bool
    recording_interval_sealed: bool
    producer_ends: _containers.RepeatedCompositeFieldContainer[ProducerRecordingEnd]
    acquisition_pulse_off: _microcontroller_pb2.PulseCommandEvidence
    def __init__(self, context: _Optional[_Union[ReportContext, _Mapping]] = ..., actual_stop_monotonic_ns: _Optional[int] = ..., trial_activity_stopped: _Optional[bool] = ..., visual_stimulus_idle: _Optional[bool] = ..., recording_interval_sealed: _Optional[bool] = ..., producer_ends: _Optional[_Iterable[_Union[ProducerRecordingEnd, _Mapping]]] = ..., acquisition_pulse_off: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ...) -> None: ...

class CameraTransportSummary(_message.Message):
    __slots__ = ("camera", "observed_monotonic_ns", "buffer_underruns", "failed_buffers", "missed_frames", "resend_requests", "resend_packets", "resynchronizations")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    BUFFER_UNDERRUNS_FIELD_NUMBER: _ClassVar[int]
    FAILED_BUFFERS_FIELD_NUMBER: _ClassVar[int]
    MISSED_FRAMES_FIELD_NUMBER: _ClassVar[int]
    RESEND_REQUESTS_FIELD_NUMBER: _ClassVar[int]
    RESEND_PACKETS_FIELD_NUMBER: _ClassVar[int]
    RESYNCHRONIZATIONS_FIELD_NUMBER: _ClassVar[int]
    camera: _camera_pb2.CameraRole
    observed_monotonic_ns: int
    buffer_underruns: int
    failed_buffers: int
    missed_frames: int
    resend_requests: int
    resend_packets: int
    resynchronizations: int
    def __init__(self, camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., observed_monotonic_ns: _Optional[int] = ..., buffer_underruns: _Optional[int] = ..., failed_buffers: _Optional[int] = ..., missed_frames: _Optional[int] = ..., resend_requests: _Optional[int] = ..., resend_packets: _Optional[int] = ..., resynchronizations: _Optional[int] = ...) -> None: ...

class FinishedReport(_message.Message):
    __slots__ = ("context", "trial_activity_stopped", "outputs", "acquisition_transport_summaries", "visual_stimulus_timing_summaries", "visual_stimulus_review_summary")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    TRIAL_ACTIVITY_STOPPED_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_TRANSPORT_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_TIMING_SUMMARIES_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_REVIEW_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    context: ReportContext
    trial_activity_stopped: bool
    outputs: _containers.RepeatedCompositeFieldContainer[OutputResult]
    acquisition_transport_summaries: _containers.RepeatedCompositeFieldContainer[CameraTransportSummary]
    visual_stimulus_timing_summaries: _containers.RepeatedCompositeFieldContainer[_runtime_pb2_1.TrialTimingSummary]
    visual_stimulus_review_summary: _runtime_pb2_1.ReviewRecordingSummary
    def __init__(self, context: _Optional[_Union[ReportContext, _Mapping]] = ..., trial_activity_stopped: _Optional[bool] = ..., outputs: _Optional[_Iterable[_Union[OutputResult, _Mapping]]] = ..., acquisition_transport_summaries: _Optional[_Iterable[_Union[CameraTransportSummary, _Mapping]]] = ..., visual_stimulus_timing_summaries: _Optional[_Iterable[_Union[_runtime_pb2_1.TrialTimingSummary, _Mapping]]] = ..., visual_stimulus_review_summary: _Optional[_Union[_runtime_pb2_1.ReviewRecordingSummary, _Mapping]] = ...) -> None: ...

class ResourceRelease(_message.Message):
    __slots__ = ("resource", "released", "path", "failure")
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    RELEASED_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    resource: str
    released: bool
    path: str
    failure: Failure
    def __init__(self, resource: _Optional[str] = ..., released: _Optional[bool] = ..., path: _Optional[str] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class CleanupReport(_message.Message):
    __slots__ = ("source", "work", "operation", "verified_monotonic_ns", "trial_activity_stopped", "resources", "outputs", "cleanup_resources_revision")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    VERIFIED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    TRIAL_ACTIVITY_STOPPED_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_RESOURCES_REVISION_FIELD_NUMBER: _ClassVar[int]
    source: ProcessIdentity
    work: WorkContext
    operation: OperationContext
    verified_monotonic_ns: int
    trial_activity_stopped: bool
    resources: _containers.RepeatedCompositeFieldContainer[ResourceRelease]
    outputs: _containers.RepeatedCompositeFieldContainer[OutputResult]
    cleanup_resources_revision: int
    def __init__(self, source: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., operation: _Optional[_Union[OperationContext, _Mapping]] = ..., verified_monotonic_ns: _Optional[int] = ..., trial_activity_stopped: _Optional[bool] = ..., resources: _Optional[_Iterable[_Union[ResourceRelease, _Mapping]]] = ..., outputs: _Optional[_Iterable[_Union[OutputResult, _Mapping]]] = ..., cleanup_resources_revision: _Optional[int] = ...) -> None: ...

class LifecycleReport(_message.Message):
    __slots__ = ("ready", "started", "stopped", "finished", "cleanup", "operation")
    READY_FIELD_NUMBER: _ClassVar[int]
    STARTED_FIELD_NUMBER: _ClassVar[int]
    STOPPED_FIELD_NUMBER: _ClassVar[int]
    FINISHED_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    ready: ReadyReport
    started: StartedReport
    stopped: StoppedReport
    finished: FinishedReport
    cleanup: CleanupReport
    operation: BackendOperationReport
    def __init__(self, ready: _Optional[_Union[ReadyReport, _Mapping]] = ..., started: _Optional[_Union[StartedReport, _Mapping]] = ..., stopped: _Optional[_Union[StoppedReport, _Mapping]] = ..., finished: _Optional[_Union[FinishedReport, _Mapping]] = ..., cleanup: _Optional[_Union[CleanupReport, _Mapping]] = ..., operation: _Optional[_Union[BackendOperationReport, _Mapping]] = ...) -> None: ...

class BackendOperationReport(_message.Message):
    __slots__ = ("source", "operation")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    source: BackendContext
    operation: OperationState
    def __init__(self, source: _Optional[_Union[BackendContext, _Mapping]] = ..., operation: _Optional[_Union[OperationState, _Mapping]] = ...) -> None: ...

class CleanupBlocker(_message.Message):
    __slots__ = ("responsible", "work", "resource", "path", "reason", "recovery_action")
    RESPONSIBLE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    RESOURCE_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_ACTION_FIELD_NUMBER: _ClassVar[int]
    responsible: ProcessIdentity
    work: WorkContext
    resource: str
    path: str
    reason: Failure
    recovery_action: str
    def __init__(self, responsible: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., resource: _Optional[str] = ..., path: _Optional[str] = ..., reason: _Optional[_Union[Failure, _Mapping]] = ..., recovery_action: _Optional[str] = ...) -> None: ...

class ErrorReport(_message.Message):
    __slots__ = ("error_id", "source", "work", "operation", "occurred_monotonic_ns", "failure", "device", "output_path", "isolation", "incident_episode_id")
    ERROR_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    OCCURRED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_PATH_FIELD_NUMBER: _ClassVar[int]
    ISOLATION_FIELD_NUMBER: _ClassVar[int]
    INCIDENT_EPISODE_ID_FIELD_NUMBER: _ClassVar[int]
    error_id: str
    source: ProcessIdentity
    work: WorkContext
    operation: OperationContext
    occurred_monotonic_ns: int
    failure: Failure
    device: str
    output_path: str
    isolation: FaultIsolationEvidence
    incident_episode_id: str
    def __init__(self, error_id: _Optional[str] = ..., source: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., operation: _Optional[_Union[OperationContext, _Mapping]] = ..., occurred_monotonic_ns: _Optional[int] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ..., device: _Optional[str] = ..., output_path: _Optional[str] = ..., isolation: _Optional[_Union[FaultIsolationEvidence, _Mapping]] = ..., incident_episode_id: _Optional[str] = ...) -> None: ...

class FaultIsolationEvidence(_message.Message):
    __slots__ = ("affected_resource_ids", "fenced_resource_ids", "leases_released_or_quarantined", "feedback_hold_active", "verified_monotonic_ns", "bounded_uncertainty", "feedback_hold_resource_ids")
    AFFECTED_RESOURCE_IDS_FIELD_NUMBER: _ClassVar[int]
    FENCED_RESOURCE_IDS_FIELD_NUMBER: _ClassVar[int]
    LEASES_RELEASED_OR_QUARANTINED_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_HOLD_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    VERIFIED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    BOUNDED_UNCERTAINTY_FIELD_NUMBER: _ClassVar[int]
    FEEDBACK_HOLD_RESOURCE_IDS_FIELD_NUMBER: _ClassVar[int]
    affected_resource_ids: _containers.RepeatedScalarFieldContainer[str]
    fenced_resource_ids: _containers.RepeatedScalarFieldContainer[str]
    leases_released_or_quarantined: bool
    feedback_hold_active: bool
    verified_monotonic_ns: int
    bounded_uncertainty: bool
    feedback_hold_resource_ids: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, affected_resource_ids: _Optional[_Iterable[str]] = ..., fenced_resource_ids: _Optional[_Iterable[str]] = ..., leases_released_or_quarantined: _Optional[bool] = ..., feedback_hold_active: _Optional[bool] = ..., verified_monotonic_ns: _Optional[int] = ..., bounded_uncertainty: _Optional[bool] = ..., feedback_hold_resource_ids: _Optional[_Iterable[str]] = ...) -> None: ...

class ContinuingFunctionEvidence(_message.Message):
    __slots__ = ("resource_id", "functioning", "schedule_valid", "host_clock_valid", "control_path_valid", "observed_monotonic_ns")
    RESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    FUNCTIONING_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_VALID_FIELD_NUMBER: _ClassVar[int]
    HOST_CLOCK_VALID_FIELD_NUMBER: _ClassVar[int]
    CONTROL_PATH_VALID_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    resource_id: str
    functioning: bool
    schedule_valid: bool
    host_clock_valid: bool
    control_path_valid: bool
    observed_monotonic_ns: int
    def __init__(self, resource_id: _Optional[str] = ..., functioning: _Optional[bool] = ..., schedule_valid: _Optional[bool] = ..., host_clock_valid: _Optional[bool] = ..., control_path_valid: _Optional[bool] = ..., observed_monotonic_ns: _Optional[int] = ...) -> None: ...

class WorkerProgress(_message.Message):
    __slots__ = ("worker", "progress_required", "last_progress_monotonic_ns", "evidence")
    WORKER_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_REQUIRED_FIELD_NUMBER: _ClassVar[int]
    LAST_PROGRESS_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    worker: str
    progress_required: bool
    last_progress_monotonic_ns: int
    evidence: DeviceProgressEvidence
    def __init__(self, worker: _Optional[str] = ..., progress_required: _Optional[bool] = ..., last_progress_monotonic_ns: _Optional[int] = ..., evidence: _Optional[_Union[DeviceProgressEvidence, _Mapping]] = ...) -> None: ...

class HeartbeatReport(_message.Message):
    __slots__ = ("source", "work", "sent_monotonic_ns", "session_phase", "trial_phase", "health_summary", "active_error", "workers", "continuing_functions", "cleanup_resources_revision", "cleanup_resources")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    SENT_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    SESSION_PHASE_FIELD_NUMBER: _ClassVar[int]
    TRIAL_PHASE_FIELD_NUMBER: _ClassVar[int]
    HEALTH_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ERROR_FIELD_NUMBER: _ClassVar[int]
    WORKERS_FIELD_NUMBER: _ClassVar[int]
    CONTINUING_FUNCTIONS_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_RESOURCES_REVISION_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_RESOURCES_FIELD_NUMBER: _ClassVar[int]
    source: ProcessIdentity
    work: WorkContext
    sent_monotonic_ns: int
    session_phase: SessionPhase
    trial_phase: TrialPhase
    health_summary: str
    active_error: ErrorReport
    workers: _containers.RepeatedCompositeFieldContainer[WorkerProgress]
    continuing_functions: _containers.RepeatedCompositeFieldContainer[ContinuingFunctionEvidence]
    cleanup_resources_revision: int
    cleanup_resources: _containers.RepeatedCompositeFieldContainer[ResourceObligation]
    def __init__(self, source: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., sent_monotonic_ns: _Optional[int] = ..., session_phase: _Optional[_Union[SessionPhase, str]] = ..., trial_phase: _Optional[_Union[TrialPhase, str]] = ..., health_summary: _Optional[str] = ..., active_error: _Optional[_Union[ErrorReport, _Mapping]] = ..., workers: _Optional[_Iterable[_Union[WorkerProgress, _Mapping]]] = ..., continuing_functions: _Optional[_Iterable[_Union[ContinuingFunctionEvidence, _Mapping]]] = ..., cleanup_resources_revision: _Optional[int] = ..., cleanup_resources: _Optional[_Iterable[_Union[ResourceObligation, _Mapping]]] = ...) -> None: ...

class RecoveryState(_message.Message):
    __slots__ = ("attempt_id", "affected", "work", "trigger", "action", "start_monotonic_ns", "deadline_monotonic_ns", "completion_monotonic_ns", "progress", "outcome", "evidence", "failure")
    ATTEMPT_ID_FIELD_NUMBER: _ClassVar[int]
    AFFECTED_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    DEADLINE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    COMPLETION_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    attempt_id: str
    affected: ProcessIdentity
    work: WorkContext
    trigger: Failure
    action: str
    start_monotonic_ns: int
    deadline_monotonic_ns: int
    completion_monotonic_ns: int
    progress: str
    outcome: RecoveryOutcome
    evidence: str
    failure: Failure
    def __init__(self, attempt_id: _Optional[str] = ..., affected: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., trigger: _Optional[_Union[Failure, _Mapping]] = ..., action: _Optional[str] = ..., start_monotonic_ns: _Optional[int] = ..., deadline_monotonic_ns: _Optional[int] = ..., completion_monotonic_ns: _Optional[int] = ..., progress: _Optional[str] = ..., outcome: _Optional[_Union[RecoveryOutcome, str]] = ..., evidence: _Optional[str] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class OperationState(_message.Message):
    __slots__ = ("context", "command", "work", "complete", "succeeded", "progress", "failure")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    COMPLETE_FIELD_NUMBER: _ClassVar[int]
    SUCCEEDED_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    context: OperationContext
    command: str
    work: WorkContext
    complete: bool
    succeeded: bool
    progress: str
    failure: Failure
    def __init__(self, context: _Optional[_Union[OperationContext, _Mapping]] = ..., command: _Optional[str] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., complete: _Optional[bool] = ..., succeeded: _Optional[bool] = ..., progress: _Optional[str] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class SessionState(_message.Message):
    __slots__ = ("phase", "context", "outcome", "directory", "trial_count", "activated", "stop_after_trial", "interruption_reason", "shutdown_requested", "cleanup_confirmed", "cleanup_blockers")
    PHASE_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    TRIAL_COUNT_FIELD_NUMBER: _ClassVar[int]
    ACTIVATED_FIELD_NUMBER: _ClassVar[int]
    STOP_AFTER_TRIAL_FIELD_NUMBER: _ClassVar[int]
    INTERRUPTION_REASON_FIELD_NUMBER: _ClassVar[int]
    SHUTDOWN_REQUESTED_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_CONFIRMED_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_BLOCKERS_FIELD_NUMBER: _ClassVar[int]
    phase: SessionPhase
    context: SessionContext
    outcome: SessionOutcome
    directory: str
    trial_count: int
    activated: bool
    stop_after_trial: bool
    interruption_reason: Failure
    shutdown_requested: bool
    cleanup_confirmed: bool
    cleanup_blockers: _containers.RepeatedCompositeFieldContainer[CleanupBlocker]
    def __init__(self, phase: _Optional[_Union[SessionPhase, str]] = ..., context: _Optional[_Union[SessionContext, _Mapping]] = ..., outcome: _Optional[_Union[SessionOutcome, str]] = ..., directory: _Optional[str] = ..., trial_count: _Optional[int] = ..., activated: _Optional[bool] = ..., stop_after_trial: _Optional[bool] = ..., interruption_reason: _Optional[_Union[Failure, _Mapping]] = ..., shutdown_requested: _Optional[bool] = ..., cleanup_confirmed: _Optional[bool] = ..., cleanup_blockers: _Optional[_Iterable[_Union[CleanupBlocker, _Mapping]]] = ...) -> None: ...

class TrialState(_message.Message):
    __slots__ = ("context", "phase", "outcome", "start_monotonic_ns", "scheduled_end_monotonic_ns", "actual_end_monotonic_ns", "gap_earliest_end_monotonic_ns", "interruption_issued_monotonic_ns")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ACTUAL_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    GAP_EARLIEST_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    INTERRUPTION_ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    context: TrialContext
    phase: TrialPhase
    outcome: TrialOutcome
    start_monotonic_ns: int
    scheduled_end_monotonic_ns: int
    actual_end_monotonic_ns: int
    gap_earliest_end_monotonic_ns: int
    interruption_issued_monotonic_ns: int
    def __init__(self, context: _Optional[_Union[TrialContext, _Mapping]] = ..., phase: _Optional[_Union[TrialPhase, str]] = ..., outcome: _Optional[_Union[TrialOutcome, str]] = ..., start_monotonic_ns: _Optional[int] = ..., scheduled_end_monotonic_ns: _Optional[int] = ..., actual_end_monotonic_ns: _Optional[int] = ..., gap_earliest_end_monotonic_ns: _Optional[int] = ..., interruption_issued_monotonic_ns: _Optional[int] = ...) -> None: ...

class ParticipantState(_message.Message):
    __slots__ = ("process", "enabled", "required", "process_running", "connected", "health", "last_evidence_monotonic_ns", "errors", "ready", "started", "stopped", "finished", "outputs", "preparation_progress", "outstanding_obligations", "software_version", "capabilities", "protocol_package", "session_phase", "trial_phase", "cleanup", "configuration_module_version", "acquisition_warnings")
    PROCESS_FIELD_NUMBER: _ClassVar[int]
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_FIELD_NUMBER: _ClassVar[int]
    PROCESS_RUNNING_FIELD_NUMBER: _ClassVar[int]
    CONNECTED_FIELD_NUMBER: _ClassVar[int]
    HEALTH_FIELD_NUMBER: _ClassVar[int]
    LAST_EVIDENCE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    READY_FIELD_NUMBER: _ClassVar[int]
    STARTED_FIELD_NUMBER: _ClassVar[int]
    STOPPED_FIELD_NUMBER: _ClassVar[int]
    FINISHED_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    PREPARATION_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    OUTSTANDING_OBLIGATIONS_FIELD_NUMBER: _ClassVar[int]
    SOFTWARE_VERSION_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    PROTOCOL_PACKAGE_FIELD_NUMBER: _ClassVar[int]
    SESSION_PHASE_FIELD_NUMBER: _ClassVar[int]
    TRIAL_PHASE_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_MODULE_VERSION_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_WARNINGS_FIELD_NUMBER: _ClassVar[int]
    process: ProcessIdentity
    enabled: bool
    required: bool
    process_running: bool
    connected: bool
    health: str
    last_evidence_monotonic_ns: int
    errors: _containers.RepeatedCompositeFieldContainer[ErrorReport]
    ready: ReadinessState
    started: StartedReport
    stopped: StoppedReport
    finished: FinishedReport
    outputs: _containers.RepeatedCompositeFieldContainer[OutputResult]
    preparation_progress: str
    outstanding_obligations: _containers.RepeatedScalarFieldContainer[str]
    software_version: str
    capabilities: _containers.RepeatedScalarFieldContainer[str]
    protocol_package: str
    session_phase: SessionPhase
    trial_phase: TrialPhase
    cleanup: CleanupReport
    configuration_module_version: str
    acquisition_warnings: _containers.RepeatedCompositeFieldContainer[AcquisitionWarningView]
    def __init__(self, process: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., enabled: _Optional[bool] = ..., required: _Optional[bool] = ..., process_running: _Optional[bool] = ..., connected: _Optional[bool] = ..., health: _Optional[str] = ..., last_evidence_monotonic_ns: _Optional[int] = ..., errors: _Optional[_Iterable[_Union[ErrorReport, _Mapping]]] = ..., ready: _Optional[_Union[ReadinessState, _Mapping]] = ..., started: _Optional[_Union[StartedReport, _Mapping]] = ..., stopped: _Optional[_Union[StoppedReport, _Mapping]] = ..., finished: _Optional[_Union[FinishedReport, _Mapping]] = ..., outputs: _Optional[_Iterable[_Union[OutputResult, _Mapping]]] = ..., preparation_progress: _Optional[str] = ..., outstanding_obligations: _Optional[_Iterable[str]] = ..., software_version: _Optional[str] = ..., capabilities: _Optional[_Iterable[str]] = ..., protocol_package: _Optional[str] = ..., session_phase: _Optional[_Union[SessionPhase, str]] = ..., trial_phase: _Optional[_Union[TrialPhase, str]] = ..., cleanup: _Optional[_Union[CleanupReport, _Mapping]] = ..., configuration_module_version: _Optional[str] = ..., acquisition_warnings: _Optional[_Iterable[_Union[AcquisitionWarningView, _Mapping]]] = ...) -> None: ...

class ReadinessState(_message.Message):
    __slots__ = ("context", "configuration_revision", "required_checks_passed")
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_CHECKS_PASSED_FIELD_NUMBER: _ClassVar[int]
    context: ReportContext
    configuration_revision: int
    required_checks_passed: bool
    def __init__(self, context: _Optional[_Union[ReportContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., required_checks_passed: _Optional[bool] = ...) -> None: ...

class ControlState(_message.Message):
    __slots__ = ("holder_client_id", "control_generation", "commands")
    HOLDER_CLIENT_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROL_GENERATION_FIELD_NUMBER: _ClassVar[int]
    COMMANDS_FIELD_NUMBER: _ClassVar[int]
    holder_client_id: str
    control_generation: str
    commands: _containers.RepeatedCompositeFieldContainer[CommandAvailability]
    def __init__(self, holder_client_id: _Optional[str] = ..., control_generation: _Optional[str] = ..., commands: _Optional[_Iterable[_Union[CommandAvailability, _Mapping]]] = ...) -> None: ...

class CommandAvailability(_message.Message):
    __slots__ = ("command", "available", "blocking_reason")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    BLOCKING_REASON_FIELD_NUMBER: _ClassVar[int]
    command: str
    available: bool
    blocking_reason: str
    def __init__(self, command: _Optional[str] = ..., available: _Optional[bool] = ..., blocking_reason: _Optional[str] = ...) -> None: ...

class RuntimeIncident(_message.Message):
    __slots__ = ("incident_id", "revision", "work", "error_ids", "affected_resources", "consequence", "disposition", "first_observed_monotonic_ns", "last_observed_monotonic_ns", "occurrence_count", "continuation_available", "acknowledged")
    INCIDENT_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    ERROR_IDS_FIELD_NUMBER: _ClassVar[int]
    AFFECTED_RESOURCES_FIELD_NUMBER: _ClassVar[int]
    CONSEQUENCE_FIELD_NUMBER: _ClassVar[int]
    DISPOSITION_FIELD_NUMBER: _ClassVar[int]
    FIRST_OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    LAST_OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    OCCURRENCE_COUNT_FIELD_NUMBER: _ClassVar[int]
    CONTINUATION_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_FIELD_NUMBER: _ClassVar[int]
    incident_id: str
    revision: int
    work: WorkContext
    error_ids: _containers.RepeatedScalarFieldContainer[str]
    affected_resources: _containers.RepeatedScalarFieldContainer[str]
    consequence: str
    disposition: RuntimeIncidentDisposition
    first_observed_monotonic_ns: int
    last_observed_monotonic_ns: int
    occurrence_count: int
    continuation_available: bool
    acknowledged: bool
    def __init__(self, incident_id: _Optional[str] = ..., revision: _Optional[int] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., error_ids: _Optional[_Iterable[str]] = ..., affected_resources: _Optional[_Iterable[str]] = ..., consequence: _Optional[str] = ..., disposition: _Optional[_Union[RuntimeIncidentDisposition, str]] = ..., first_observed_monotonic_ns: _Optional[int] = ..., last_observed_monotonic_ns: _Optional[int] = ..., occurrence_count: _Optional[int] = ..., continuation_available: _Optional[bool] = ..., acknowledged: _Optional[bool] = ...) -> None: ...

class Prompt(_message.Message):
    __slots__ = ("prompt_id", "setup", "operation", "explanation", "permitted_choices", "runtime_incident")
    PROMPT_ID_FIELD_NUMBER: _ClassVar[int]
    SETUP_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    EXPLANATION_FIELD_NUMBER: _ClassVar[int]
    PERMITTED_CHOICES_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_INCIDENT_FIELD_NUMBER: _ClassVar[int]
    prompt_id: str
    setup: SessionContext
    operation: OperationContext
    explanation: str
    permitted_choices: _containers.RepeatedScalarFieldContainer[str]
    runtime_incident: RuntimeIncident
    def __init__(self, prompt_id: _Optional[str] = ..., setup: _Optional[_Union[SessionContext, _Mapping]] = ..., operation: _Optional[_Union[OperationContext, _Mapping]] = ..., explanation: _Optional[str] = ..., permitted_choices: _Optional[_Iterable[str]] = ..., runtime_incident: _Optional[_Union[RuntimeIncident, _Mapping]] = ...) -> None: ...

class Warning(_message.Message):
    __slots__ = ("warning_id", "component", "message", "issues", "reverted_fields", "acquisition_occurrence")
    WARNING_ID_FIELD_NUMBER: _ClassVar[int]
    COMPONENT_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ISSUES_FIELD_NUMBER: _ClassVar[int]
    REVERTED_FIELDS_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_OCCURRENCE_FIELD_NUMBER: _ClassVar[int]
    warning_id: str
    component: str
    message: str
    issues: _containers.RepeatedCompositeFieldContainer[FieldIssue]
    reverted_fields: _containers.RepeatedScalarFieldContainer[str]
    acquisition_occurrence: AcquisitionWarningOccurrence
    def __init__(self, warning_id: _Optional[str] = ..., component: _Optional[str] = ..., message: _Optional[str] = ..., issues: _Optional[_Iterable[_Union[FieldIssue, _Mapping]]] = ..., reverted_fields: _Optional[_Iterable[str]] = ..., acquisition_occurrence: _Optional[_Union[AcquisitionWarningOccurrence, _Mapping]] = ...) -> None: ...

class AcquisitionWarningOccurrence(_message.Message):
    __slots__ = ("source", "work", "camera", "configuration_revision", "preview_run_id", "code", "count", "first_observed_monotonic_ns", "last_observed_monotonic_ns", "latest_sdk_code", "latest_details")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    CODE_FIELD_NUMBER: _ClassVar[int]
    COUNT_FIELD_NUMBER: _ClassVar[int]
    FIRST_OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    LAST_OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    LATEST_SDK_CODE_FIELD_NUMBER: _ClassVar[int]
    LATEST_DETAILS_FIELD_NUMBER: _ClassVar[int]
    source: ProcessIdentity
    work: WorkContext
    camera: _camera_pb2.CameraRole
    configuration_revision: int
    preview_run_id: str
    code: str
    count: int
    first_observed_monotonic_ns: int
    last_observed_monotonic_ns: int
    latest_sdk_code: str
    latest_details: str
    def __init__(self, source: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., code: _Optional[str] = ..., count: _Optional[int] = ..., first_observed_monotonic_ns: _Optional[int] = ..., last_observed_monotonic_ns: _Optional[int] = ..., latest_sdk_code: _Optional[str] = ..., latest_details: _Optional[str] = ...) -> None: ...

class AcquisitionWarningView(_message.Message):
    __slots__ = ("producer", "work", "camera", "configuration_revision", "preview_run_id", "warning_revision", "warnings")
    PRODUCER_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    WARNING_REVISION_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    producer: ProcessIdentity
    work: WorkContext
    camera: _camera_pb2.CameraRole
    configuration_revision: int
    preview_run_id: str
    warning_revision: int
    warnings: _containers.RepeatedCompositeFieldContainer[Warning]
    def __init__(self, producer: _Optional[_Union[ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[WorkContext, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., warning_revision: _Optional[int] = ..., warnings: _Optional[_Iterable[_Union[Warning, _Mapping]]] = ...) -> None: ...

class CameraDeviceView(_message.Message):
    __slots__ = ("device_open", "preview_running", "cleanup_pending", "preview_run_id", "applied_configuration_revision", "capabilities", "last_failure", "applied_settings", "device", "preview_prepared", "preview_visible", "preview_visibility_revision", "preview_failure")
    DEVICE_OPEN_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUNNING_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_PENDING_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    APPLIED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    LAST_FAILURE_FIELD_NUMBER: _ClassVar[int]
    APPLIED_SETTINGS_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_PREPARED_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_VISIBLE_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_VISIBILITY_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_FAILURE_FIELD_NUMBER: _ClassVar[int]
    device_open: bool
    preview_running: bool
    cleanup_pending: bool
    preview_run_id: str
    applied_configuration_revision: int
    capabilities: _camera_pb2.CameraCapabilities
    last_failure: Failure
    applied_settings: _camera_pb2.CameraSettings
    device: _camera_pb2.CameraDeviceIdentity
    preview_prepared: bool
    preview_visible: bool
    preview_visibility_revision: int
    preview_failure: str
    def __init__(self, device_open: _Optional[bool] = ..., preview_running: _Optional[bool] = ..., cleanup_pending: _Optional[bool] = ..., preview_run_id: _Optional[str] = ..., applied_configuration_revision: _Optional[int] = ..., capabilities: _Optional[_Union[_camera_pb2.CameraCapabilities, _Mapping]] = ..., last_failure: _Optional[_Union[Failure, _Mapping]] = ..., applied_settings: _Optional[_Union[_camera_pb2.CameraSettings, _Mapping]] = ..., device: _Optional[_Union[_camera_pb2.CameraDeviceIdentity, _Mapping]] = ..., preview_prepared: _Optional[bool] = ..., preview_visible: _Optional[bool] = ..., preview_visibility_revision: _Optional[int] = ..., preview_failure: _Optional[str] = ...) -> None: ...

class AcquisitionDeviceViews(_message.Message):
    __slots__ = ("source", "state_revision", "observed_monotonic_ns", "behavioral", "tracking", "pulses", "trial_pulses", "diagnostic", "eye_tracking")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    PULSES_FIELD_NUMBER: _ClassVar[int]
    TRIAL_PULSES_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_FIELD_NUMBER: _ClassVar[int]
    EYE_TRACKING_FIELD_NUMBER: _ClassVar[int]
    source: BackendContext
    state_revision: int
    observed_monotonic_ns: int
    behavioral: CameraDeviceView
    tracking: CameraDeviceView
    pulses: _microcontroller_pb2.MicrocontrollerObservation
    trial_pulses: TrialPulseEvidence
    diagnostic: MicrocontrollerDiagnosticView
    eye_tracking: CameraDeviceView
    def __init__(self, source: _Optional[_Union[BackendContext, _Mapping]] = ..., state_revision: _Optional[int] = ..., observed_monotonic_ns: _Optional[int] = ..., behavioral: _Optional[_Union[CameraDeviceView, _Mapping]] = ..., tracking: _Optional[_Union[CameraDeviceView, _Mapping]] = ..., pulses: _Optional[_Union[_microcontroller_pb2.MicrocontrollerObservation, _Mapping]] = ..., trial_pulses: _Optional[_Union[TrialPulseEvidence, _Mapping]] = ..., diagnostic: _Optional[_Union[MicrocontrollerDiagnosticView, _Mapping]] = ..., eye_tracking: _Optional[_Union[CameraDeviceView, _Mapping]] = ...) -> None: ...

class MicrocontrollerDiagnosticView(_message.Message):
    __slots__ = ("active", "signal", "pin", "rising_edges", "observed_monotonic_ns")
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    SIGNAL_FIELD_NUMBER: _ClassVar[int]
    PIN_FIELD_NUMBER: _ClassVar[int]
    RISING_EDGES_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    active: bool
    signal: MicrocontrollerSignalKind
    pin: str
    rising_edges: int
    observed_monotonic_ns: int
    def __init__(self, active: _Optional[bool] = ..., signal: _Optional[_Union[MicrocontrollerSignalKind, str]] = ..., pin: _Optional[str] = ..., rising_edges: _Optional[int] = ..., observed_monotonic_ns: _Optional[int] = ...) -> None: ...

class TrialPulseEvidence(_message.Message):
    __slots__ = ("work", "on", "off")
    WORK_FIELD_NUMBER: _ClassVar[int]
    ON_FIELD_NUMBER: _ClassVar[int]
    OFF_FIELD_NUMBER: _ClassVar[int]
    work: WorkContext
    on: _microcontroller_pb2.PulseCommandEvidence
    off: _microcontroller_pb2.PulseCommandEvidence
    def __init__(self, work: _Optional[_Union[WorkContext, _Mapping]] = ..., on: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ..., off: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ...) -> None: ...

class Snapshot(_message.Message):
    __slots__ = ("controller_generation", "captured_monotonic_ns", "state_revision", "configuration", "session", "trial", "participants", "control", "operations", "errors", "warnings", "recoveries", "prompts", "metadata", "configuration_values", "acquisition_devices", "visual_stimulus_display", "spikeglx_recording", "runtime_incidents", "reservation", "retained_since_monotonic_ns", "retained_truncated", "tracking_diagnostic", "microcontroller")
    CONTROLLER_GENERATION_FIELD_NUMBER: _ClassVar[int]
    CAPTURED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FIELD_NUMBER: _ClassVar[int]
    PARTICIPANTS_FIELD_NUMBER: _ClassVar[int]
    CONTROL_FIELD_NUMBER: _ClassVar[int]
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    ERRORS_FIELD_NUMBER: _ClassVar[int]
    WARNINGS_FIELD_NUMBER: _ClassVar[int]
    RECOVERIES_FIELD_NUMBER: _ClassVar[int]
    PROMPTS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_VALUES_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_DEVICES_FIELD_NUMBER: _ClassVar[int]
    VISUAL_STIMULUS_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    SPIKEGLX_RECORDING_FIELD_NUMBER: _ClassVar[int]
    RUNTIME_INCIDENTS_FIELD_NUMBER: _ClassVar[int]
    RESERVATION_FIELD_NUMBER: _ClassVar[int]
    RETAINED_SINCE_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    RETAINED_TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    TRACKING_DIAGNOSTIC_FIELD_NUMBER: _ClassVar[int]
    MICROCONTROLLER_FIELD_NUMBER: _ClassVar[int]
    controller_generation: str
    captured_monotonic_ns: int
    state_revision: int
    configuration: ConfigurationState
    session: SessionState
    trial: TrialState
    participants: _containers.RepeatedCompositeFieldContainer[ParticipantState]
    control: ControlState
    operations: _containers.RepeatedCompositeFieldContainer[OperationState]
    errors: _containers.RepeatedCompositeFieldContainer[ErrorReport]
    warnings: _containers.RepeatedCompositeFieldContainer[Warning]
    recoveries: _containers.RepeatedCompositeFieldContainer[RecoveryState]
    prompts: _containers.RepeatedCompositeFieldContainer[Prompt]
    metadata: _containers.RepeatedCompositeFieldContainer[MetadataResult]
    configuration_values: ConfigurationValues
    acquisition_devices: AcquisitionDeviceViews
    visual_stimulus_display: VisualStimulusDisplayView
    spikeglx_recording: _spikeglx_pb2.SpikeGLXRecordingView
    runtime_incidents: _containers.RepeatedCompositeFieldContainer[RuntimeIncident]
    reservation: OutputReservationState
    retained_since_monotonic_ns: int
    retained_truncated: bool
    tracking_diagnostic: TrackingDiagnosticState
    microcontroller: MicrocontrollerDeviceView
    def __init__(self, controller_generation: _Optional[str] = ..., captured_monotonic_ns: _Optional[int] = ..., state_revision: _Optional[int] = ..., configuration: _Optional[_Union[ConfigurationState, _Mapping]] = ..., session: _Optional[_Union[SessionState, _Mapping]] = ..., trial: _Optional[_Union[TrialState, _Mapping]] = ..., participants: _Optional[_Iterable[_Union[ParticipantState, _Mapping]]] = ..., control: _Optional[_Union[ControlState, _Mapping]] = ..., operations: _Optional[_Iterable[_Union[OperationState, _Mapping]]] = ..., errors: _Optional[_Iterable[_Union[ErrorReport, _Mapping]]] = ..., warnings: _Optional[_Iterable[_Union[Warning, _Mapping]]] = ..., recoveries: _Optional[_Iterable[_Union[RecoveryState, _Mapping]]] = ..., prompts: _Optional[_Iterable[_Union[Prompt, _Mapping]]] = ..., metadata: _Optional[_Iterable[_Union[MetadataResult, _Mapping]]] = ..., configuration_values: _Optional[_Union[ConfigurationValues, _Mapping]] = ..., acquisition_devices: _Optional[_Union[AcquisitionDeviceViews, _Mapping]] = ..., visual_stimulus_display: _Optional[_Union[VisualStimulusDisplayView, _Mapping]] = ..., spikeglx_recording: _Optional[_Union[_spikeglx_pb2.SpikeGLXRecordingView, _Mapping]] = ..., runtime_incidents: _Optional[_Iterable[_Union[RuntimeIncident, _Mapping]]] = ..., reservation: _Optional[_Union[OutputReservationState, _Mapping]] = ..., retained_since_monotonic_ns: _Optional[int] = ..., retained_truncated: _Optional[bool] = ..., tracking_diagnostic: _Optional[_Union[TrackingDiagnosticState, _Mapping]] = ..., microcontroller: _Optional[_Union[MicrocontrollerDeviceView, _Mapping]] = ...) -> None: ...

class OutputReservationState(_message.Message):
    __slots__ = ("session", "operation", "session_directory", "lock_held", "ready_for_outputs", "released", "conflicting_paths", "recovery_required", "failure")
    SESSION_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    SESSION_DIRECTORY_FIELD_NUMBER: _ClassVar[int]
    LOCK_HELD_FIELD_NUMBER: _ClassVar[int]
    READY_FOR_OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    RELEASED_FIELD_NUMBER: _ClassVar[int]
    CONFLICTING_PATHS_FIELD_NUMBER: _ClassVar[int]
    RECOVERY_REQUIRED_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    session: SessionContext
    operation: OperationContext
    session_directory: str
    lock_held: bool
    ready_for_outputs: bool
    released: bool
    conflicting_paths: _containers.RepeatedScalarFieldContainer[str]
    recovery_required: bool
    failure: Failure
    def __init__(self, session: _Optional[_Union[SessionContext, _Mapping]] = ..., operation: _Optional[_Union[OperationContext, _Mapping]] = ..., session_directory: _Optional[str] = ..., lock_held: _Optional[bool] = ..., ready_for_outputs: _Optional[bool] = ..., released: _Optional[bool] = ..., conflicting_paths: _Optional[_Iterable[str]] = ..., recovery_required: _Optional[bool] = ..., failure: _Optional[_Union[Failure, _Mapping]] = ...) -> None: ...

class MicrocontrollerDeviceView(_message.Message):
    __slots__ = ("observation", "diagnostic", "cleanup_pending", "failure")
    OBSERVATION_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_PENDING_FIELD_NUMBER: _ClassVar[int]
    FAILURE_FIELD_NUMBER: _ClassVar[int]
    observation: _microcontroller_pb2.MicrocontrollerObservation
    diagnostic: MicrocontrollerDiagnosticView
    cleanup_pending: bool
    failure: str
    def __init__(self, observation: _Optional[_Union[_microcontroller_pb2.MicrocontrollerObservation, _Mapping]] = ..., diagnostic: _Optional[_Union[MicrocontrollerDiagnosticView, _Mapping]] = ..., cleanup_pending: _Optional[bool] = ..., failure: _Optional[str] = ...) -> None: ...
