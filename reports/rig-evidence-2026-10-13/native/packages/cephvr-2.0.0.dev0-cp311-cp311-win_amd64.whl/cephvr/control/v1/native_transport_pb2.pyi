from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class PipeHandshake(_message.Message):
    __slots__ = ("protocol_version", "process_instance_id", "startup_nonce", "accepted")
    PROTOCOL_VERSION_FIELD_NUMBER: _ClassVar[int]
    PROCESS_INSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    STARTUP_NONCE_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_FIELD_NUMBER: _ClassVar[int]
    protocol_version: int
    process_instance_id: str
    startup_nonce: bytes
    accepted: bool
    def __init__(self, protocol_version: _Optional[int] = ..., process_instance_id: _Optional[str] = ..., startup_nonce: _Optional[bytes] = ..., accepted: _Optional[bool] = ...) -> None: ...
