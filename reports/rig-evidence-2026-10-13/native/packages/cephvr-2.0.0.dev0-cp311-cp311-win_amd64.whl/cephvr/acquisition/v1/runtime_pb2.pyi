from cephvr.acquisition.v1 import camera_pb2 as _camera_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CameraFilePolicy(_message.Message):
    __slots__ = ("camera", "transport", "frame_silence_timeout_ns", "post_cutoff_drain_margin_ns")
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    FRAME_SILENCE_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    POST_CUTOFF_DRAIN_MARGIN_NS_FIELD_NUMBER: _ClassVar[int]
    camera: _camera_pb2.CameraRole
    transport: _camera_pb2.CameraTransportSettings
    frame_silence_timeout_ns: int
    post_cutoff_drain_margin_ns: int
    def __init__(self, camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ..., frame_silence_timeout_ns: _Optional[int] = ..., post_cutoff_drain_margin_ns: _Optional[int] = ...) -> None: ...

class AcquisitionFilePolicies(_message.Message):
    __slots__ = ("contract_version", "cameras", "frame_log_sync_interval_ns", "video_sync_interval_ns", "fragment_target_ns", "encoder_stall_timeout_ns", "serial_baud_rate", "serial_ack_timeout_ns", "serial_keepalive_interval_ns", "serial_communication_timeout_ns", "serial_stop_completion_margin_ns")
    CONTRACT_VERSION_FIELD_NUMBER: _ClassVar[int]
    CAMERAS_FIELD_NUMBER: _ClassVar[int]
    FRAME_LOG_SYNC_INTERVAL_NS_FIELD_NUMBER: _ClassVar[int]
    VIDEO_SYNC_INTERVAL_NS_FIELD_NUMBER: _ClassVar[int]
    FRAGMENT_TARGET_NS_FIELD_NUMBER: _ClassVar[int]
    ENCODER_STALL_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    SERIAL_BAUD_RATE_FIELD_NUMBER: _ClassVar[int]
    SERIAL_ACK_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    SERIAL_KEEPALIVE_INTERVAL_NS_FIELD_NUMBER: _ClassVar[int]
    SERIAL_COMMUNICATION_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    SERIAL_STOP_COMPLETION_MARGIN_NS_FIELD_NUMBER: _ClassVar[int]
    contract_version: int
    cameras: _containers.RepeatedCompositeFieldContainer[CameraFilePolicy]
    frame_log_sync_interval_ns: int
    video_sync_interval_ns: int
    fragment_target_ns: int
    encoder_stall_timeout_ns: int
    serial_baud_rate: int
    serial_ack_timeout_ns: int
    serial_keepalive_interval_ns: int
    serial_communication_timeout_ns: int
    serial_stop_completion_margin_ns: int
    def __init__(self, contract_version: _Optional[int] = ..., cameras: _Optional[_Iterable[_Union[CameraFilePolicy, _Mapping]]] = ..., frame_log_sync_interval_ns: _Optional[int] = ..., video_sync_interval_ns: _Optional[int] = ..., fragment_target_ns: _Optional[int] = ..., encoder_stall_timeout_ns: _Optional[int] = ..., serial_baud_rate: _Optional[int] = ..., serial_ack_timeout_ns: _Optional[int] = ..., serial_keepalive_interval_ns: _Optional[int] = ..., serial_communication_timeout_ns: _Optional[int] = ..., serial_stop_completion_margin_ns: _Optional[int] = ...) -> None: ...

class AcquisitionRecordingOptions(_message.Message):
    __slots__ = ("pending_records_capacity", "diagnostic_tail_max_lines", "diagnostic_tail_max_bytes")
    PENDING_RECORDS_CAPACITY_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_TAIL_MAX_LINES_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_TAIL_MAX_BYTES_FIELD_NUMBER: _ClassVar[int]
    pending_records_capacity: int
    diagnostic_tail_max_lines: int
    diagnostic_tail_max_bytes: int
    def __init__(self, pending_records_capacity: _Optional[int] = ..., diagnostic_tail_max_lines: _Optional[int] = ..., diagnostic_tail_max_bytes: _Optional[int] = ...) -> None: ...
