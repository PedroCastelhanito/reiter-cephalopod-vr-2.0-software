from cephvr.acquisition.v1 import camera_pb2 as _camera_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class PulseBoundaryCommand(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PULSE_BOUNDARY_COMMAND_UNSPECIFIED: _ClassVar[PulseBoundaryCommand]
    PULSE_BOUNDARY_COMMAND_ON: _ClassVar[PulseBoundaryCommand]
    PULSE_BOUNDARY_COMMAND_OFF: _ClassVar[PulseBoundaryCommand]

class PulseCommandOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    PULSE_COMMAND_OUTCOME_UNSPECIFIED: _ClassVar[PulseCommandOutcome]
    PULSE_COMMAND_OUTCOME_APPLIED: _ClassVar[PulseCommandOutcome]
    PULSE_COMMAND_OUTCOME_REJECTED: _ClassVar[PulseCommandOutcome]
    PULSE_COMMAND_OUTCOME_TIMED_OUT: _ClassVar[PulseCommandOutcome]
    PULSE_COMMAND_OUTCOME_TRANSPORT_FAILED: _ClassVar[PulseCommandOutcome]
    PULSE_COMMAND_OUTCOME_NOT_DISPATCHED: _ClassVar[PulseCommandOutcome]
PULSE_BOUNDARY_COMMAND_UNSPECIFIED: PulseBoundaryCommand
PULSE_BOUNDARY_COMMAND_ON: PulseBoundaryCommand
PULSE_BOUNDARY_COMMAND_OFF: PulseBoundaryCommand
PULSE_COMMAND_OUTCOME_UNSPECIFIED: PulseCommandOutcome
PULSE_COMMAND_OUTCOME_APPLIED: PulseCommandOutcome
PULSE_COMMAND_OUTCOME_REJECTED: PulseCommandOutcome
PULSE_COMMAND_OUTCOME_TIMED_OUT: PulseCommandOutcome
PULSE_COMMAND_OUTCOME_TRANSPORT_FAILED: PulseCommandOutcome
PULSE_COMMAND_OUTCOME_NOT_DISPATCHED: PulseCommandOutcome

class PulseCommandEvidence(_message.Message):
    __slots__ = ("connection_id", "request_id", "command", "behavioral_selected", "tracking_selected", "scheduled_boundary_monotonic_ns", "dispatched_monotonic_ns", "acknowledged_monotonic_ns", "applied", "resulting_state", "error_code", "stop_issued_monotonic_ns", "outcome")
    CONNECTION_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_SELECTED_FIELD_NUMBER: _ClassVar[int]
    TRACKING_SELECTED_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_BOUNDARY_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    DISPATCHED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    APPLIED_FIELD_NUMBER: _ClassVar[int]
    RESULTING_STATE_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    STOP_ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    connection_id: str
    request_id: str
    command: PulseBoundaryCommand
    behavioral_selected: bool
    tracking_selected: bool
    scheduled_boundary_monotonic_ns: int
    dispatched_monotonic_ns: int
    acknowledged_monotonic_ns: int
    applied: bool
    resulting_state: MicrocontrollerState
    error_code: str
    stop_issued_monotonic_ns: int
    outcome: PulseCommandOutcome
    def __init__(self, connection_id: _Optional[str] = ..., request_id: _Optional[str] = ..., command: _Optional[_Union[PulseBoundaryCommand, str]] = ..., behavioral_selected: _Optional[bool] = ..., tracking_selected: _Optional[bool] = ..., scheduled_boundary_monotonic_ns: _Optional[int] = ..., dispatched_monotonic_ns: _Optional[int] = ..., acknowledged_monotonic_ns: _Optional[int] = ..., applied: _Optional[bool] = ..., resulting_state: _Optional[_Union[MicrocontrollerState, _Mapping]] = ..., error_code: _Optional[str] = ..., stop_issued_monotonic_ns: _Optional[int] = ..., outcome: _Optional[_Union[PulseCommandOutcome, str]] = ...) -> None: ...

class PulseOutputState(_message.Message):
    __slots__ = ("enabled", "running", "pin", "applied_frequency_hz")
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    RUNNING_FIELD_NUMBER: _ClassVar[int]
    PIN_FIELD_NUMBER: _ClassVar[int]
    APPLIED_FREQUENCY_HZ_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    running: bool
    pin: str
    applied_frequency_hz: float
    def __init__(self, enabled: _Optional[bool] = ..., running: _Optional[bool] = ..., pin: _Optional[str] = ..., applied_frequency_hz: _Optional[float] = ...) -> None: ...

class MicrocontrollerCapabilities(_message.Message):
    __slots__ = ("protocol_version", "firmware", "pins", "minimum_requested_hz", "maximum_requested_hz", "minimum_watchdog_ms", "maximum_watchdog_ms", "rising_edge_input_pins")
    PROTOCOL_VERSION_FIELD_NUMBER: _ClassVar[int]
    FIRMWARE_FIELD_NUMBER: _ClassVar[int]
    PINS_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_REQUESTED_HZ_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_REQUESTED_HZ_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_WATCHDOG_MS_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_WATCHDOG_MS_FIELD_NUMBER: _ClassVar[int]
    RISING_EDGE_INPUT_PINS_FIELD_NUMBER: _ClassVar[int]
    protocol_version: int
    firmware: str
    pins: _containers.RepeatedScalarFieldContainer[str]
    minimum_requested_hz: float
    maximum_requested_hz: float
    minimum_watchdog_ms: int
    maximum_watchdog_ms: int
    rising_edge_input_pins: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, protocol_version: _Optional[int] = ..., firmware: _Optional[str] = ..., pins: _Optional[_Iterable[str]] = ..., minimum_requested_hz: _Optional[float] = ..., maximum_requested_hz: _Optional[float] = ..., minimum_watchdog_ms: _Optional[int] = ..., maximum_watchdog_ms: _Optional[int] = ..., rising_edge_input_pins: _Optional[_Iterable[str]] = ...) -> None: ...

class MicrocontrollerState(_message.Message):
    __slots__ = ("configuration_valid", "watchdog_stopped", "watchdog_ms", "behavioral", "tracking")
    CONFIGURATION_VALID_FIELD_NUMBER: _ClassVar[int]
    WATCHDOG_STOPPED_FIELD_NUMBER: _ClassVar[int]
    WATCHDOG_MS_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    configuration_valid: bool
    watchdog_stopped: bool
    watchdog_ms: int
    behavioral: PulseOutputState
    tracking: PulseOutputState
    def __init__(self, configuration_valid: _Optional[bool] = ..., watchdog_stopped: _Optional[bool] = ..., watchdog_ms: _Optional[int] = ..., behavioral: _Optional[_Union[PulseOutputState, _Mapping]] = ..., tracking: _Optional[_Union[PulseOutputState, _Mapping]] = ...) -> None: ...

class MicrocontrollerObservation(_message.Message):
    __slots__ = ("port", "connection_id", "request_id", "observed_monotonic_ns", "state", "capabilities", "capabilities_observed_monotonic_ns")
    PORT_FIELD_NUMBER: _ClassVar[int]
    CONNECTION_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_OBSERVED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    port: str
    connection_id: str
    request_id: str
    observed_monotonic_ns: int
    state: MicrocontrollerState
    capabilities: MicrocontrollerCapabilities
    capabilities_observed_monotonic_ns: int
    def __init__(self, port: _Optional[str] = ..., connection_id: _Optional[str] = ..., request_id: _Optional[str] = ..., observed_monotonic_ns: _Optional[int] = ..., state: _Optional[_Union[MicrocontrollerState, _Mapping]] = ..., capabilities: _Optional[_Union[MicrocontrollerCapabilities, _Mapping]] = ..., capabilities_observed_monotonic_ns: _Optional[int] = ...) -> None: ...

class PulseConfigurationResolution(_message.Message):
    __slots__ = ("requested_configuration_revision", "requested", "behavioral_active", "tracking_active", "applied")
    REQUESTED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    TRACKING_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    APPLIED_FIELD_NUMBER: _ClassVar[int]
    requested_configuration_revision: int
    requested: _camera_pb2.CameraPulseConfiguration
    behavioral_active: bool
    tracking_active: bool
    applied: MicrocontrollerObservation
    def __init__(self, requested_configuration_revision: _Optional[int] = ..., requested: _Optional[_Union[_camera_pb2.CameraPulseConfiguration, _Mapping]] = ..., behavioral_active: _Optional[bool] = ..., tracking_active: _Optional[bool] = ..., applied: _Optional[_Union[MicrocontrollerObservation, _Mapping]] = ...) -> None: ...
