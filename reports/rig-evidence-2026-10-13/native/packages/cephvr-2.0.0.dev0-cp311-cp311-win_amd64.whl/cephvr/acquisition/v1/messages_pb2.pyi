from cephvr.control.v1 import types_pb2 as _types_pb2
from cephvr.acquisition.v1 import camera_pb2 as _camera_pb2
from cephvr.acquisition.v1 import microcontroller_pb2 as _microcontroller_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CameraEditKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_EDIT_KIND_UNSPECIFIED: _ClassVar[CameraEditKind]
    CAMERA_EDIT_KIND_APPLY_SETTINGS: _ClassVar[CameraEditKind]
    CAMERA_EDIT_KIND_IMPORT_PFS: _ClassVar[CameraEditKind]
    CAMERA_EDIT_KIND_EXPORT_PFS: _ClassVar[CameraEditKind]
    CAMERA_EDIT_KIND_FINISH_EDITING: _ClassVar[CameraEditKind]
    CAMERA_EDIT_KIND_TEST_CONNECTION: _ClassVar[CameraEditKind]

class FrameBufferKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FRAME_BUFFER_KIND_UNSPECIFIED: _ClassVar[FrameBufferKind]
    FRAME_BUFFER_KIND_TRACKING: _ClassVar[FrameBufferKind]
    FRAME_BUFFER_KIND_PREVIEW: _ClassVar[FrameBufferKind]
CAMERA_EDIT_KIND_UNSPECIFIED: CameraEditKind
CAMERA_EDIT_KIND_APPLY_SETTINGS: CameraEditKind
CAMERA_EDIT_KIND_IMPORT_PFS: CameraEditKind
CAMERA_EDIT_KIND_EXPORT_PFS: CameraEditKind
CAMERA_EDIT_KIND_FINISH_EDITING: CameraEditKind
CAMERA_EDIT_KIND_TEST_CONNECTION: CameraEditKind
FRAME_BUFFER_KIND_UNSPECIFIED: FrameBufferKind
FRAME_BUFFER_KIND_TRACKING: FrameBufferKind
FRAME_BUFFER_KIND_PREVIEW: FrameBufferKind

class WorkerContext(_message.Message):
    __slots__ = ("worker", "owner", "work", "camera")
    WORKER_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    WORK_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    worker: _types_pb2.ProcessIdentity
    owner: _types_pb2.ProcessIdentity
    work: _types_pb2.WorkContext
    camera: _camera_pb2.CameraRole
    def __init__(self, worker: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., owner: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., work: _Optional[_Union[_types_pb2.WorkContext, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ...) -> None: ...

class WorkerCommand(_message.Message):
    __slots__ = ("command_id", "issuer", "target", "parent_operation")
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    ISSUER_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    PARENT_OPERATION_FIELD_NUMBER: _ClassVar[int]
    command_id: str
    issuer: _types_pb2.ProcessIdentity
    target: WorkerContext
    parent_operation: _types_pb2.OperationContext
    def __init__(self, command_id: _Optional[str] = ..., issuer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., target: _Optional[_Union[WorkerContext, _Mapping]] = ..., parent_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ...) -> None: ...

class WorkerEditCamera(_message.Message):
    __slots__ = ("command", "configuration_revision", "kind", "requested", "transport", "path")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    PATH_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    configuration_revision: int
    kind: CameraEditKind
    requested: _camera_pb2.CameraDeviceConfiguration
    transport: _camera_pb2.CameraTransportSettings
    path: str
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., kind: _Optional[_Union[CameraEditKind, str]] = ..., requested: _Optional[_Union[_camera_pb2.CameraDeviceConfiguration, _Mapping]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ..., path: _Optional[str] = ...) -> None: ...

class WorkerResolveCamera(_message.Message):
    __slots__ = ("command", "configuration_revision", "requested", "transport")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    configuration_revision: int
    requested: _camera_pb2.CameraDeviceConfiguration
    transport: _camera_pb2.CameraTransportSettings
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., requested: _Optional[_Union[_camera_pb2.CameraDeviceConfiguration, _Mapping]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ...) -> None: ...

class PreviewBufferContext(_message.Message):
    __slots__ = ("controller", "acquisition_run_id")
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    ACQUISITION_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    controller: _types_pb2.ProcessIdentity
    acquisition_run_id: str
    def __init__(self, controller: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., acquisition_run_id: _Optional[str] = ...) -> None: ...

class FrameBufferDescriptor(_message.Message):
    __slots__ = ("allocation_id", "owner", "producer", "consumer", "camera", "kind", "session", "preview", "configuration_revision", "shared_memory_name", "layout_version", "capacity_frames", "image", "allocation_bytes")
    ALLOCATION_ID_FIELD_NUMBER: _ClassVar[int]
    OWNER_FIELD_NUMBER: _ClassVar[int]
    PRODUCER_FIELD_NUMBER: _ClassVar[int]
    CONSUMER_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SESSION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    SHARED_MEMORY_NAME_FIELD_NUMBER: _ClassVar[int]
    LAYOUT_VERSION_FIELD_NUMBER: _ClassVar[int]
    CAPACITY_FRAMES_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    ALLOCATION_BYTES_FIELD_NUMBER: _ClassVar[int]
    allocation_id: str
    owner: _types_pb2.ProcessIdentity
    producer: _types_pb2.ProcessIdentity
    consumer: _types_pb2.ProcessIdentity
    camera: _camera_pb2.CameraRole
    kind: FrameBufferKind
    session: _types_pb2.SessionContext
    preview: PreviewBufferContext
    configuration_revision: int
    shared_memory_name: str
    layout_version: int
    capacity_frames: int
    image: _camera_pb2.CameraImageLayout
    allocation_bytes: int
    def __init__(self, allocation_id: _Optional[str] = ..., owner: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., producer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., consumer: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., kind: _Optional[_Union[FrameBufferKind, str]] = ..., session: _Optional[_Union[_types_pb2.SessionContext, _Mapping]] = ..., preview: _Optional[_Union[PreviewBufferContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., shared_memory_name: _Optional[str] = ..., layout_version: _Optional[int] = ..., capacity_frames: _Optional[int] = ..., image: _Optional[_Union[_camera_pb2.CameraImageLayout, _Mapping]] = ..., allocation_bytes: _Optional[int] = ...) -> None: ...

class RingSyncNames(_message.Message):
    __slots__ = ("transfer_id", "target", "event_name")
    TRANSFER_ID_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    EVENT_NAME_FIELD_NUMBER: _ClassVar[int]
    transfer_id: str
    target: _types_pb2.ProcessIdentity
    event_name: str
    def __init__(self, transfer_id: _Optional[str] = ..., target: _Optional[_Union[_types_pb2.ProcessIdentity, _Mapping]] = ..., event_name: _Optional[str] = ...) -> None: ...

class FrameBufferAttachment(_message.Message):
    __slots__ = ("buffer", "sync")
    BUFFER_FIELD_NUMBER: _ClassVar[int]
    SYNC_FIELD_NUMBER: _ClassVar[int]
    buffer: FrameBufferDescriptor
    sync: RingSyncNames
    def __init__(self, buffer: _Optional[_Union[FrameBufferDescriptor, _Mapping]] = ..., sync: _Optional[_Union[RingSyncNames, _Mapping]] = ...) -> None: ...

class AttachedResource(_message.Message):
    __slots__ = ("resource_id", "transfer_id")
    RESOURCE_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSFER_ID_FIELD_NUMBER: _ClassVar[int]
    resource_id: str
    transfer_id: str
    def __init__(self, resource_id: _Optional[str] = ..., transfer_id: _Optional[str] = ...) -> None: ...

class CameraCaptureSettings(_message.Message):
    __slots__ = ("sdk_buffer_count", "frame_silence_timeout_ns", "session_preview_max_hz")
    SDK_BUFFER_COUNT_FIELD_NUMBER: _ClassVar[int]
    FRAME_SILENCE_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    SESSION_PREVIEW_MAX_HZ_FIELD_NUMBER: _ClassVar[int]
    sdk_buffer_count: int
    frame_silence_timeout_ns: int
    session_preview_max_hz: float
    def __init__(self, sdk_buffer_count: _Optional[int] = ..., frame_silence_timeout_ns: _Optional[int] = ..., session_preview_max_hz: _Optional[float] = ...) -> None: ...

class CameraWorkerSetupPayload(_message.Message):
    __slots__ = ("device", "transport", "layout", "capture", "outputs", "native_timestamp_available", "native_counter_available", "camera_clock", "recording", "pulse_configuration", "owned_functions")
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    CAPTURE_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    NATIVE_TIMESTAMP_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    NATIVE_COUNTER_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    CAMERA_CLOCK_FIELD_NUMBER: _ClassVar[int]
    RECORDING_FIELD_NUMBER: _ClassVar[int]
    PULSE_CONFIGURATION_FIELD_NUMBER: _ClassVar[int]
    OWNED_FUNCTIONS_FIELD_NUMBER: _ClassVar[int]
    device: _camera_pb2.CameraDeviceConfiguration
    transport: _camera_pb2.CameraTransportSettings
    layout: _camera_pb2.CameraImageLayout
    capture: CameraCaptureSettings
    outputs: _containers.RepeatedCompositeFieldContainer[FrameBufferAttachment]
    native_timestamp_available: bool
    native_counter_available: bool
    camera_clock: _camera_pb2.CameraClockDescriptor
    recording: RecordingSettings
    pulse_configuration: _microcontroller_pb2.MicrocontrollerObservation
    owned_functions: _containers.RepeatedCompositeFieldContainer[_types_pb2.PreparedFunctionScope]
    def __init__(self, device: _Optional[_Union[_camera_pb2.CameraDeviceConfiguration, _Mapping]] = ..., transport: _Optional[_Union[_camera_pb2.CameraTransportSettings, _Mapping]] = ..., layout: _Optional[_Union[_camera_pb2.CameraImageLayout, _Mapping]] = ..., capture: _Optional[_Union[CameraCaptureSettings, _Mapping]] = ..., outputs: _Optional[_Iterable[_Union[FrameBufferAttachment, _Mapping]]] = ..., native_timestamp_available: _Optional[bool] = ..., native_counter_available: _Optional[bool] = ..., camera_clock: _Optional[_Union[_camera_pb2.CameraClockDescriptor, _Mapping]] = ..., recording: _Optional[_Union[RecordingSettings, _Mapping]] = ..., pulse_configuration: _Optional[_Union[_microcontroller_pb2.MicrocontrollerObservation, _Mapping]] = ..., owned_functions: _Optional[_Iterable[_Union[_types_pb2.PreparedFunctionScope, _Mapping]]] = ...) -> None: ...

class RecordingSettings(_message.Message):
    __slots__ = ("ffmpeg_executable", "ffprobe_executable", "ffmpeg_args", "video_sync_interval_ns", "fragment_target_ns", "encoder_stall_timeout_ns", "diagnostic_tail_max_lines", "diagnostic_tail_max_bytes", "session_config_reference", "recording_bit_depth", "frame_log_sync_interval_ns", "pending_records_capacity", "recording_queue_frames")
    FFMPEG_EXECUTABLE_FIELD_NUMBER: _ClassVar[int]
    FFPROBE_EXECUTABLE_FIELD_NUMBER: _ClassVar[int]
    FFMPEG_ARGS_FIELD_NUMBER: _ClassVar[int]
    VIDEO_SYNC_INTERVAL_NS_FIELD_NUMBER: _ClassVar[int]
    FRAGMENT_TARGET_NS_FIELD_NUMBER: _ClassVar[int]
    ENCODER_STALL_TIMEOUT_NS_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_TAIL_MAX_LINES_FIELD_NUMBER: _ClassVar[int]
    DIAGNOSTIC_TAIL_MAX_BYTES_FIELD_NUMBER: _ClassVar[int]
    SESSION_CONFIG_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    RECORDING_BIT_DEPTH_FIELD_NUMBER: _ClassVar[int]
    FRAME_LOG_SYNC_INTERVAL_NS_FIELD_NUMBER: _ClassVar[int]
    PENDING_RECORDS_CAPACITY_FIELD_NUMBER: _ClassVar[int]
    RECORDING_QUEUE_FRAMES_FIELD_NUMBER: _ClassVar[int]
    ffmpeg_executable: str
    ffprobe_executable: str
    ffmpeg_args: _containers.RepeatedScalarFieldContainer[str]
    video_sync_interval_ns: int
    fragment_target_ns: int
    encoder_stall_timeout_ns: int
    diagnostic_tail_max_lines: int
    diagnostic_tail_max_bytes: int
    session_config_reference: str
    recording_bit_depth: int
    frame_log_sync_interval_ns: int
    pending_records_capacity: int
    recording_queue_frames: int
    def __init__(self, ffmpeg_executable: _Optional[str] = ..., ffprobe_executable: _Optional[str] = ..., ffmpeg_args: _Optional[_Iterable[str]] = ..., video_sync_interval_ns: _Optional[int] = ..., fragment_target_ns: _Optional[int] = ..., encoder_stall_timeout_ns: _Optional[int] = ..., diagnostic_tail_max_lines: _Optional[int] = ..., diagnostic_tail_max_bytes: _Optional[int] = ..., session_config_reference: _Optional[str] = ..., recording_bit_depth: _Optional[int] = ..., frame_log_sync_interval_ns: _Optional[int] = ..., pending_records_capacity: _Optional[int] = ..., recording_queue_frames: _Optional[int] = ...) -> None: ...

class WorkerPreparePreview(_message.Message):
    __slots__ = ("command", "configuration_revision", "preview_run_id", "camera")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    configuration_revision: int
    preview_run_id: str
    camera: CameraWorkerSetupPayload
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ..., camera: _Optional[_Union[CameraWorkerSetupPayload, _Mapping]] = ...) -> None: ...

class WorkerStartPreview(_message.Message):
    __slots__ = ("command", "preparation", "configuration_revision", "preview_run_id")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    PREPARATION_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    preparation: _types_pb2.OperationContext
    configuration_revision: int
    preview_run_id: str
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., preparation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., configuration_revision: _Optional[int] = ..., preview_run_id: _Optional[str] = ...) -> None: ...

class WorkerStopPreview(_message.Message):
    __slots__ = ("command", "preview_run_id", "release_device")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    PREVIEW_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    RELEASE_DEVICE_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    preview_run_id: str
    release_device: bool
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., preview_run_id: _Optional[str] = ..., release_device: _Optional[bool] = ...) -> None: ...

class WorkerSetupSession(_message.Message):
    __slots__ = ("command", "camera", "configuration_revision")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    camera: CameraWorkerSetupPayload
    configuration_revision: int
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., camera: _Optional[_Union[CameraWorkerSetupPayload, _Mapping]] = ..., configuration_revision: _Optional[int] = ...) -> None: ...

class CameraWorkerTrialPreparation(_message.Message):
    __slots__ = ("allocation_ids", "outputs")
    ALLOCATION_IDS_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    allocation_ids: _containers.RepeatedScalarFieldContainer[str]
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputPlan]
    def __init__(self, allocation_ids: _Optional[_Iterable[str]] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputPlan, _Mapping]]] = ...) -> None: ...

class WorkerPrepareTrial(_message.Message):
    __slots__ = ("command", "camera", "required_configuration_revision")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    camera: CameraWorkerTrialPreparation
    required_configuration_revision: int
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., camera: _Optional[_Union[CameraWorkerTrialPreparation, _Mapping]] = ..., required_configuration_revision: _Optional[int] = ...) -> None: ...

class WorkerSchedule(_message.Message):
    __slots__ = ("command", "start_monotonic_ns", "end_monotonic_ns", "trial_file_prefix", "outputs")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    TRIAL_FILE_PREFIX_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    start_monotonic_ns: int
    end_monotonic_ns: int
    trial_file_prefix: str
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputPlan]
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., start_monotonic_ns: _Optional[int] = ..., end_monotonic_ns: _Optional[int] = ..., trial_file_prefix: _Optional[str] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputPlan, _Mapping]]] = ...) -> None: ...

class WorkerRelease(_message.Message):
    __slots__ = ("command", "schedule_operation", "start_monotonic_ns", "end_monotonic_ns")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_OPERATION_FIELD_NUMBER: _ClassVar[int]
    START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    schedule_operation: _types_pb2.OperationContext
    start_monotonic_ns: int
    end_monotonic_ns: int
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., schedule_operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., start_monotonic_ns: _Optional[int] = ..., end_monotonic_ns: _Optional[int] = ...) -> None: ...

class WorkerStop(_message.Message):
    __slots__ = ("command", "issued_monotonic_ns", "reason")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    issued_monotonic_ns: int
    reason: _types_pb2.Failure
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ..., reason: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class WorkerInterrupt(_message.Message):
    __slots__ = ("command", "issued_monotonic_ns", "reason")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    ISSUED_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    REASON_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    issued_monotonic_ns: int
    reason: _types_pb2.Failure
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., issued_monotonic_ns: _Optional[int] = ..., reason: _Optional[_Union[_types_pb2.Failure, _Mapping]] = ...) -> None: ...

class WorkerReadyEvidence(_message.Message):
    __slots__ = ("configuration_revision", "required_checks_passed", "attached_resources")
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_CHECKS_PASSED_FIELD_NUMBER: _ClassVar[int]
    ATTACHED_RESOURCES_FIELD_NUMBER: _ClassVar[int]
    configuration_revision: int
    required_checks_passed: bool
    attached_resources: _containers.RepeatedCompositeFieldContainer[AttachedResource]
    def __init__(self, configuration_revision: _Optional[int] = ..., required_checks_passed: _Optional[bool] = ..., attached_resources: _Optional[_Iterable[_Union[AttachedResource, _Mapping]]] = ...) -> None: ...

class WorkerStartedEvidence(_message.Message):
    __slots__ = ("actual_start_monotonic_ns", "first_activity")
    ACTUAL_START_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    FIRST_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
    actual_start_monotonic_ns: int
    first_activity: _containers.RepeatedCompositeFieldContainer[_types_pb2.ActivityEvidence]
    def __init__(self, actual_start_monotonic_ns: _Optional[int] = ..., first_activity: _Optional[_Iterable[_Union[_types_pb2.ActivityEvidence, _Mapping]]] = ...) -> None: ...

class WorkerStoppedEvidence(_message.Message):
    __slots__ = ("actual_stop_monotonic_ns", "activity_stopped", "recording_interval_sealed", "recording_end_monotonic_ns")
    ACTUAL_STOP_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    ACTIVITY_STOPPED_FIELD_NUMBER: _ClassVar[int]
    RECORDING_INTERVAL_SEALED_FIELD_NUMBER: _ClassVar[int]
    RECORDING_END_MONOTONIC_NS_FIELD_NUMBER: _ClassVar[int]
    actual_stop_monotonic_ns: int
    activity_stopped: bool
    recording_interval_sealed: bool
    recording_end_monotonic_ns: int
    def __init__(self, actual_stop_monotonic_ns: _Optional[int] = ..., activity_stopped: _Optional[bool] = ..., recording_interval_sealed: _Optional[bool] = ..., recording_end_monotonic_ns: _Optional[int] = ...) -> None: ...

class WorkerFinishedEvidence(_message.Message):
    __slots__ = ("activity_stopped", "outputs", "transport_summary")
    ACTIVITY_STOPPED_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
    activity_stopped: bool
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputResult]
    transport_summary: _types_pb2.CameraTransportSummary
    def __init__(self, activity_stopped: _Optional[bool] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputResult, _Mapping]]] = ..., transport_summary: _Optional[_Union[_types_pb2.CameraTransportSummary, _Mapping]] = ...) -> None: ...

class WorkerCleanupEvidence(_message.Message):
    __slots__ = ("resources", "outputs")
    RESOURCES_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    resources: _containers.RepeatedCompositeFieldContainer[_types_pb2.ResourceRelease]
    outputs: _containers.RepeatedCompositeFieldContainer[_types_pb2.OutputResult]
    def __init__(self, resources: _Optional[_Iterable[_Union[_types_pb2.ResourceRelease, _Mapping]]] = ..., outputs: _Optional[_Iterable[_Union[_types_pb2.OutputResult, _Mapping]]] = ...) -> None: ...

class WorkerLifecycleEvidence(_message.Message):
    __slots__ = ("source", "operation", "ready", "started", "stopped", "finished", "cleanup", "state_revision")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    READY_FIELD_NUMBER: _ClassVar[int]
    STARTED_FIELD_NUMBER: _ClassVar[int]
    STOPPED_FIELD_NUMBER: _ClassVar[int]
    FINISHED_FIELD_NUMBER: _ClassVar[int]
    CLEANUP_FIELD_NUMBER: _ClassVar[int]
    STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    source: WorkerContext
    operation: _types_pb2.OperationContext
    ready: WorkerReadyEvidence
    started: WorkerStartedEvidence
    stopped: WorkerStoppedEvidence
    finished: WorkerFinishedEvidence
    cleanup: WorkerCleanupEvidence
    state_revision: int
    def __init__(self, source: _Optional[_Union[WorkerContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationContext, _Mapping]] = ..., ready: _Optional[_Union[WorkerReadyEvidence, _Mapping]] = ..., started: _Optional[_Union[WorkerStartedEvidence, _Mapping]] = ..., stopped: _Optional[_Union[WorkerStoppedEvidence, _Mapping]] = ..., finished: _Optional[_Union[WorkerFinishedEvidence, _Mapping]] = ..., cleanup: _Optional[_Union[WorkerCleanupEvidence, _Mapping]] = ..., state_revision: _Optional[int] = ...) -> None: ...

class WorkerWarningReport(_message.Message):
    __slots__ = ("source", "view")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    VIEW_FIELD_NUMBER: _ClassVar[int]
    source: WorkerContext
    view: _types_pb2.AcquisitionWarningView
    def __init__(self, source: _Optional[_Union[WorkerContext, _Mapping]] = ..., view: _Optional[_Union[_types_pb2.AcquisitionWarningView, _Mapping]] = ...) -> None: ...

class WorkerOperationReport(_message.Message):
    __slots__ = ("source", "operation", "state_revision", "resolved_camera", "exported_pfs_path")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_CAMERA_FIELD_NUMBER: _ClassVar[int]
    EXPORTED_PFS_PATH_FIELD_NUMBER: _ClassVar[int]
    source: WorkerContext
    operation: _types_pb2.OperationState
    state_revision: int
    resolved_camera: _camera_pb2.CameraResolvedState
    exported_pfs_path: str
    def __init__(self, source: _Optional[_Union[WorkerContext, _Mapping]] = ..., operation: _Optional[_Union[_types_pb2.OperationState, _Mapping]] = ..., state_revision: _Optional[int] = ..., resolved_camera: _Optional[_Union[_camera_pb2.CameraResolvedState, _Mapping]] = ..., exported_pfs_path: _Optional[str] = ...) -> None: ...

class WorkerQuery(_message.Message):
    __slots__ = ("target",)
    TARGET_FIELD_NUMBER: _ClassVar[int]
    target: WorkerContext
    def __init__(self, target: _Optional[_Union[WorkerContext, _Mapping]] = ...) -> None: ...

class WorkerState(_message.Message):
    __slots__ = ("source", "state_revision", "confirmed_configuration_revision", "operations", "lifecycle", "warning_views")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    STATE_REVISION_FIELD_NUMBER: _ClassVar[int]
    CONFIRMED_CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    WARNING_VIEWS_FIELD_NUMBER: _ClassVar[int]
    source: WorkerContext
    state_revision: int
    confirmed_configuration_revision: int
    operations: _containers.RepeatedCompositeFieldContainer[_types_pb2.OperationState]
    lifecycle: _containers.RepeatedCompositeFieldContainer[WorkerLifecycleEvidence]
    warning_views: _containers.RepeatedCompositeFieldContainer[_types_pb2.AcquisitionWarningView]
    def __init__(self, source: _Optional[_Union[WorkerContext, _Mapping]] = ..., state_revision: _Optional[int] = ..., confirmed_configuration_revision: _Optional[int] = ..., operations: _Optional[_Iterable[_Union[_types_pb2.OperationState, _Mapping]]] = ..., lifecycle: _Optional[_Iterable[_Union[WorkerLifecycleEvidence, _Mapping]]] = ..., warning_views: _Optional[_Iterable[_Union[_types_pb2.AcquisitionWarningView, _Mapping]]] = ...) -> None: ...

class WorkerRetainedResultQuery(_message.Message):
    __slots__ = ("query", "command_id")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    COMMAND_ID_FIELD_NUMBER: _ClassVar[int]
    query: WorkerQuery
    command_id: str
    def __init__(self, query: _Optional[_Union[WorkerQuery, _Mapping]] = ..., command_id: _Optional[str] = ...) -> None: ...

class WorkerRetainedResult(_message.Message):
    __slots__ = ("found", "source", "admission", "operation", "lifecycle")
    FOUND_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    ADMISSION_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    found: bool
    source: WorkerContext
    admission: _types_pb2.CommandAdmission
    operation: WorkerOperationReport
    lifecycle: _containers.RepeatedCompositeFieldContainer[WorkerLifecycleEvidence]
    def __init__(self, found: _Optional[bool] = ..., source: _Optional[_Union[WorkerContext, _Mapping]] = ..., admission: _Optional[_Union[_types_pb2.CommandAdmission, _Mapping]] = ..., operation: _Optional[_Union[WorkerOperationReport, _Mapping]] = ..., lifecycle: _Optional[_Iterable[_Union[WorkerLifecycleEvidence, _Mapping]]] = ...) -> None: ...

class WorkerPulseEvidence(_message.Message):
    __slots__ = ("command", "camera", "evidence")
    COMMAND_FIELD_NUMBER: _ClassVar[int]
    CAMERA_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    command: WorkerCommand
    camera: _camera_pb2.CameraRole
    evidence: _microcontroller_pb2.PulseCommandEvidence
    def __init__(self, command: _Optional[_Union[WorkerCommand, _Mapping]] = ..., camera: _Optional[_Union[_camera_pb2.CameraRole, str]] = ..., evidence: _Optional[_Union[_microcontroller_pb2.PulseCommandEvidence, _Mapping]] = ...) -> None: ...
