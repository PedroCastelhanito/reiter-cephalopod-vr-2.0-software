from cephvr.acquisition.v1 import messages_pb2 as _messages_pb2
from cephvr.control.v1 import types_pb2 as _types_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
