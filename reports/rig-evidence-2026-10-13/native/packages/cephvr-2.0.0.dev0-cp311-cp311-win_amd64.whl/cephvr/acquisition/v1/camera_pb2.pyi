from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CameraRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CAMERA_ROLE_UNSPECIFIED: _ClassVar[CameraRole]
    CAMERA_ROLE_BEHAVIORAL: _ClassVar[CameraRole]
    CAMERA_ROLE_TRACKING: _ClassVar[CameraRole]
    CAMERA_ROLE_EYE_TRACKING: _ClassVar[CameraRole]

class FrameTiming(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FRAME_TIMING_UNSPECIFIED: _ClassVar[FrameTiming]
    FRAME_TIMING_EXTERNAL_TRIGGER: _ClassVar[FrameTiming]
    FRAME_TIMING_FREE_RUNNING: _ClassVar[FrameTiming]

class FeatureAccess(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    FEATURE_ACCESS_UNSPECIFIED: _ClassVar[FeatureAccess]
    FEATURE_ACCESS_UNAVAILABLE: _ClassVar[FeatureAccess]
    FEATURE_ACCESS_READ_ONLY: _ClassVar[FeatureAccess]
    FEATURE_ACCESS_READ_WRITE: _ClassVar[FeatureAccess]
CAMERA_ROLE_UNSPECIFIED: CameraRole
CAMERA_ROLE_BEHAVIORAL: CameraRole
CAMERA_ROLE_TRACKING: CameraRole
CAMERA_ROLE_EYE_TRACKING: CameraRole
FRAME_TIMING_UNSPECIFIED: FrameTiming
FRAME_TIMING_EXTERNAL_TRIGGER: FrameTiming
FRAME_TIMING_FREE_RUNNING: FrameTiming
FEATURE_ACCESS_UNSPECIFIED: FeatureAccess
FEATURE_ACCESS_UNAVAILABLE: FeatureAccess
FEATURE_ACCESS_READ_ONLY: FeatureAccess
FEATURE_ACCESS_READ_WRITE: FeatureAccess

class CameraRoi(_message.Message):
    __slots__ = ("width", "height", "offset_x", "offset_y")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_X_FIELD_NUMBER: _ClassVar[int]
    OFFSET_Y_FIELD_NUMBER: _ClassVar[int]
    width: int
    height: int
    offset_x: int
    offset_y: int
    def __init__(self, width: _Optional[int] = ..., height: _Optional[int] = ..., offset_x: _Optional[int] = ..., offset_y: _Optional[int] = ...) -> None: ...

class CameraGain(_message.Message):
    __slots__ = ("decimal_value", "integer_value", "unit", "selector")
    DECIMAL_VALUE_FIELD_NUMBER: _ClassVar[int]
    INTEGER_VALUE_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    decimal_value: float
    integer_value: int
    unit: str
    selector: str
    def __init__(self, decimal_value: _Optional[float] = ..., integer_value: _Optional[int] = ..., unit: _Optional[str] = ..., selector: _Optional[str] = ...) -> None: ...

class CameraSettings(_message.Message):
    __slots__ = ("exposure_us", "gain", "frame_rate_hz", "roi", "pixel_format", "trigger_selector", "trigger_source", "trigger_activation", "exposure_duration_mode")
    EXPOSURE_US_FIELD_NUMBER: _ClassVar[int]
    GAIN_FIELD_NUMBER: _ClassVar[int]
    FRAME_RATE_HZ_FIELD_NUMBER: _ClassVar[int]
    ROI_FIELD_NUMBER: _ClassVar[int]
    PIXEL_FORMAT_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_SELECTOR_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_ACTIVATION_FIELD_NUMBER: _ClassVar[int]
    EXPOSURE_DURATION_MODE_FIELD_NUMBER: _ClassVar[int]
    exposure_us: float
    gain: CameraGain
    frame_rate_hz: float
    roi: CameraRoi
    pixel_format: str
    trigger_selector: str
    trigger_source: str
    trigger_activation: str
    exposure_duration_mode: str
    def __init__(self, exposure_us: _Optional[float] = ..., gain: _Optional[_Union[CameraGain, _Mapping]] = ..., frame_rate_hz: _Optional[float] = ..., roi: _Optional[_Union[CameraRoi, _Mapping]] = ..., pixel_format: _Optional[str] = ..., trigger_selector: _Optional[str] = ..., trigger_source: _Optional[str] = ..., trigger_activation: _Optional[str] = ..., exposure_duration_mode: _Optional[str] = ...) -> None: ...

class PfsSnapshot(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class CameraDeviceConfiguration(_message.Message):
    __slots__ = ("device_id", "frame_timing", "settings", "pfs_baseline", "pfs_source_filename", "unaligned_free_running")
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    FRAME_TIMING_FIELD_NUMBER: _ClassVar[int]
    SETTINGS_FIELD_NUMBER: _ClassVar[int]
    PFS_BASELINE_FIELD_NUMBER: _ClassVar[int]
    PFS_SOURCE_FILENAME_FIELD_NUMBER: _ClassVar[int]
    UNALIGNED_FREE_RUNNING_FIELD_NUMBER: _ClassVar[int]
    device_id: str
    frame_timing: FrameTiming
    settings: CameraSettings
    pfs_baseline: PfsSnapshot
    pfs_source_filename: str
    unaligned_free_running: bool
    def __init__(self, device_id: _Optional[str] = ..., frame_timing: _Optional[_Union[FrameTiming, str]] = ..., settings: _Optional[_Union[CameraSettings, _Mapping]] = ..., pfs_baseline: _Optional[_Union[PfsSnapshot, _Mapping]] = ..., pfs_source_filename: _Optional[str] = ..., unaligned_free_running: _Optional[bool] = ...) -> None: ...

class CameraDeviceIdentity(_message.Message):
    __slots__ = ("configured_id", "physical_id", "model", "transport_interface")
    CONFIGURED_ID_FIELD_NUMBER: _ClassVar[int]
    PHYSICAL_ID_FIELD_NUMBER: _ClassVar[int]
    MODEL_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_INTERFACE_FIELD_NUMBER: _ClassVar[int]
    configured_id: str
    physical_id: str
    model: str
    transport_interface: str
    def __init__(self, configured_id: _Optional[str] = ..., physical_id: _Optional[str] = ..., model: _Optional[str] = ..., transport_interface: _Optional[str] = ...) -> None: ...

class FloatCapability(_message.Message):
    __slots__ = ("access", "minimum", "maximum", "increment", "unit")
    ACCESS_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_FIELD_NUMBER: _ClassVar[int]
    INCREMENT_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    access: FeatureAccess
    minimum: float
    maximum: float
    increment: float
    unit: str
    def __init__(self, access: _Optional[_Union[FeatureAccess, str]] = ..., minimum: _Optional[float] = ..., maximum: _Optional[float] = ..., increment: _Optional[float] = ..., unit: _Optional[str] = ...) -> None: ...

class IntegerCapability(_message.Message):
    __slots__ = ("access", "minimum", "maximum", "increment", "unit")
    ACCESS_FIELD_NUMBER: _ClassVar[int]
    MINIMUM_FIELD_NUMBER: _ClassVar[int]
    MAXIMUM_FIELD_NUMBER: _ClassVar[int]
    INCREMENT_FIELD_NUMBER: _ClassVar[int]
    UNIT_FIELD_NUMBER: _ClassVar[int]
    access: FeatureAccess
    minimum: int
    maximum: int
    increment: int
    unit: str
    def __init__(self, access: _Optional[_Union[FeatureAccess, str]] = ..., minimum: _Optional[int] = ..., maximum: _Optional[int] = ..., increment: _Optional[int] = ..., unit: _Optional[str] = ...) -> None: ...

class EnumChoice(_message.Message):
    __slots__ = ("value", "sdk_symbol")
    VALUE_FIELD_NUMBER: _ClassVar[int]
    SDK_SYMBOL_FIELD_NUMBER: _ClassVar[int]
    value: str
    sdk_symbol: str
    def __init__(self, value: _Optional[str] = ..., sdk_symbol: _Optional[str] = ...) -> None: ...

class EnumCapability(_message.Message):
    __slots__ = ("access", "choices")
    ACCESS_FIELD_NUMBER: _ClassVar[int]
    CHOICES_FIELD_NUMBER: _ClassVar[int]
    access: FeatureAccess
    choices: _containers.RepeatedCompositeFieldContainer[EnumChoice]
    def __init__(self, access: _Optional[_Union[FeatureAccess, str]] = ..., choices: _Optional[_Iterable[_Union[EnumChoice, _Mapping]]] = ...) -> None: ...

class GainCapability(_message.Message):
    __slots__ = ("decimal", "integer", "selector")
    DECIMAL_FIELD_NUMBER: _ClassVar[int]
    INTEGER_FIELD_NUMBER: _ClassVar[int]
    SELECTOR_FIELD_NUMBER: _ClassVar[int]
    decimal: FloatCapability
    integer: IntegerCapability
    selector: EnumCapability
    def __init__(self, decimal: _Optional[_Union[FloatCapability, _Mapping]] = ..., integer: _Optional[_Union[IntegerCapability, _Mapping]] = ..., selector: _Optional[_Union[EnumCapability, _Mapping]] = ...) -> None: ...

class RoiCapabilities(_message.Message):
    __slots__ = ("width", "height", "offset_x", "offset_y")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_X_FIELD_NUMBER: _ClassVar[int]
    OFFSET_Y_FIELD_NUMBER: _ClassVar[int]
    width: IntegerCapability
    height: IntegerCapability
    offset_x: IntegerCapability
    offset_y: IntegerCapability
    def __init__(self, width: _Optional[_Union[IntegerCapability, _Mapping]] = ..., height: _Optional[_Union[IntegerCapability, _Mapping]] = ..., offset_x: _Optional[_Union[IntegerCapability, _Mapping]] = ..., offset_y: _Optional[_Union[IntegerCapability, _Mapping]] = ...) -> None: ...

class TriggerRateLimit(_message.Message):
    __slots__ = ("maximum_hz", "evidence")
    MAXIMUM_HZ_FIELD_NUMBER: _ClassVar[int]
    EVIDENCE_FIELD_NUMBER: _ClassVar[int]
    maximum_hz: float
    evidence: str
    def __init__(self, maximum_hz: _Optional[float] = ..., evidence: _Optional[str] = ...) -> None: ...

class CameraCapabilities(_message.Message):
    __slots__ = ("exposure_us", "gain", "frame_rate_hz", "roi", "pixel_format", "trigger_selector", "trigger_source", "trigger_activation", "exposure_duration_mode", "trigger_rate_limit")
    EXPOSURE_US_FIELD_NUMBER: _ClassVar[int]
    GAIN_FIELD_NUMBER: _ClassVar[int]
    FRAME_RATE_HZ_FIELD_NUMBER: _ClassVar[int]
    ROI_FIELD_NUMBER: _ClassVar[int]
    PIXEL_FORMAT_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_SELECTOR_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_ACTIVATION_FIELD_NUMBER: _ClassVar[int]
    EXPOSURE_DURATION_MODE_FIELD_NUMBER: _ClassVar[int]
    TRIGGER_RATE_LIMIT_FIELD_NUMBER: _ClassVar[int]
    exposure_us: FloatCapability
    gain: GainCapability
    frame_rate_hz: FloatCapability
    roi: RoiCapabilities
    pixel_format: EnumCapability
    trigger_selector: EnumCapability
    trigger_source: EnumCapability
    trigger_activation: EnumCapability
    exposure_duration_mode: EnumCapability
    trigger_rate_limit: TriggerRateLimit
    def __init__(self, exposure_us: _Optional[_Union[FloatCapability, _Mapping]] = ..., gain: _Optional[_Union[GainCapability, _Mapping]] = ..., frame_rate_hz: _Optional[_Union[FloatCapability, _Mapping]] = ..., roi: _Optional[_Union[RoiCapabilities, _Mapping]] = ..., pixel_format: _Optional[_Union[EnumCapability, _Mapping]] = ..., trigger_selector: _Optional[_Union[EnumCapability, _Mapping]] = ..., trigger_source: _Optional[_Union[EnumCapability, _Mapping]] = ..., trigger_activation: _Optional[_Union[EnumCapability, _Mapping]] = ..., exposure_duration_mode: _Optional[_Union[EnumCapability, _Mapping]] = ..., trigger_rate_limit: _Optional[_Union[TriggerRateLimit, _Mapping]] = ...) -> None: ...

class CameraTransportOverride(_message.Message):
    __slots__ = ("sdk_name", "boolean", "integer", "decimal", "enum_symbol")
    SDK_NAME_FIELD_NUMBER: _ClassVar[int]
    BOOLEAN_FIELD_NUMBER: _ClassVar[int]
    INTEGER_FIELD_NUMBER: _ClassVar[int]
    DECIMAL_FIELD_NUMBER: _ClassVar[int]
    ENUM_SYMBOL_FIELD_NUMBER: _ClassVar[int]
    sdk_name: str
    boolean: bool
    integer: int
    decimal: float
    enum_symbol: str
    def __init__(self, sdk_name: _Optional[str] = ..., boolean: _Optional[bool] = ..., integer: _Optional[int] = ..., decimal: _Optional[float] = ..., enum_symbol: _Optional[str] = ...) -> None: ...

class CameraTransportSettings(_message.Message):
    __slots__ = ("overrides",)
    OVERRIDES_FIELD_NUMBER: _ClassVar[int]
    overrides: _containers.RepeatedCompositeFieldContainer[CameraTransportOverride]
    def __init__(self, overrides: _Optional[_Iterable[_Union[CameraTransportOverride, _Mapping]]] = ...) -> None: ...

class CameraImageLayout(_message.Message):
    __slots__ = ("width", "height", "pixel_format", "row_stride_bytes", "image_payload_bytes")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    PIXEL_FORMAT_FIELD_NUMBER: _ClassVar[int]
    ROW_STRIDE_BYTES_FIELD_NUMBER: _ClassVar[int]
    IMAGE_PAYLOAD_BYTES_FIELD_NUMBER: _ClassVar[int]
    width: int
    height: int
    pixel_format: str
    row_stride_bytes: int
    image_payload_bytes: int
    def __init__(self, width: _Optional[int] = ..., height: _Optional[int] = ..., pixel_format: _Optional[str] = ..., row_stride_bytes: _Optional[int] = ..., image_payload_bytes: _Optional[int] = ...) -> None: ...

class CameraSettingAdjustment(_message.Message):
    __slots__ = ("field_path", "requested_display", "actual_display")
    FIELD_PATH_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    ACTUAL_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    field_path: str
    requested_display: str
    actual_display: str
    def __init__(self, field_path: _Optional[str] = ..., requested_display: _Optional[str] = ..., actual_display: _Optional[str] = ...) -> None: ...

class CameraClockDescriptor(_message.Message):
    __slots__ = ("device_id", "timestamp_source", "conversion_available", "tick_period_ns_numerator", "tick_period_ns_denominator", "timestamp_semantics", "reset_semantics", "wrap_semantics", "unavailable_reason", "counter_source", "counter_semantics", "counter_width_bits", "counter_wrap_semantics", "counter_unavailable_reason")
    DEVICE_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_SOURCE_FIELD_NUMBER: _ClassVar[int]
    CONVERSION_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    TICK_PERIOD_NS_NUMERATOR_FIELD_NUMBER: _ClassVar[int]
    TICK_PERIOD_NS_DENOMINATOR_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_SEMANTICS_FIELD_NUMBER: _ClassVar[int]
    RESET_SEMANTICS_FIELD_NUMBER: _ClassVar[int]
    WRAP_SEMANTICS_FIELD_NUMBER: _ClassVar[int]
    UNAVAILABLE_REASON_FIELD_NUMBER: _ClassVar[int]
    COUNTER_SOURCE_FIELD_NUMBER: _ClassVar[int]
    COUNTER_SEMANTICS_FIELD_NUMBER: _ClassVar[int]
    COUNTER_WIDTH_BITS_FIELD_NUMBER: _ClassVar[int]
    COUNTER_WRAP_SEMANTICS_FIELD_NUMBER: _ClassVar[int]
    COUNTER_UNAVAILABLE_REASON_FIELD_NUMBER: _ClassVar[int]
    device_id: str
    timestamp_source: str
    conversion_available: bool
    tick_period_ns_numerator: int
    tick_period_ns_denominator: int
    timestamp_semantics: str
    reset_semantics: str
    wrap_semantics: str
    unavailable_reason: str
    counter_source: str
    counter_semantics: str
    counter_width_bits: int
    counter_wrap_semantics: str
    counter_unavailable_reason: str
    def __init__(self, device_id: _Optional[str] = ..., timestamp_source: _Optional[str] = ..., conversion_available: _Optional[bool] = ..., tick_period_ns_numerator: _Optional[int] = ..., tick_period_ns_denominator: _Optional[int] = ..., timestamp_semantics: _Optional[str] = ..., reset_semantics: _Optional[str] = ..., wrap_semantics: _Optional[str] = ..., unavailable_reason: _Optional[str] = ..., counter_source: _Optional[str] = ..., counter_semantics: _Optional[str] = ..., counter_width_bits: _Optional[int] = ..., counter_wrap_semantics: _Optional[str] = ..., counter_unavailable_reason: _Optional[str] = ...) -> None: ...

class NativeMetadataWarning(_message.Message):
    __slots__ = ("code", "sdk_code", "details")
    CODE_FIELD_NUMBER: _ClassVar[int]
    SDK_CODE_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    code: str
    sdk_code: str
    details: str
    def __init__(self, code: _Optional[str] = ..., sdk_code: _Optional[str] = ..., details: _Optional[str] = ...) -> None: ...

class CameraResolvedState(_message.Message):
    __slots__ = ("configuration_revision", "device", "applied", "capabilities", "transport", "layout", "adjustments", "native_timestamp_available", "native_counter_available", "effective_exposure_us", "metadata_warnings", "metadata_diagnostics", "camera_clock")
    CONFIGURATION_REVISION_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    APPLIED_FIELD_NUMBER: _ClassVar[int]
    CAPABILITIES_FIELD_NUMBER: _ClassVar[int]
    TRANSPORT_FIELD_NUMBER: _ClassVar[int]
    LAYOUT_FIELD_NUMBER: _ClassVar[int]
    ADJUSTMENTS_FIELD_NUMBER: _ClassVar[int]
    NATIVE_TIMESTAMP_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    NATIVE_COUNTER_AVAILABLE_FIELD_NUMBER: _ClassVar[int]
    EFFECTIVE_EXPOSURE_US_FIELD_NUMBER: _ClassVar[int]
    METADATA_WARNINGS_FIELD_NUMBER: _ClassVar[int]
    METADATA_DIAGNOSTICS_FIELD_NUMBER: _ClassVar[int]
    CAMERA_CLOCK_FIELD_NUMBER: _ClassVar[int]
    configuration_revision: int
    device: CameraDeviceIdentity
    applied: CameraDeviceConfiguration
    capabilities: CameraCapabilities
    transport: CameraTransportSettings
    layout: CameraImageLayout
    adjustments: _containers.RepeatedCompositeFieldContainer[CameraSettingAdjustment]
    native_timestamp_available: bool
    native_counter_available: bool
    effective_exposure_us: float
    metadata_warnings: _containers.RepeatedScalarFieldContainer[str]
    metadata_diagnostics: _containers.RepeatedCompositeFieldContainer[NativeMetadataWarning]
    camera_clock: CameraClockDescriptor
    def __init__(self, configuration_revision: _Optional[int] = ..., device: _Optional[_Union[CameraDeviceIdentity, _Mapping]] = ..., applied: _Optional[_Union[CameraDeviceConfiguration, _Mapping]] = ..., capabilities: _Optional[_Union[CameraCapabilities, _Mapping]] = ..., transport: _Optional[_Union[CameraTransportSettings, _Mapping]] = ..., layout: _Optional[_Union[CameraImageLayout, _Mapping]] = ..., adjustments: _Optional[_Iterable[_Union[CameraSettingAdjustment, _Mapping]]] = ..., native_timestamp_available: _Optional[bool] = ..., native_counter_available: _Optional[bool] = ..., effective_exposure_us: _Optional[float] = ..., metadata_warnings: _Optional[_Iterable[str]] = ..., metadata_diagnostics: _Optional[_Iterable[_Union[NativeMetadataWarning, _Mapping]]] = ..., camera_clock: _Optional[_Union[CameraClockDescriptor, _Mapping]] = ...) -> None: ...

class FfmpegArguments(_message.Message):
    __slots__ = ("values",)
    VALUES_FIELD_NUMBER: _ClassVar[int]
    values: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, values: _Optional[_Iterable[str]] = ...) -> None: ...

class CameraSessionSettings(_message.Message):
    __slots__ = ("enabled", "save_video", "device", "ffmpeg_args", "sdk_buffer_count", "recording_bit_depth")
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    SAVE_VIDEO_FIELD_NUMBER: _ClassVar[int]
    DEVICE_FIELD_NUMBER: _ClassVar[int]
    FFMPEG_ARGS_FIELD_NUMBER: _ClassVar[int]
    SDK_BUFFER_COUNT_FIELD_NUMBER: _ClassVar[int]
    RECORDING_BIT_DEPTH_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    save_video: bool
    device: CameraDeviceConfiguration
    ffmpeg_args: FfmpegArguments
    sdk_buffer_count: int
    recording_bit_depth: int
    def __init__(self, enabled: _Optional[bool] = ..., save_video: _Optional[bool] = ..., device: _Optional[_Union[CameraDeviceConfiguration, _Mapping]] = ..., ffmpeg_args: _Optional[_Union[FfmpegArguments, _Mapping]] = ..., sdk_buffer_count: _Optional[int] = ..., recording_bit_depth: _Optional[int] = ...) -> None: ...

class CameraPulseSettings(_message.Message):
    __slots__ = ("pin", "requested_frequency_hz")
    PIN_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_FREQUENCY_HZ_FIELD_NUMBER: _ClassVar[int]
    pin: str
    requested_frequency_hz: float
    def __init__(self, pin: _Optional[str] = ..., requested_frequency_hz: _Optional[float] = ...) -> None: ...

class CameraPulseConfiguration(_message.Message):
    __slots__ = ("port", "behavioral", "tracking", "trial_state_pin", "projector_flip_pin", "trial_state_enabled", "projector_flip_enabled", "eye_tracking")
    PORT_FIELD_NUMBER: _ClassVar[int]
    BEHAVIORAL_FIELD_NUMBER: _ClassVar[int]
    TRACKING_FIELD_NUMBER: _ClassVar[int]
    TRIAL_STATE_PIN_FIELD_NUMBER: _ClassVar[int]
    PROJECTOR_FLIP_PIN_FIELD_NUMBER: _ClassVar[int]
    TRIAL_STATE_ENABLED_FIELD_NUMBER: _ClassVar[int]
    PROJECTOR_FLIP_ENABLED_FIELD_NUMBER: _ClassVar[int]
    EYE_TRACKING_FIELD_NUMBER: _ClassVar[int]
    port: str
    behavioral: CameraPulseSettings
    tracking: CameraPulseSettings
    trial_state_pin: str
    projector_flip_pin: str
    trial_state_enabled: bool
    projector_flip_enabled: bool
    eye_tracking: CameraPulseSettings
    def __init__(self, port: _Optional[str] = ..., behavioral: _Optional[_Union[CameraPulseSettings, _Mapping]] = ..., tracking: _Optional[_Union[CameraPulseSettings, _Mapping]] = ..., trial_state_pin: _Optional[str] = ..., projector_flip_pin: _Optional[str] = ..., trial_state_enabled: _Optional[bool] = ..., projector_flip_enabled: _Optional[bool] = ..., eye_tracking: _Optional[_Union[CameraPulseSettings, _Mapping]] = ...) -> None: ...
